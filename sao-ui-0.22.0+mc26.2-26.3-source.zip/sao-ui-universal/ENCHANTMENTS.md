# 魔咒资料与数值核对（0.15）

核对对象为 Minecraft Java 26.2 / 26.3 的游戏内 data/minecraft/enchantment/*.json，共43项。中英文说明使用自行归纳的机制事实，不复制Wiki段落。两版原版附魔清单相同。显示按物品已有附魔等级计算；无附魔时显示最高等级的可用魔咒预览，明确标为未生效。附魔书显示储存附魔，模组/数据包自定义ID保留名称和ID并提示无详解。

资料入口：https://minecraft.wiki/w/Enchantment

- aqua_affinity: https://minecraft.wiki/w/Aqua_Affinity
- bane_of_arthropods: https://minecraft.wiki/w/Bane_Of_Arthropods
- binding_curse: https://minecraft.wiki/w/Curse_of_Binding
- blast_protection: https://minecraft.wiki/w/Blast_Protection
- breach: https://minecraft.wiki/w/Breach
- channeling: https://minecraft.wiki/w/Channeling
- density: https://minecraft.wiki/w/Density
- depth_strider: https://minecraft.wiki/w/Depth_Strider
- efficiency: https://minecraft.wiki/w/Efficiency
- feather_falling: https://minecraft.wiki/w/Feather_Falling
- fire_aspect: https://minecraft.wiki/w/Fire_Aspect
- fire_protection: https://minecraft.wiki/w/Fire_Protection
- flame: https://minecraft.wiki/w/Flame
- fortune: https://minecraft.wiki/w/Fortune
- frost_walker: https://minecraft.wiki/w/Frost_Walker
- impaling: https://minecraft.wiki/w/Impaling
- infinity: https://minecraft.wiki/w/Infinity
- knockback: https://minecraft.wiki/w/Knockback
- looting: https://minecraft.wiki/w/Looting
- loyalty: https://minecraft.wiki/w/Loyalty
- luck_of_the_sea: https://minecraft.wiki/w/Luck_Of_The_Sea
- lunge: https://minecraft.wiki/w/Lunge
- lure: https://minecraft.wiki/w/Lure
- mending: https://minecraft.wiki/w/Mending
- multishot: https://minecraft.wiki/w/Multishot
- piercing: https://minecraft.wiki/w/Piercing
- power: https://minecraft.wiki/w/Power
- projectile_protection: https://minecraft.wiki/w/Projectile_Protection
- protection: https://minecraft.wiki/w/Protection
- punch: https://minecraft.wiki/w/Punch
- quick_charge: https://minecraft.wiki/w/Quick_Charge
- respiration: https://minecraft.wiki/w/Respiration
- riptide: https://minecraft.wiki/w/Riptide
- sharpness: https://minecraft.wiki/w/Sharpness
- silk_touch: https://minecraft.wiki/w/Silk_Touch
- smite: https://minecraft.wiki/w/Smite
- soul_speed: https://minecraft.wiki/w/Soul_Speed
- sweeping_edge: https://minecraft.wiki/w/Sweeping_Edge
- swift_sneak: https://minecraft.wiki/w/Swift_Sneak
- thorns: https://minecraft.wiki/w/Thorns
- unbreaking: https://minecraft.wiki/w/Unbreaking
- vanishing_curse: https://minecraft.wiki/w/Curse_of_Vanishing
- wind_burst: https://minecraft.wiki/w/Wind_Burst

关键校验：耐久III普通工具75%、护甲30%；锋利V额外3点；效率V速度加值26；时运III适用矿石平均2.2倍；快速装填III约0.5秒；摔落保护IV48%；迅捷潜行III75%；灵魂疾行III相对基础速度+61.5%。荆棘按当前数据定义为1至5点伤害，未沿用旧版1至4的表述；水下呼吸以当前oxygen_bonus属性与逐次消耗概率解释，避免将旧版15秒公式当作固定计时。突进冲量为0.458×等级，疲劳度为4×等级。

以上是原版Java默认机制。服务端数据包可更改同名附魔的效果和条件，界面应明确标注该限制，不能把客户端说明当作服务器伤害结算值。

## 0.19 同步数据的来源与边界

26.2/26.3 的 RegistryDataLoader 将附魔列为同步注册表，并使用 Enchantment.DIRECT_CODEC；该 codec 包含 effects。客户端从当前世界注册表读取实例，由原生 LevelBasedValue 在所查看等级计算数值。EnchantmentEffectFacts 只描述已支持的标准操作，不执行效果、战利品条件或函数。

单人连接有共享服务器注册表的优化，不能仅凭单人测试证明网络解码。因此 ServerEnchantmentsGameTest 使用绑定回环地址的 DedicatedServer 和 TCP 连接，数据包只写进服务端存档，并断言客户端附魔实例与服务端实例不同。它覆盖新增附魔、等级数值、概率、条件函数提示、原版附魔被数据包覆盖，以及切换到新世界后的隔离。26.2 测试数据包使用 condition 字段，26.3 使用 type 字段；UI 对两版均保留 requirements 条件标志。

资源包说明是作者提供的文字；同步数值是效果定义中的单步操作；原版详解是默认参考。它们都不能替代完整的服务器战斗计算。未知效果、服务端函数正文和插件模拟附魔需要专用适配或作者说明。
