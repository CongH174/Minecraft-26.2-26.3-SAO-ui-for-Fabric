> 当前统一版的权威规格见 ../../SPEC.md。0.15新增43种魔咒详解、可附魔物品目录、IPN热键适配和可选服务端容器2×2合成。以下保留历史功能规格作为实现背景。

# SAO UI 0.14.0 — Flat container workflows

- Minecraft 26.2; Fabric Loader 0.19.3; Fabric API 0.152.1+26.2; Java 25.
- Loom 1.17.21; Gradle 9.5.1. No mappings dependency for unobfuscated 26.2.
- Client only; GUI render-state and container-bounds accessors plus scoped Screen/MouseHandler presentation Mixins. Only vanilla container packets; no custom network protocol, server dependency, browser engine or UI framework.
- Player name, HP/max HP, absorption amount, experience level; health animation uses elapsed real time.
- K opens/closes menu; Escape returns. O is reserved by vanilla 26.2 friends UI. Native buttons retain keyboard focus and narration.
- Circular root icons select Player / Items / Equipment / Settings. A projected silver submenu unfolds to the right. Inventory shows the 27-slot backpack, 9-slot hotbar and offhand directly. Equipment lists all carried/equipped offensive items. Organize opens the native inventory; options open native OptionsScreen after the closing animation.
- HUD visibility, animation, scale, x/y are saved in config/saoui.json. Cancel discards edits.
- Preserve vanilla HUD by default; HudOptions independently controls SAO health/hunger/experience/armor, saturation overlay and vanilla HUD visibility. Respect F1 and spectator mode.
- Reuse only the PNGs recorded in ASSETS.md. No upstream Kotlin/Lua engine, fonts or audio.
- Future work: target HP, server-backed party data.
- Verification: gradlew build; gradlew runClientGameTest. Test source set must stay out of the release jar.
- Token discipline: consult this file first, search only relevant source paths, show the first useful error and test summary.

- Opening: 520 ms, 32 ms orb stagger, front-facing approach. Closing: 240 ms reverse fan. Page reveal: 260 ms.
- Pointer hits use the inverse perspective mapping, including circular hit regions. Configurable, stronger mouse translation parallax; sharp world background.
- See DESIGN.md for palette and hierarchy. Pure projection/motion math is unit tested; GameTest verifies native pointer dispatch and saves deterministic rendered animation frames.

- Left paper doll uses the current skin and armor via the vanilla entity preview; mouse look modifies only render state, never real player rotation.
- Live item models, stack counts, durability and vanilla tooltips. Inventory slots forward projected hits to the vanilla AbstractContainerScreen input state machine. Equipment catalogue slots remain inspection-only. Organize opens the full vanilla inventory/crafting screen.
- Offensive = weapon/tool/piercing/kinetic components, projectile weapon class, sword/axe tags, or positive attack damage/speed/knockback modifiers. Scan 36 carried slots plus offhand and 4 armor slots, without duplicating main hand.
- Item stats are base main-hand melee values; theoretical DPS is damage times speed, excluding target/conditional enchantment effects. Ranged damage is explicitly conditional.

- 26.2 port: RenderPipeline lives under com.mojang.blaze3d.pipeline; input type is KEYSYM; OptionsScreen takes (parent, options, false). Use the 26.2 fixed brewing fuel capacity (20) and duration (400 ticks), as total-value getters do not exist.
- Dependency metadata is generated from gradle.properties and checked with Fabric VersionPredicate. This dedicated 0.14.0+mc26.2 build targets only 26.2; the 26.3 build remains separate.

- InventoryInteraction delegates pickup, split/merge, quick move, quick craft, double click and inventory keybinds to the native InventoryMenu. Slot coordinates/hits and carried/drag preview rendering are projected into the SAO menu.
- Blank-space clicks do not drop the carried stack; Q remains explicit native dropping. Page switches cancel the drag gesture but keep carried items. Closing/replacing the screen sends the native container-close packet and calls native cleanup only while inventoryMenu is active; never closes a newly opened server container.
- Native client and integrated-server acceptance checks cover item/component conservation, offhand/hotbar mapping and closing with a carried enchanted weapon.

- MenuModule holds stable IDs, translation keys and existing icon assets. SaoConfig persists moduleOrder, hiddenModules and homeModule; validation removes unknown/duplicate IDs, appends missing modules, always enables Settings, and falls back from a hidden/invalid home to the first enabled module.
- SaoModuleSettingsScreen offers reorder, visibility, home selection and reset through an isolated draft. Save updates the menu; Cancel/Esc leaves memory and disk unchanged. HUD reset and module reset are independent.
- Fresh menu instances use the configured home; returning from settings or resizing preserves the current page when enabled. Root positions, selected connector and stagger animate in configured visible order. Close remains last; profile shortcuts respect hidden modules.
- Config tests cover legacy migration, malformed values, stable home IDs, deep-copy drafts, independent resets and JSON persistence. Client GameTest covers controls, custom order, hidden modules, home opening, native inventory operations after reorder, all optional modules hidden, fallback, reset and saved-file reload.

- Main menu always uses yaw/pitch 0, including opening. Default pointer displacement is 18/14 GUI units times normalized cursor position and parallaxStrength (0..2).
- BlockFloatingUi captures a recent client UseBlock position and uses GameRenderer.projectPointToScreen for the real world origin. Native AbstractContainerScreen instances are transformed in place; no screen/menu replacement or invented block slots. Player/creative inventories are excluded.
- BlockSurfaceMotion performs a 420ms scale/rise from the block to the fitted flat layout; one cached affine frame drives native GUI extraction and mouse inverse mapping for click/release/drag/move/scroll. Gate mutations until settled; keep Esc available. Native blur/dimming is suppressed only for animated block screens.
- blockUiEnabled and parallaxStrength persist and are editable under UI Settings; display reset includes these preferences, module reset remains separate.

- Clamp parallax to the actual panel bounds with a 6-unit viewport margin, including large chest menus and recipe drawers at maximum strength. Pure math and runtime checks cover the boundary behavior.

- 0.7 presentation: FlatContainerLayout resolves 13 known vanilla menu families; FlatContainerUi replaces their backgrounds, labels and slot geometry with independent workflow/storage and player-inventory panels. Storage and simple workflow slots are rearranged; choice controls use their native hit regions. No invented slots. Match player slots by container identity and inventory index, including Crafter's trailing result slot.
- The render pass preserves actual native menu state and widget callbacks, ghost recipes, item decorations, tooltip behavior and map/banner/entity previews. Texture/sprite filtering is scoped to native details, with explicit overload targets. Native PIP bounds are transformed explicitly. Anvil fields and recipe drawers use dark text and flat chrome.
- Flat bounds include all panels and the visible recipe drawer. Outside-click handling covers base containers plus the recipe-book and loom overrides, so the relocated backpack is never treated as an outside drop. Width/height fitting and the affine inverse share one cached frame.
- Acceptance exercises 23 block variants, client-only geometry, chest transfer conservation, furnace progress, crafting output, recipe drawer input, anvil rename packets, smithing result, stonecutting choice/output, enchantment choice, brewing progress, beacon payment/effect buttons, loom selection, cartography results and Crafter slot disabling.

- 0.8 freedom-first architecture: ContainerUiProfile owns one preset; ContainerUiRules resolves complete defaults/block/location profiles; ContainerPanelLayout performs pure module placement. FlatContainerUi consumes resolved placement, and BlockFloatingUi uses the same anchor/offset/fitting transform for pointer input. No shared menu-type policy: chest and barrel may differ despite using the same menu.
- ContainerTargets resolves the actual used block ID and a hashed save-path/server-address identity plus dimension/coordinates/block ID. Location rules cannot leak into other worlds, dimensions, positions or replacement block types. Settings expose 22 vanilla entries: all anvil damage states and shulker colors resolve through their shared family keys.
- SaoContainerSettingsScreen edits an isolated draft with a searchable target list, default/type/aimed-position scopes, enable switch, four directions, gap, independent X/Y offsets, save/cancel and remove-override inheritance. Numeric values outside allowed ranges prevent saving. Rules take effect on the next container opening.
- PlayerArmorSlots is an optional backpack-page equipment column above the offhand, mapped to native InventoryMenu slots 5..8. Reuse InventoryInteraction and armor/cursed-item restrictions; no portrait-side fit expansion.

- Hold the block affine frame steady while mouse buttons are held; resume parallax after release. K-menu inventory/armor gestures likewise hold translation. This prevents small, fitted slots sliding away before placement completes.

- 0.9: RecipeBookComponent.updateTabs has a separate vanilla center-based path; relocate visible tabs from recipeOrigin after every update, retaining native visibility/selection/callbacks. Verify four directions, resize, reopen and recipe updates.
- HudOptions is a deep-copied nested configuration with legacy defaults. HudValues bounds percentages and unknown saturation. SaoHud samples native food/XP/armor and draws collapsed independent rows. Saturation uses AppleSkin's vanilla FoodData sync, gated by optional mod detection; no linked AppleSkin classes or bundled third-party jar. Multiplayer accuracy requires server synchronization.
- SaoHudSettingsScreen returns an isolated draft to SaoSettingsScreen; final persistence stays at the parent. Hide only selected native health/food/armor/experience/crosshair elements; keep the hotbar and unrelated HUDs. F1/spectator behavior stays native.
- Registered SAO key closes every AbstractContainerScreen via native onClose, including unskinned menus and entrance frames. Drain the consumed key press to prevent reopen. Acceptance tests remapped keys and cursor conservation.

- 0.10: ContainerTypeGroups canonicalizes vanilla colored shulkers and damaged anvils only at the type-rule/catalog layer. Exact world/position/block identities stay untouched. Legacy type rules merge deterministically with base ID priority, otherwise sorted first variant.
- HudBarRenderer shares the existing health chrome and gradient fill among all four bars. Saturation and absorption use full 9-pixel fill height; absorption length is current absorption/max HP. Native poison darkens health green; wither takes precedence and uses black. Gold remains above the effect tint. No synthetic damage handling.
- Health text omits Lv whenever the SAO XP bar is enabled. It returns when XP is hidden.
- Five independent native visibility flags replace hideVanilla. Legacy true migrates into those flags once. HOTBAR, chat, effects, air and unrelated HUDs are never registered for suppression. ExperienceBarMixin scopes XP track suppression to the ExperienceBar class so contextual locator/jump bars remain intact.
- SaoHudSettingsScreen presents SAO and vanilla controls in two columns, keeps isolated nested drafts, and explicitly states that the native hotbar is retained.

- 26.2 test fixture uses getClientLevel for chunk waits. Test-only mouse invoker dispatches the real handler; native stats request/reply supplies an ordered packet barrier, replacing the newer Fabric wait API. Keep both under gametest sources and dedicated test Mixin namespace.

- 0.11 universal containers: replaceAllContainers defaults false and is copied/persisted through isolated settings drafts. When true it overrides all enable rules, while known vanilla block family layouts remain configurable. Turning off restores per-block policy on subsequent opens.
- Observe Gui.setScreen RETURN and ClientPacketListener.handleOpenScreen RETURN in addition to ScreenEvents. Require screen identity == current visible screen before consuming UseBlock origins. Exclude InventoryInteraction. Read nullable menuType via accessor, never getType on InventoryMenu.
- UniversalContainerUi skins E inventory, creative, merchant, horse and unknown/modded AbstractContainerScreen instances. Preserve native slot and widget geometry, subclass extractContents/render/labels, native protocol and menu IDs. Include directly rendered creative tabs in fit bounds and exclude creative's offscreen hidden slots. Native backgrounds/chrome replaced; small functional textures and custom content retained.
- Scope: native container screens; non-container screens and independent mod rendering engines are not promised complete reskins. No server installation required. Gameplay remains server authoritative; this is not a server-side packet interceptor.
- Acceptance includes exact nested initialization crash, server-initiated menu without UseBlock, opt-in precedence and save/cancel, E inventory/armor/recipes, modded irregular slots/custom button/data sync, actual merchant output, horse saddle sync, creative tab input/item packet sync, plus all existing suites. Runtime compatibility also exercised with the user's Fabric API 0.156.0+26.2.

- 0.12: UiTheme persists independent RGB background/accent values with legacy/default validation and deep-copy isolation. ThemePalette caches derived surface, ink, muted, border, cell and selection colors, shared by projected menus and all SAO container adapters. HUD semantic colors remain independent.
- SaoThemeSettingsScreen edits a nested draft with RGB sliders, six-digit HEX input, local preview, invalid-input save guard and isolated reset. Save in both child and parent to persist. Resizing retains partial text. Text automatically chooses light/dark contrast.
- Theme acceptance exercises nested cancel/save, disk reload, HEX validation, resize, real slider mouse dispatch, reset, dark/cyan and light/rose rendered screens, and native container item synchronization.

- 0.14: PlayerCraftingSlots attaches InventoryMenu result 0 and input 1..4 directly to the K inventory page. Shares InventoryInteraction for native input/recipes/Shift result/cleanup; no invented slots or recipe code. PlayerCraftingLayout owns pure right-panel geometry and inventory-only viewport expansion.
- craftingVisible defaults true, copies/persists through existing isolated settings drafts and hides this module only. Non-inventory pages disable all five widgets. Page switches and resize retain native inputs; native menu close returns ingredients/cursor with usual full-inventory drop rules.
- Verification covers 2x2 workbench recipe, split placement, three batches of sticks, result deposit restriction, page/resize retention, max-parallax fit, close/preview conservation, E inventory agreement, and preference save/cancel.

- 0.16: independent physical UI/HUD sizing, exact 0..2 sliders, native background blur, surface opacity, custom font color and nested effect drafts. See root SPEC.md.
