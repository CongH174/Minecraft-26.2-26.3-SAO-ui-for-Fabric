package io.github.saoui;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.player.LocalPlayer;

/** AppleSkin's saturation receiver writes to vanilla FoodData, so no linked AppleSkin classes are needed. */
final class AppleSkinBridge {
    static final boolean AVAILABLE = FabricLoader.getInstance().isModLoaded("appleskin");
    static float saturation(LocalPlayer player) {
        return AVAILABLE ? player.getFoodData().getSaturationLevel() : Float.NaN;
    }
    private AppleSkinBridge() {}
}
