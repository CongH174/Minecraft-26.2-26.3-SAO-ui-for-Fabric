package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Live player preview, inventory and combat catalogue, sharing the menu's projected surface. */
public final class PlayerPanels {
    private final Consumer<FloatingItemSlot> add, remove;
    private final List<FloatingItemSlot> slots = new ArrayList<>();
    private List<CombatItems.Entry> weapons = List.of();
    private MenuModule page;
    private int selectedItem;
    private InventoryInteraction inventory;
    private PlayerArmorSlots armor;
    private PlayerCraftingSlots crafting;
    private final EnchantmentPanel enchantments = new EnchantmentPanel();

    public PlayerPanels(Consumer<FloatingItemSlot> add, Consumer<FloatingItemSlot> remove) {
        this.add = add; this.remove = remove;
    }

    void bindInventory(InventoryInteraction inventory) {
        this.inventory = inventory;
        armor = new PlayerArmorSlots(inventory, add);
        crafting = new PlayerCraftingSlots(inventory, add);
    }

    int inventorySlotAt(double x, double y) {
        int armorSlot = armor == null ? -1 : armor.slotAt(x, y);
        if (armorSlot >= 0) return armorSlot;
        if (page != MenuModule.INVENTORY) return -1;
        int craftSlot = crafting == null ? -1 : crafting.slotAt(x, y);
        if (craftSlot >= 0) return craftSlot;
        for (var slot : slots) if (slot.isMouseOver(x, y)) return slot.menuSlot();
        return -1;
    }

    void selectAt(double x, double y) {
        for (int i = 0; i < slots.size(); i++) if (slots.get(i).isMouseOver(x, y)) selectedItem = i;
    }

    public void setPage(MenuModule page) {
        for (var slot : slots) remove.accept(slot);
        slots.clear();
        this.page = page;
        var player = Minecraft.getInstance().player;
        selectedItem = page == MenuModule.INVENTORY && player != null ? 27 + player.getInventory().getSelectedSlot() : 0;
        refresh();
        int count = page == MenuModule.INVENTORY ? 37 : page == MenuModule.EQUIPMENT ? 41 : 0;
        for (int i = 0; i < count; i++) {
            int index = i;
            var slot = new FloatingItemSlot(() -> selectedItem = index);
            if (page == MenuModule.INVENTORY && player != null) {
                int containerSlot = i == 36 ? 40 : i < 27 ? i + 9 : i - 27;
                slot.bindInventory(inventory, player.inventoryMenu.findSlot(player.getInventory(), containerSlot).orElse(-1));
            }
            slots.add(slot);
            add.accept(slot);
        }
    }

    public void refresh() {
        var player = Minecraft.getInstance().player;
        if (page == MenuModule.EQUIPMENT && player != null) weapons = CombatItems.scan(player);
        if (page == MenuModule.EQUIPMENT) selectedItem = Math.min(selectedItem, Math.max(0, weapons.size() - 1));
    }

    private CombatItems.Entry entry(int index) {
        var player = Minecraft.getInstance().player;
        if (player == null) return new CombatItems.Entry(ItemStack.EMPTY, 0, null);
        if (page == MenuModule.EQUIPMENT) return index < weapons.size() ? weapons.get(index)
                : new CombatItems.Entry(ItemStack.EMPTY, 0, null);
        if (index == 36) return new CombatItems.Entry(player.getOffhandItem(), -1, EquipmentSlot.OFFHAND);
        int inventory = index < 27 ? index + 9 : index - 27;
        return new CombatItems.Entry(player.getInventory().getItem(inventory), inventory, null);
    }

    public void place(MenuProjection projection, double opacity, boolean interactive) {
        var player = Minecraft.getInstance().player;
        if (armor != null) armor.place(projection, opacity, interactive, page == MenuModule.INVENTORY);
        if (crafting != null) crafting.place(projection, opacity, interactive, page == MenuModule.INVENTORY);
        for (int i = 0; i < slots.size(); i++) {
            var slot = slots.get(i);
            if (page == MenuModule.EQUIPMENT && i >= weapons.size()) {
                slot.visible = false; slot.active = false;
                continue;
            }
            double x, y;
            if (page == MenuModule.INVENTORY && i >= 27) {
                x = i == 36 ? 274 : 58 + (i - 27) * 22;
                y = 8;
            } else {
                x = 58 + (i % 9) * 22;
                y = -78 + (i / 9) * 22;
            }
            var entry = entry(i);
            boolean held = player != null && entry.equipmentSlot() == null
                    && entry.inventorySlot() == player.getInventory().getSelectedSlot();
            slot.place(projection, x, y, 20, entry.stack(), opacity, selectedItem == i, held, interactive);
        }
    }

    boolean scroll(double x,double y,double amount,MenuProjection p) {
        return page==MenuModule.EQUIPMENT && enchantments.scroll(x,y,amount,p);
    }

    boolean detailsModal(){return page==MenuModule.EQUIPMENT&&enchantments.modal();}
    void readingOverlay(GuiGraphicsExtractor g){if(page==MenuModule.EQUIPMENT)enchantments.readingOverlay(g);}

    boolean detailClick(double x,double y,MenuProjection p) { return page==MenuModule.EQUIPMENT && enchantments.click(x,y,p); }

    boolean detailKey(net.minecraft.client.input.KeyEvent event) { return page==MenuModule.EQUIPMENT && enchantments.keyPressed(event); }

    void craftingPanel(GuiGraphicsExtractor g, MenuProjection p, double reveal) {
        if (crafting != null && page == MenuModule.INVENTORY) crafting.render(g, p, reveal);
        if (page == MenuModule.EQUIPMENT) enchantments.render(g,p,entry(selectedItem).stack(),reveal,entry(selectedItem).location().getString());
    }

    public void portrait(GuiGraphicsExtractor g, MenuProjection p, int mouseX, int mouseY, double opacity) {
        Player player = Minecraft.getInstance().player;
        if (player == null || opacity < 0.01) return;
        panel(g, p, -198, -124, 160, 252, opacity);
        line(g, p, player.getName().getString(), -186, -110, 136, ThemePalette.ink(), opacity);
        FloatingDraw.rect(g, p, -186, -96, 136, 0.8, color(FloatingDraw.alpha(ThemePalette.line(), .44), opacity));
        if (opacity > 0.35) {
            var box = FloatingDraw.bounds(p, -184, -92, 132, 148);
            int scale = Math.max(3, (int) (box.height() / 2.05));
            InventoryScreen.extractEntityInInventoryFollowsMouse(g, box.left(), box.top(),
                    box.left() + box.width(), box.top() + box.height(), scale, 0,
                    mouseX, mouseY, player);
        }
        FloatingDraw.rect(g, p, -186, 59, 136, 0.8, color(FloatingDraw.alpha(ThemePalette.line(), .44), opacity));
        stat(g, p, "hp", (int) Math.ceil(player.getHealth()) + "/" + (int) Math.ceil(player.getMaxHealth()), -186, 68, opacity);
        stat(g, p, "armor", Integer.toString(player.getArmorValue()), -115, 68, opacity);
        // Attack damage is not a reliably synchronized client attribute; show the equipped item's base value.
        stat(g, p, "attack", CombatItems.number(CombatItems.stats(player, player.getMainHandItem()).damage()), -186, 87, opacity);
        stat(g, p, "speed", CombatItems.number(player.getAttributeValue(Attributes.ATTACK_SPEED)), -115, 87, opacity);
        stat(g, p, "toughness", CombatItems.number(player.getAttributeValue(Attributes.ARMOR_TOUGHNESS)), -186, 106, opacity);
        stat(g, p, "movement", CombatItems.number(player.getAttributeValue(Attributes.MOVEMENT_SPEED)), -115, 106, opacity);
    }

    public static void panel(GuiGraphicsExtractor g, MenuProjection p, double x, double y,
                             double width, double height, double opacity) {
        FloatingDraw.rect(g, p, x + 3, y + 3, width, height, color(0x22000000, opacity));
        FloatingDraw.rect(g, p, x, y, width, height, color(ThemePalette.background(), opacity));
        FloatingDraw.rect(g, p, x, y, width, 1.5, color(ThemePalette.edge(), opacity));
        FloatingDraw.rect(g, p, x, y, 2, 31, color(ThemePalette.accent(), opacity));
    }

    public void contents(GuiGraphicsExtractor g, MenuProjection p, double opacity) {
        if (page != MenuModule.INVENTORY && page != MenuModule.EQUIPMENT) return;
        String title = Component.translatable(page == MenuModule.INVENTORY ? "root.saoui.inventory" : "root.saoui.equipment").getString();
        line(g, p, title, 58, -110, 180, ThemePalette.ink(), opacity);
        line(g, p, Component.translatable(page == MenuModule.INVENTORY ? "item.saoui.pack_header" : "item.saoui.combat_header",
                weapons.size()).getString(), 58, -94, page == MenuModule.INVENTORY ? 198 : 240, ThemePalette.muted(), opacity);
        if (page == MenuModule.INVENTORY) {
            if (SaoUiClient.config().armorSlotsVisible)
                line(g, p, Component.translatable("stats.saoui.armor").getString(), 266, -109, 44, ThemePalette.muted(), opacity);
            line(g, p, Component.translatable("item.saoui.hotbar_header").getString(), 58, -5, 190, ThemePalette.muted(), opacity);
            line(g, p, Component.translatable("item.saoui.offhand").getString(), 266, -5, 44, ThemePalette.muted(), opacity);
        } else if (weapons.isEmpty()) {
            line(g, p, Component.translatable("item.saoui.no_weapons").getString(), 58, -49, 238, ThemePalette.muted(), opacity);
        }
        line(g, p, Component.translatable(page == MenuModule.INVENTORY ? "item.saoui.inspect_note" : "item.saoui.base_note").getString(),
                58, 33, 238, ThemePalette.muted(), opacity);
        details(g, p, opacity);
    }

    private void details(GuiGraphicsExtractor g, MenuProjection p, double opacity) {
        var player = Minecraft.getInstance().player;
        if (player == null) return;
        var entry = entry(selectedItem);
        ItemStack stack = entry.stack();
        FloatingDraw.rect(g, p, 56, 45, 242, 57, color(FloatingDraw.alpha(ThemePalette.line(), .44), opacity));
        if (stack.isEmpty()) {
            line(g, p, Component.translatable("item.saoui.select_hint").getString(), 62, 50, 230, ThemePalette.ink(), opacity);
            return;
        }
        line(g, p, stack.getHoverName().getString(), 62, 49, 230, ThemePalette.ink(), opacity);
        line(g, p, ItemDetails.summary(player,stack).getString(), 62, 63, 230, ThemePalette.ink(), opacity);
        String durability = stack.isDamageableItem()
                ? (stack.getMaxDamage() - stack.getDamageValue()) + "/" + stack.getMaxDamage()
                : Component.translatable("item.saoui.not_applicable").getString();
        line(g, p, Component.translatable("item.saoui.durability", durability, stack.getCount()).getString(),
                62, 77, 230, ThemePalette.ink(), opacity);
        line(g, p, Component.translatable("item.saoui.typed_tail", entry.location(),
                (stack.getEnchantments().size()+stack.getOrDefault(net.minecraft.core.component.DataComponents.STORED_ENCHANTMENTS,net.minecraft.world.item.enchantment.ItemEnchantments.EMPTY).size())).getString(),
                62, 91, 230, ThemePalette.ink(), opacity);
    }

    private static void stat(GuiGraphicsExtractor g, MenuProjection p, String key, String value,
                              double x, double y, double opacity) {
        line(g, p, Component.translatable("stats.saoui." + key).getString() + " " + value,
                x, y, 67, ThemePalette.ink(), opacity);
    }

    private static void line(GuiGraphicsExtractor g, MenuProjection p, String text, double x, double y,
                              int maxWidth, int color, double opacity) {
        FloatingDraw.text(g, p, Minecraft.getInstance().font.plainSubstrByWidth(text, maxWidth),
                x, y, FloatingDraw.alpha(color, opacity));
    }

    private static int color(int color, double opacity) { return FloatingDraw.alpha(color, opacity); }
}
