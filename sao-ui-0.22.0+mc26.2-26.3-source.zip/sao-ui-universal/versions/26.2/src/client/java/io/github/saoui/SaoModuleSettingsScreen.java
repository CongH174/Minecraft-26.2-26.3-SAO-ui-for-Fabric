package io.github.saoui;

import java.io.IOException;
import java.util.Collections;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Editable draft; Save applies the layout and Cancel leaves the active layout alone. */
public final class SaoModuleSettingsScreen extends Screen {
    private final Screen parent;
    private final java.util.function.Consumer<SaoConfig> apply;
    private SaoConfig draft;
    private boolean saveFailed;
    private int left, top, panelWidth, rowHeight, rowStep, rowsTop, footer;

    public SaoModuleSettingsScreen(Screen parent) {
        this(parent,SaoUiClient.config(),null);
    }

    public SaoModuleSettingsScreen(Screen parent,SaoConfig initial,java.util.function.Consumer<SaoConfig> apply) {
        super(Component.translatable("screen.saoui.modules"));
        this.apply=apply;
        this.parent = parent;
        draft = initial.copy().validated();
    }

    @Override protected void init() {
        panelWidth = Math.min(360, width - 24);
        left = (width - panelWidth) / 2;
        rowHeight = Math.clamp((height - 108) / 4 - 4, 16, 24);
        rowStep = rowHeight + 4;
        int panelHeight = 58 + rowStep * (MenuModule.values().length + 1) + rowHeight;
        top = Math.max(8, (height - panelHeight) / 2);
        rowsTop = top + 49;
        for (int i = 0; i < draft.moduleOrder.size(); i++) addRow(i);
        footer = rowsTop + draft.moduleOrder.size() * rowStep + 9;
        int half = (panelWidth - 8) / 2;
        addRenderableWidget(new SaoButton(left, footer, half, rowHeight, Component.translatable("gui.done"), null, this::save));
        addRenderableWidget(new SaoButton(left + half + 8, footer, half, rowHeight, Component.translatable("gui.cancel"), null, this::onClose));
        addRenderableWidget(new SaoButton(left, footer + rowStep, panelWidth, rowHeight,
                Component.translatable("settings.saoui.modules_reset"), null, () -> { draft.resetModules(); rebuildWidgets(); }));
    }

    private void addRow(int index) {
        var module = MenuModule.fromId(draft.moduleOrder.get(index));
        int y = rowsTop + index * rowStep, homeX = left + panelWidth - 70;
        int downX = homeX - 30, upX = downX - 30, enabledX = upX - 58;
        var toggle = addRenderableWidget(new SaoButton(enabledX, y, 54, rowHeight,
                Component.translatable("settings.saoui.module_toggle", Component.translatable(module.titleKey()),
                        Component.translatable(draft.moduleEnabled(module) ? "settings.saoui.visible" : "settings.saoui.hidden")),
                Component.translatable(draft.moduleEnabled(module) ? "settings.saoui.visible" : "settings.saoui.hidden"), null, () -> {
                    if (!draft.hiddenModules.remove(module.id())) draft.hiddenModules.add(module.id());
                    draft.validated();
                    rebuildWidgets();
                }));
        toggle.active = module.canHide();
        var up = addRenderableWidget(new SaoButton(upX, y, 26, rowHeight,
                Component.translatable("settings.saoui.module_up", Component.translatable(module.titleKey())), Component.literal("↑"), null,
                () -> { Collections.swap(draft.moduleOrder, index, index - 1); rebuildWidgets(); }));
        up.active = index > 0;
        var down = addRenderableWidget(new SaoButton(downX, y, 26, rowHeight,
                Component.translatable("settings.saoui.module_down", Component.translatable(module.titleKey())), Component.literal("↓"), null,
                () -> { Collections.swap(draft.moduleOrder, index, index + 1); rebuildWidgets(); }));
        down.active = index < draft.moduleOrder.size() - 1;
        boolean home = module.id().equals(draft.homeModule);
        var homeButton = addRenderableWidget(new SaoButton(homeX, y, 70, rowHeight,
                Component.translatable(home ? "settings.saoui.module_home_selected" : "settings.saoui.module_home",
                        Component.translatable(module.titleKey())), Component.translatable(home ? "settings.saoui.home_badge" : "settings.saoui.set_home"), null,
                () -> { draft.homeModule = module.id(); rebuildWidgets(); }));
        homeButton.active = draft.moduleEnabled(module) && !home;
    }

    private void save() {
        try {
            if(apply!=null)apply.accept(draft.copy());else SaoUiClient.saveConfig(draft);
            onClose();
        } catch (IOException error) {
            saveFailed = true;
            SaoUiClient.LOGGER.error("Cannot save SAO menu layout", error);
        }
    }

    @Override public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xE8101820);
        g.text(font, title, left, top, 0xFFF3A72E, true);
        g.text(font, Component.translatable("settings.saoui.home_current", Component.translatable(draft.home().titleKey())),
                left, top + 17, 0xFFE4E9E7, false);
        g.text(font, font.plainSubstrByWidth(Component.translatable("settings.saoui.modules_hint").getString(), panelWidth),
                left, top + 32, 0xFFA7B8B1, false);
        for (int i = 0; i < draft.moduleOrder.size(); i++) {
            var module = MenuModule.fromId(draft.moduleOrder.get(i));
            int y = rowsTop + i * rowStep;
            int color = draft.moduleEnabled(module) ? 0xFFE4E9E7 : 0xFF82918A;
            UiSprites.icon(g, SaoUiClient.id("textures/sao/menu/icons/" + module.icon() + ".png"),
                    left, y + (rowHeight - 16) / 2, 16);
            g.text(font, font.plainSubstrByWidth((i + 1) + ". " + Component.translatable(module.titleKey()).getString(),
                    panelWidth - 218), left + 21, y + (rowHeight - 9) / 2, color, false);
        }
        if (saveFailed) g.text(font, Component.translatable("settings.saoui.save_failed"),
                left, Math.min(height - 10, footer + rowStep * 2), 0xFFFF7777, false);
        super.extractRenderState(g, mouseX, mouseY, delta);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
}
