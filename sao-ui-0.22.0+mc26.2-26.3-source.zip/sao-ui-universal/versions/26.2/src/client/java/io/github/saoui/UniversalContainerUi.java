package io.github.saoui;

import io.github.saoui.mixin.ContainerScreenAccessor;
import io.github.saoui.mixin.RecipeBookAccessor;
import io.github.saoui.mixin.RecipeScreenAccessor;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Shared SAO canvas for player, creative, entity and unregistered/modded container menus.
 * Native geometry, menu IDs, widgets and packet callbacks remain authoritative. */
public final class UniversalContainerUi {
    private static final Set<Screen> SCREENS = Collections.newSetFromMap(new WeakHashMap<>());
    static void attach(Screen screen) { SCREENS.add(screen); }
    public static boolean managed(Screen screen) { return SCREENS.contains(screen); }

    private static boolean visibleSlot(Screen screen, net.minecraft.world.inventory.Slot slot) {
        // Creative inventory hides inactive tab slots at (-2000,-2000) while isActive() stays true.
        return slot.isActive() && (!(screen instanceof net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen)
                || slot.x >= 0 && slot.y >= 0);
    }
    static FlatContainerUi.Bounds contentBounds(Screen screen) {
        var a = (ContainerScreenAccessor)screen;
        int x = a.saoui$left() - 6, y = a.saoui$top() - 6;
        int right = a.saoui$left() + a.saoui$width() + 6, bottom = a.saoui$top() + a.saoui$height() + 6;
        for (var slot : ((AbstractContainerScreen<?>)screen).getMenu().slots) if (visibleSlot(screen, slot) && !ContainerCraftingUi.extraSlot((AbstractContainerScreen<?>)screen,slot.index)) {
            x = Math.min(x, a.saoui$left() + slot.x - 3); y = Math.min(y, a.saoui$top() + slot.y - 3);
            right = Math.max(right, a.saoui$left() + slot.x + 19); bottom = Math.max(bottom, a.saoui$top() + slot.y + 19);
        }
        if (screen instanceof net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen) {
            // Tab hit regions are rendered directly, rather than registered as widgets.
            y = Math.min(y, a.saoui$top() - 34);
            bottom = Math.max(bottom, a.saoui$top() + a.saoui$height() + 32);
        }
        for (var child : screen.children()) if (child instanceof AbstractWidget w && w.visible) {
            x = Math.min(x, w.getX() - 3); y = Math.min(y, w.getY() - 3);
            right = Math.max(right, w.getRight() + 3); bottom = Math.max(bottom, w.getBottom() + 3);
        }
        return new FlatContainerUi.Bounds(x, y, right - x, bottom - y);
    }
    static FlatContainerUi.Bounds bounds(Screen screen) {
        var b = contentBounds(screen);
        int x = b.x(), y = b.y() - 46, right = b.x() + b.width(), bottom = b.y() + b.height();
        if (screen instanceof RecipeScreenAccessor recipe && recipe.saoui$book().isVisible()) {
            var book = (RecipeBookAccessor)recipe.saoui$book();
            x = Math.min(x, book.saoui$x() - 30); y = Math.min(y, book.saoui$y() - 4);
            right = Math.max(right, book.saoui$x() + 150); bottom = Math.max(bottom, book.saoui$y() + 170);
        }
        return new FlatContainerUi.Bounds(x, y, right - x, bottom - y);
    }
    static void render(Screen screen, GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        var a = (ContainerScreenAccessor)screen; var container = (AbstractContainerScreen<?>)screen;
        var b = contentBounds(screen);
        FlatContainerUi.panel(g, b.x(), b.y() - 46, b.width(), b.height() + 46, screen.getTitle().getString().isBlank()
                        ? Component.translatable("saoui.container.creative").getString() : screen.getTitle().getString(),
                Component.translatable("saoui.container.universal").getString(), "items");
        var hovered = a.saoui$findSlot(mouseX, mouseY);
        if (hovered != a.saoui$hovered() && a.saoui$hovered() != null) a.saoui$stopHover(a.saoui$hovered());
        a.saoui$hovered(hovered);
        for (var slot : container.getMenu().slots) if (visibleSlot(screen, slot))
            FlatContainerUi.cell(g, a.saoui$left() + slot.x - 2, a.saoui$top() + slot.y - 2, 20, 20, slot == hovered, false);
        ContainerCraftingUi.render(screen,g);
        FlatContainerUi.nativeDetails(screen, g, mouseX, mouseY, delta, true);
        FlatContainerUi.slotsAndCursor(screen, g, mouseX, mouseY);
    }
    static boolean sprite(GuiGraphicsExtractor g, Identifier id, int x, int y, int w, int h) {
        String p = id.getPath();
        if (p.contains("background")) return true;
        if (p.contains("tab") || p.contains("slot") || p.contains("button") || p.contains("text_field")) {
            FlatContainerUi.cell(g, x, y, w, h, p.contains("selected") && !p.contains("unselected") || p.contains("highlighted"), p.contains("disabled"));
            return true;
        }
        return false;
    }
    public static int textColor(int color) {
        if (!FlatContainerUi.nativePass() || !BlockFloatingUi.active(Minecraft.getInstance().gui.screen())) return color;
        int r = color >> 16 & 255, green = color >> 8 & 255, blue = color & 255;
        return Math.max(r, Math.max(green, blue)) - Math.min(r, Math.min(green, blue)) < 28
                ? color & 0xFF000000 | ThemePalette.ink() & 0x00FFFFFF : color;
    }
    private UniversalContainerUi() {}
}
