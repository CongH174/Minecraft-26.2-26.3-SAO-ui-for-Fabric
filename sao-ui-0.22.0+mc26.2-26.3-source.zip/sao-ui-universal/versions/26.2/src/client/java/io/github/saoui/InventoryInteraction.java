package io.github.saoui;

import java.util.Arrays;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.world.inventory.InventoryMenu;

/** Vanilla inventory input/state machine, with hit testing on the floating surface. */
final class InventoryInteraction extends AbstractContainerScreen<InventoryMenu> {
    private final PlayerPanels panels;
    private final Runnable close;

    InventoryInteraction(PlayerPanels panels, Runnable close) {
        super(Minecraft.getInstance().player.inventoryMenu,
                Minecraft.getInstance().player.getInventory(), Component.empty());
        this.panels = panels;
        this.close = close;
    }

    @Override protected void init() { super.init(); leftPos = topPos = 0; }

    boolean available() {
        return minecraft.player != null && minecraft.gameMode != null
                && !minecraft.player.isSpectator() && minecraft.player.containerMenu == menu;
    }

    void pointer(double x, double y) {
        int id = panels.inventorySlotAt(x, y);
        hoveredSlot = id < 0 ? null : menu.getSlot(id);
    }

    @Override protected boolean isHovering(int x, int y, int width, int height, double mouseX, double mouseY) {
        int id = panels.inventorySlotAt(mouseX, mouseY);
        if (id < 0) return false;
        var slot = menu.getSlot(id);
        return slot.x == x && slot.y == y;
    }

    @Override protected boolean hasClickedOutside(double x, double y, int left, int top) {
        // Empty space belongs to the floating menu. Dropping remains an explicit Q action.
        return false;
    }

    void cancelGesture() {
        isQuickCrafting = false;
        quickCraftSlots.clear();
        hoveredSlot = null;
    }

    boolean handleKey(KeyEvent event) {
        boolean shortcut = minecraft.options.keyInventory.matches(event)
                || hoveredSlot != null && (minecraft.options.keyDrop.matches(event)
                || minecraft.options.keyPickItem.matches(event)
                || minecraft.options.keySwapOffhand.matches(event)
                || Arrays.stream(minecraft.options.keyHotbarSlots).anyMatch(key -> key.matches(event)));
        return super.keyPressed(event) || shortcut;
    }

    void extractProjectedSlot(GuiGraphicsExtractor g, MenuProjection projection, int id, double x, double y) {
        var slot = menu.getSlot(id);
        g.pose().pushMatrix();
        FloatingDraw.tangent(g, projection, x, y);
        g.pose().translate(-slot.x, -slot.y);
        super.extractSlot(g, slot, 0, 0);
        g.pose().popMatrix();
    }

    void finish() {
        cancelGesture();
        if (minecraft.player != null && minecraft.player.containerMenu == menu) {
            // Send the standard close packet without replacing the next screen during its initialization.
            minecraft.player.connection.send(new ServerboundContainerClosePacket(menu.containerId));
            super.removed();
        }
    }

    @Override public void onClose() { close.run(); }
}
