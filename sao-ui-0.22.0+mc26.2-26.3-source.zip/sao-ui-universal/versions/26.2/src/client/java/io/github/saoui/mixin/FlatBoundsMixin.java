package io.github.saoui.mixin;

import io.github.saoui.FlatContainerUi;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractRecipeBookScreen;
import net.minecraft.client.gui.screens.inventory.LoomScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractRecipeBookScreen.class, LoomScreen.class})
public abstract class FlatBoundsMixin {
    @Inject(method = "hasClickedOutside", at = @At("HEAD"), cancellable = true)
    private void saoui$bounds(double x, double y, int left, int top, CallbackInfoReturnable<Boolean> ci) {
        Screen screen = (Screen)(Object)this;
        if (FlatContainerUi.skinned(screen)) ci.setReturnValue(!FlatContainerUi.bounds(screen).contains(x, y));
    }
}
