package io.github.saoui.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractRecipeBookScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(AbstractRecipeBookScreen.class)
public interface RecipeScreenAccessor {
    @Accessor("recipeBookComponent") RecipeBookComponent<?> saoui$book();
    @Accessor("widthTooNarrow") void saoui$narrow(boolean value);
}
