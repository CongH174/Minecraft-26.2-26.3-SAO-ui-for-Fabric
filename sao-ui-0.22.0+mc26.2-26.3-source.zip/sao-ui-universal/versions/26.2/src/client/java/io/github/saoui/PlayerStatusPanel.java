package io.github.saoui;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** A live status readout of native, client-synchronized player data. */
final class PlayerStatusPanel {
    record Durability(ItemStack stack,int remaining,int maximum) { int percent(){return maximum==0?100:(int)Math.ceil(100.0*remaining/maximum);} }
    static int occupied(Player player){int used=0;for(int i=0;i<36;i++)if(!player.getInventory().getItem(i).isEmpty())used++;return used;}
    static Durability weakest(Player player){
        Durability result=new Durability(ItemStack.EMPTY,0,0);
        for(var slot:List.of(EquipmentSlot.MAINHAND,EquipmentSlot.OFFHAND,EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET)){
            var stack=player.getItemBySlot(slot);if(!stack.isDamageableItem())continue;
            var next=new Durability(stack,Math.max(0,stack.getMaxDamage()-stack.getDamageValue()),stack.getMaxDamage());
            if(result.maximum()==0||(double)next.remaining()/next.maximum()<(double)result.remaining()/result.maximum())result=next;
        }return result;
    }
    static void render(GuiGraphicsExtractor g,MenuProjection p,double opacity){
        var mc=Minecraft.getInstance();var player=mc.player;if(player==null)return;
        int ink=ThemePalette.ink(),muted=ThemePalette.muted(),accent=ThemePalette.accent();
        line(g,p,tr("profile.saoui.title"),58,-110,158,ink,opacity);
        String mode=mc.gameMode==null?"":mc.gameMode.getPlayerMode().getLongDisplayName().getString();
        right(g,p,mode,296,-110,76,accent,opacity);
        line(g,p,player.getName().getString(),58,-95,238,muted,opacity);
        track(g,p,tr("profile.saoui.health"),number(player.getHealth())+" / "+number(player.getMaxHealth())+(player.getAbsorptionAmount()>0?" +"+number(player.getAbsorptionAmount()):""),-77,player.getHealth()/player.getMaxHealth(),0xFF73B945,opacity);
        track(g,p,tr("profile.saoui.food"),player.getFoodData().getFoodLevel()+" / 20",-53,player.getFoodData().getFoodLevel()/20.0,0xFFE7A15A,opacity);
        track(g,p,tr("profile.saoui.experience",player.experienceLevel),tr("profile.saoui.next_xp",Math.max(0,(int)Math.ceil((1-player.experienceProgress)*player.getXpNeededForNextLevel()))),-29,player.experienceProgress,0xFF72C4D5,opacity);
        int used=occupied(player);
        line(g,p,tr("profile.saoui.pack"),58,-3,95,muted,opacity);
        right(g,p,tr("profile.saoui.pack_value",used,36-used),296,-3,145,ink,opacity);
        FloatingDraw.rect(g,p,58,11,238,.7,FloatingDraw.alpha(FloatingDraw.alpha(ThemePalette.line(),.4),opacity));
        var wear=weakest(player);
        line(g,p,tr("profile.saoui.durability"),58,20,146,muted,opacity);
        right(g,p,wear.maximum()==0?"—":wear.percent()+"%",296,20,70,wear.percent()<20?0xFFCF694C:ink,opacity);
        line(g,p,wear.maximum()==0?tr("profile.saoui.no_durability"):wear.stack().getHoverName().getString()+"  "+wear.remaining()+" / "+wear.maximum(),58,33,238,ink,opacity);
        var effects=player.getActiveEffects().stream().sorted(Comparator.comparing(effect->effect.getEffect().value().getDisplayName().getString())).toList();
        line(g,p,tr("profile.saoui.effects",effects.size()),58,50,238,muted,opacity);
        if(effects.isEmpty())line(g,p,tr("profile.saoui.normal"),58,63,238,ink,opacity);
        else for(int i=0;i<Math.min(2,effects.size());i++){
            var effect=effects.get(i);String duration=effect.isInfiniteDuration()?"∞":String.format(Locale.ROOT,"%d:%02d",Math.max(0,effect.getDuration()/20)/60,Math.max(0,effect.getDuration()/20)%60);
            String extra=i==1&&effects.size()>2?"  +"+(effects.size()-2):"";
            line(g,p,effect.getEffect().value().getDisplayName().getString()+(effect.getAmplifier()>0?" "+(effect.getAmplifier()+1):"")+"  "+duration+extra,58,63+i*12,238,ink,opacity);
        }
        line(g,p,tr("profile.saoui.position",player.blockPosition().getX(),player.blockPosition().getY(),player.blockPosition().getZ()),58,88,238,muted,opacity);
    }
    private static String number(float value){return CombatItems.number(value);}
    private static String tr(String key,Object...args){return Component.translatable(key,args).getString();}
    private static void track(GuiGraphicsExtractor g,MenuProjection p,String label,String value,int y,double fill,int tint,double opacity){
        line(g,p,label,58,y,124,ThemePalette.ink(),opacity);right(g,p,value,296,y,116,ThemePalette.ink(),opacity);
        FloatingDraw.rect(g,p,58,y+13,238,4,FloatingDraw.alpha(0x302D4651,opacity));
        FloatingDraw.rect(g,p,58,y+13,238*Math.clamp(fill,0,1),4,FloatingDraw.alpha(tint,opacity));
        for(int i=1;i<10;i++)FloatingDraw.rect(g,p,58+i*23.8,y+13,.7,4,FloatingDraw.alpha(ThemePalette.background(),opacity));
    }
    private static String fit(String text,int width){var font=Minecraft.getInstance().font;return font.width(text)<=width?text:font.plainSubstrByWidth(text,Math.max(0,width-font.width("…")))+"…";}
    private static void line(GuiGraphicsExtractor g,MenuProjection p,String text,double x,double y,int width,int color,double opacity){FloatingDraw.text(g,p,fit(text,width),x,y,FloatingDraw.alpha(color,opacity));}
    private static void right(GuiGraphicsExtractor g,MenuProjection p,String text,double x,double y,int width,int color,double opacity){String fitted=fit(text,width);FloatingDraw.text(g,p,fitted,x-Minecraft.getInstance().font.width(fitted),y,FloatingDraw.alpha(color,opacity));}
    private PlayerStatusPanel(){}
}
