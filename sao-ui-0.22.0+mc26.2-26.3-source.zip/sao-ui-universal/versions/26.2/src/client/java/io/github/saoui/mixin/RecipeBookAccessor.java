package io.github.saoui.mixin;

import java.util.List;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.recipebook.RecipeBookTabButton;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(RecipeBookComponent.class)
public interface RecipeBookAccessor {
    @Invoker("initVisuals") void saoui$layout();
    @Invoker("getXOrigin") int saoui$x();
    @Invoker("getYOrigin") int saoui$y();
    @Accessor("tabButtons") List<RecipeBookTabButton> saoui$tabs();
    @Accessor("selectedTab") RecipeBookTabButton saoui$selected();
    @Accessor("searchBox") EditBox saoui$search();
}
