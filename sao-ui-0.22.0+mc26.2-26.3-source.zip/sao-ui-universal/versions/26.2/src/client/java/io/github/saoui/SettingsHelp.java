package io.github.saoui;

import java.time.Duration;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;

/** Explanations are independent language entries, never a copy of the option's value label. */
final class SettingsHelp {
    static boolean attach(AbstractWidget widget){
        if(widget.getMessage().getContents() instanceof TranslatableContents text)return attach(widget,text.getKey(),text.getArgs());
        return false;
    }
    static boolean attach(AbstractWidget widget,String key,Object...args){
        String helpKey=key+".help";
        if(!Language.getInstance().has(helpKey))return false;
        widget.setTooltip(Tooltip.create(Component.translatable(helpKey,args)));
        widget.setTooltipDelay(Duration.ofMillis(350));
        return true;
    }
    private SettingsHelp(){}
}
