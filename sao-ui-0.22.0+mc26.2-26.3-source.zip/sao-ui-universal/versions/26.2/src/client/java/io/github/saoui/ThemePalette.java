package io.github.saoui;

/** Small cached palette shared by all panel/slot renderers. No per-frame color parsing. */
public final class ThemePalette {
    private static int lastBackground=-1,lastAccent=-1,lastFont=-1;
    private static int background,accent,ink,muted,line,cell,selected,disabled,edge;
    private static void update() {
        var t=SaoUiClient.config().theme;
        if(lastBackground==t.background && lastAccent==t.accent && lastFont==(t.customFont?t.font:-1)) return;
        lastBackground=t.background; lastAccent=t.accent; lastFont=t.customFont?t.font:-1;
        background=0xF2000000|t.background; accent=0xFF000000|t.accent;
        boolean original=t.background==UiTheme.DEFAULT_BACKGROUND;
        ink=original?0xFF404443:UiTheme.text(t.background);
        if(t.customFont) ink=0xFF000000|t.font;
        muted=t.customFont?ink:original?0xFF748077:UiTheme.mix(t.background,ink,.78);
        line=original?0xFFB6C2B8:UiTheme.mix(t.background,ink,.30);
        cell=original?0xFFF3F5EE:UiTheme.mix(t.background,ink,.08);
        disabled=UiTheme.mix(t.background,ink,.16);
        edge=original?0xFFF8FAF6:UiTheme.mix(t.background,ink,.12);
        selected=UiTheme.mix(t.background,t.accent,.30);
    }
    public static int background(){update();return background;}
    public static int accent(){update();return accent;}
    public static int ink(){update();return ink;}
    public static int muted(){update();return muted;}
    public static int line(){update();return line;}
    public static int cell(){update();return cell;}
    public static int selected(){update();return selected;}
    public static int disabled(){update();return disabled;}
    public static int edge(){update();return edge;}
    public static int onAccent(){return font(UiTheme.text(accent()));}
    public static int font(int fallback){var t=SaoUiClient.config().theme;return t.customFont?(fallback & 0xFF000000)|t.font:fallback;}
    private ThemePalette(){}
}
