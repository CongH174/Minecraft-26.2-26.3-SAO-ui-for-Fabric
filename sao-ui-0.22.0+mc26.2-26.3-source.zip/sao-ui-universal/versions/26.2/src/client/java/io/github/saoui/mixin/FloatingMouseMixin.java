package io.github.saoui.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.saoui.BlockFloatingUi;
import net.minecraft.client.MouseHandler;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(MouseHandler.class)
public abstract class FloatingMouseMixin {
    @WrapOperation(method = "onButton", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseClicked(Lnet/minecraft/client/input/MouseButtonEvent;Z)Z"))
    private boolean saoui$click(Screen screen, MouseButtonEvent event, boolean twice, Operation<Boolean> original) {
        if (!BlockFloatingUi.ready(screen)) return true;
        var pointer = BlockFloatingUi.pointer(screen, event);
        BlockFloatingUi.holdPointer(screen, event.button(), true);
        try { return original.call(screen, pointer, twice); }
        catch (Throwable error) { BlockFloatingUi.holdPointer(screen, event.button(), false); throw error; }
    }

    @WrapOperation(method = "onButton", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseReleased(Lnet/minecraft/client/input/MouseButtonEvent;)Z"))
    private boolean saoui$release(Screen screen, MouseButtonEvent event, Operation<Boolean> original) {
        try { return !BlockFloatingUi.ready(screen) || original.call(screen, BlockFloatingUi.pointer(screen, event)); }
        finally { BlockFloatingUi.holdPointer(screen, event.button(), false); }
    }

    @WrapOperation(method = "handleAccumulatedMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseDragged(Lnet/minecraft/client/input/MouseButtonEvent;DD)Z"))
    private boolean saoui$drag(Screen screen, MouseButtonEvent event, double dx, double dy, Operation<Boolean> original) {
        if (!BlockFloatingUi.ready(screen)) return true;
        double scale = BlockFloatingUi.active(screen) ? BlockFloatingUi.frame(screen).scale() : 1;
        return original.call(screen, BlockFloatingUi.pointer(screen, event), dx / scale, dy / scale);
    }

    @WrapOperation(method = "handleAccumulatedMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseMoved(DD)V"))
    private void saoui$move(Screen screen, double x, double y, Operation<Void> original) {
        if (BlockFloatingUi.active(screen)) {
            var frame = BlockFloatingUi.frame(screen);
            x = frame.localX(x); y = frame.localY(y);
        }
        original.call(screen, x, y);
    }

    @WrapOperation(method = "onScroll", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;mouseScrolled(DDDD)Z"))
    private boolean saoui$scroll(Screen screen, double x, double y, double dx, double dy, Operation<Boolean> original) {
        if (!BlockFloatingUi.ready(screen)) return true;
        if (BlockFloatingUi.active(screen)) {
            var frame = BlockFloatingUi.frame(screen);
            x = frame.localX(x); y = frame.localY(y);
        }
        return original.call(screen, x, y, dx, dy);
    }
}
