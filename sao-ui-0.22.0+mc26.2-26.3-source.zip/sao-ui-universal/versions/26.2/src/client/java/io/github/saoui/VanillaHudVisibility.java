package io.github.saoui;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.Identifier;

/** Only the five requested controls are optional. The hotbar and all unrelated HUDs stay native. */
final class VanillaHudVisibility {
    static boolean visible(Identifier element) {
        var options = SaoUiClient.config().hud;
        if (element.equals(VanillaHudElements.HEALTH_BAR)) return !options.hideVanillaHealth;
        if (element.equals(VanillaHudElements.FOOD_BAR)) return !options.hideVanillaHunger;
        if (element.equals(VanillaHudElements.ARMOR_BAR)) return !options.hideVanillaArmor;
        if (element.equals(VanillaHudElements.EXPERIENCE_LEVEL)) return !options.hideVanillaExperience;
        if (element.equals(VanillaHudElements.CROSSHAIR)) return !options.hideVanillaCrosshair;
        return true;
    }
    static void register() {
        for (var id : new Identifier[] {VanillaHudElements.HEALTH_BAR, VanillaHudElements.FOOD_BAR,
                VanillaHudElements.ARMOR_BAR, VanillaHudElements.EXPERIENCE_LEVEL, VanillaHudElements.CROSSHAIR}) {
            HudElementRegistry.replaceElement(id, original -> (graphics, delta) -> {
                if (visible(id)) original.extractRenderState(graphics, delta);
            });
        }
    }
    private VanillaHudVisibility() {}
}
