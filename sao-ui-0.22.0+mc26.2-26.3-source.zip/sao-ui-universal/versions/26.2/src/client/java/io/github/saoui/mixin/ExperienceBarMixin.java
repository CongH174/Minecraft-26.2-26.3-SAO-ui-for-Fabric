package io.github.saoui.mixin;

import io.github.saoui.SaoUiClient;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.contextualbar.ExperienceBar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Scope XP suppression to XP, preserving contextual locator and mount jump bars. */
@Mixin(ExperienceBar.class)
public abstract class ExperienceBarMixin {
    @Inject(method = {"extractBackground", "extractRenderState"}, at = @At("HEAD"), cancellable = true)
    private void saoui$experience(GuiGraphicsExtractor graphics, DeltaTracker delta, CallbackInfo ci) {
        if (SaoUiClient.config().hud.hideVanillaExperience) ci.cancel();
    }
}
