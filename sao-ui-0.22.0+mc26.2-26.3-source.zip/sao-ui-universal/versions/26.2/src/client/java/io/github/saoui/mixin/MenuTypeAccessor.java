package io.github.saoui.mixin;

import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Inventory and custom menus may deliberately have no registered type. getType() throws for them. */
@Mixin(AbstractContainerMenu.class)
public interface MenuTypeAccessor {
    @Accessor("menuType") MenuType<?> saoui$type();
}
