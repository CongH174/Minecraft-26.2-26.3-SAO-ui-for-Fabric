package io.github.saoui;

import java.util.UUID;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.world.effect.MobEffects;

public final class SaoHud {
    private UUID playerId;
    private String name = "";
    private HudValues values;
    private double displayedRatio;
    private long lastFrame;

    static HudValues sample(Minecraft client) {
        var p = client.player;
        return new HudValues(p.getHealth(), p.getMaxHealth(), p.getAbsorptionAmount(),
                p.getFoodData().getFoodLevel(), AppleSkinBridge.saturation(p),
                p.experienceProgress, p.experienceLevel, p.getArmorValue(),
                HudValues.condition(p.hasEffect(MobEffects.POISON), p.hasEffect(MobEffects.WITHER)));
    }
    public void tick(Minecraft client) {
        var player = client.player;
        if (player == null) { playerId = null; values = null; lastFrame = 0; return; }
        if (!player.getUUID().equals(playerId)) {
            playerId = player.getUUID(); displayedRatio = UiMath.ratio(player.getHealth(), player.getMaxHealth()); lastFrame = 0;
        }
        name = player.getName().getString(); values = sample(client);
    }
    public void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        var client = Minecraft.getInstance(); var config = SaoUiClient.config(); var bars = config.hud;
        if (config.scale<=0 || !config.hudEnabled || !bars.anyBar() || client.player == null || values == null
                || client.player.isSpectator() || client.gui.hud.isHidden()) { lastFrame = 0; return; }
        long now = Util.getMillis(); float target = UiMath.ratio(values.health(), values.maximum());
        displayedRatio = config.smoothHealth && config.healthSmoothing>0 && lastFrame != 0
                ? UiMath.approach(displayedRatio, target, (now - lastFrame) / (1000.0 * config.healthSmoothing)) : target;
        lastFrame = now;
        draw(g,client,config,name,values,displayedRatio,frame(client,config,client.getWindow().getGuiScaledWidth(),client.getWindow().getGuiScaledHeight()));
    }
    record Frame(int x,int y,int width,int height,float scale,int nameWidth) {
        boolean contains(double px,double py){return px>=x&&px<x+width&&py>=y&&py<y+height;}
    }
    static Frame frame(Minecraft client,SaoConfig config,int viewportWidth,int viewportHeight){
        String label=client.player==null?"Player":client.player.getName().getString();
        int nameWidth=Math.max(48,client.font.width(client.font.plainSubstrByWidth(label,90))),panelWidth=nameWidth+250,panelHeight=Math.max(15,config.hud.height());
        double unit=UiEffects.unit(client.getWindow().getHeight(),client.getWindow().getGuiScale());
        float scale=(float)UiEffects.fit(UiEffects.scale(client.getWindow().getHeight(),client.getWindow().getGuiScale(),config.scale),viewportWidth,viewportHeight,panelWidth,panelHeight,4*unit);
        int w=(int)Math.ceil(panelWidth*scale),h=(int)Math.ceil(panelHeight*scale);
        int top=(int)Math.round(config.y*unit);
        // Keep the default right anchor below native effect icons; explicit user offsets are authoritative.
        if(config.hud.rightAligned&&config.y==12&&client.player!=null){
            boolean good=false,bad=false;for(var effect:client.player.getActiveEffects())if(effect.showIcon()){if(effect.getEffect().value().isBeneficial())good=true;else bad=true;}
            if(good||bad)top=Math.max(top,(good&&bad?56:30)+(int)Math.round(4*unit));
        }
        return new Frame(HudLayoutMath.left(config.x,unit,viewportWidth,w,config.hud.rightAligned),UiMath.fitPosition(top,viewportHeight,h),w,h,scale,nameWidth);
    }
    static void preview(GuiGraphicsExtractor g,Minecraft client,SaoConfig draft,int viewportWidth,int viewportHeight){
        var config=draft.copy();if(!config.hud.anyBar())config.hud.health=true;
        var sample=client.player==null?new HudValues(16,20,4,18,Float.NaN,.4f,12,8,HudValues.Condition.NORMAL):sample(client);
        draw(g,client,config,client.player==null?"Player":client.player.getName().getString(),sample,UiMath.ratio(sample.health(),sample.maximum()),frame(client,config,viewportWidth,viewportHeight));
    }
    private static void draw(GuiGraphicsExtractor g,Minecraft client,SaoConfig config,String name,HudValues values,double displayedRatio,Frame frame){
        var bars=config.hud;String shortName=client.font.plainSubstrByWidth(name,90);int nameWidth=frame.nameWidth(),panelWidth=nameWidth+250;
        g.pose().pushMatrix();g.pose().translate(frame.x(),frame.y());g.pose().scale(frame.scale(),frame.scale());
        if (bars.health) HudBarRenderer.draw(g, client, nameWidth, 0, shortName, displayedRatio,
                values.healthTint(), values.absorptionRatio(), values.healthText(bars.experience),bars);
        else {
            g.fill(4, 0, panelWidth - 8, 15, 0xBB172027);
            g.text(client.font, shortName, bars.rightAligned?panelWidth-12-client.font.width(shortName):12, 3, ThemePalette.font(0xFFFFFFFF), true);
            if (!bars.experience) {
                String level = "Lv. " + values.level();
                g.text(client.font, level, bars.rightAligned?13:panelWidth - 13 - client.font.width(level), 3, ThemePalette.font(0xFFDFE7EB), true);
            }
        }
        int row = 20;
        if (bars.hunger) {
            HudBarRenderer.draw(g, client, nameWidth, row, label("hunger"), values.foodRatio(), 0xFFE99C43,
                    bars.saturation ? values.saturationRatio() : 0, values.food() + " / 20",bars); row += 20;
        }
        if (bars.experience) {
            HudBarRenderer.draw(g, client, nameWidth, row, label("experience"), values.experienceRatio(), 0xFF75CF9C,
                    0, "Lv. " + values.level() + "  " + Math.round(values.experienceRatio() * 100) + "%",bars); row += 20;
        }
        if (bars.armor) HudBarRenderer.draw(g, client, nameWidth, row, label("armor"), values.armorRatio(),
                0xFF8DB8D5, 0, values.armor() + " / 20",bars);
        g.pose().popMatrix();
    }
    private static String label(String key) { return Component.translatable("hud.saoui." + key).getString(); }
}
