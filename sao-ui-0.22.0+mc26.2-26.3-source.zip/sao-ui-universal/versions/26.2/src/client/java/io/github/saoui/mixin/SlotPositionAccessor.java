package io.github.saoui.mixin;

import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Only the client screen's slot instances are repositioned; indices and server slots stay intact. */
@Mixin(Slot.class)
public interface SlotPositionAccessor {
    @Mutable @Accessor("x") void saoui$x(int x);
    @Mutable @Accessor("y") void saoui$y(int y);
}
