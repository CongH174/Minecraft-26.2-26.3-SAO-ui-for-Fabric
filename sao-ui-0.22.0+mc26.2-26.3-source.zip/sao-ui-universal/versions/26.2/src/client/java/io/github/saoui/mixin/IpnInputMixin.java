package io.github.saoui.mixin;
import io.github.saoui.IpnInputScope;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** IPN's outer input handler catches its own failures, so every normal path reaches RETURN. */
@Pseudo
@Mixin(targets="org.anti_ad.mc.ipnext.input.InputHandler",remap=false)
public abstract class IpnInputMixin {
    @Inject(method="onInput",at=@At("HEAD"),remap=false,require=0)
    private void saoui$begin(CallbackInfoReturnable<Boolean> cir){IpnInputScope.enter();}
    @Inject(method="onInput",at=@At("RETURN"),remap=false,require=0)
    private void saoui$end(CallbackInfoReturnable<Boolean> cir){IpnInputScope.exit();}
}
