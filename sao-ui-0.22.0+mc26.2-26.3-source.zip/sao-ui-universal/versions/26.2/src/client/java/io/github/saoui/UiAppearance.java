package io.github.saoui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

/** Render-local surfaces only. Item sprites, glyphs and HUD keep their own alpha. */
public final class UiAppearance {
    private static int depth;
    public static boolean manages(Screen screen) { return screen instanceof SaoMenuScreen || BlockFloatingUi.active(screen); }
    public static void begin(){depth++;}
    public static void end(){depth=Math.max(0,depth-1);}
    public static int surface(int color){return depth>0?UiEffects.alpha(color,SaoUiClient.config().uiOpacity):color;}
    public static void background(GuiGraphicsExtractor g){
        if(UiEffects.blurRadius(SaoUiClient.config().blurAmount())>0){g.nextStratum();g.blurBeforeThisStratum();g.nextStratum();}
    }
    public static int blurRadius(int original){
        return manages(Minecraft.getInstance().gui.screen())?UiEffects.blurRadius(SaoUiClient.config().blurAmount()):original;
    }
    private UiAppearance(){}
}
