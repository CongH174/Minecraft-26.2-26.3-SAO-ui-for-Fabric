package io.github.saoui;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import io.github.saoui.mixin.ContainerScreenAccessor;
import io.github.saoui.mixin.SlotPositionAccessor;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;

/** A themed panel over the negotiated slots of the currently open native menu. */
public final class ContainerCraftingUi {
    private static final Set<Screen> REQUESTED=Collections.newSetFromMap(new WeakHashMap<>());
    private static final int W=118,H=206;
    public static void register(){
        ClientPlayNetworking.registerGlobalReceiver(CraftingReady.TYPE,(ready,context)->{
            var client=context.client();var player=client.player;
            if(player==null||!(client.gui.screen() instanceof AbstractContainerScreen<?> screen)
                    ||screen.getMenu()!=player.containerMenu||player.containerMenu.containerId!=ready.menuId())return;
            var menu=player.containerMenu;var state=ContainerCraftingState.get(menu);
            if(state==null){if(menu.slots.size()!=ready.baseSlots())return;ContainerCraftingState.attach(menu,player);}
            FlatContainerUi.attach(screen);place(screen);
        });
    }
    private static boolean eligible(Screen screen){return SaoUiClient.config().containerCraftingVisible&&FlatContainerUi.skinned(screen)
            &&screen instanceof AbstractContainerScreen<?> c&&c.getMenu().containerId>0;}
    static boolean visible(Screen screen){return eligible(screen) && ContainerCraftingState.get(((AbstractContainerScreen<?>)screen).getMenu())!=null;}
    static void onInit(Screen screen){
        if(!eligible(screen))return;
        var container=(AbstractContainerScreen<?>)screen;
        if(ContainerCraftingState.get(container.getMenu())!=null){place(screen);return;}
        if(REQUESTED.add(screen)&&ClientPlayNetworking.canSend(CraftingRequest.TYPE))
            ClientPlayNetworking.send(new CraftingRequest(container.getMenu().containerId,container.getMenu().slots.size()));
    }
    public static boolean extraSlot(AbstractContainerScreen<?> screen,int id){var state=ContainerCraftingState.get(screen.getMenu());return state!=null&&state.contains(id);}
    private static FlatContainerUi.Bounds panel(Screen screen){var b=FlatContainerUi.nativeBounds(screen);return new FlatContainerUi.Bounds(b.x()+b.width()+12,b.y(),W,H);}
    static FlatContainerUi.Bounds expand(Screen screen,FlatContainerUi.Bounds b){
        if(!visible(screen))return b;var p=panel(screen);int bottom=Math.max(b.y()+b.height(),p.y()+p.height());
        return new FlatContainerUi.Bounds(b.x(),b.y(),p.x()+p.width()-b.x(),bottom-b.y());
    }
    static void place(Screen screen){
        if(!visible(screen))return;
        var c=(AbstractContainerScreen<?>)screen;var state=ContainerCraftingState.get(c.getMenu());if(state==null)return;
        var p=panel(screen);var a=(ContainerScreenAccessor)screen;
        int x=p.x()-a.saoui$left(),y=p.y()-a.saoui$top();
        for(int i=0;i<5;i++){
            int sx=i==0?49:37+(i-1)%2*24,sy=i==0?120:52+(i-1)/2*24;
            var slot=(SlotPositionAccessor)c.getMenu().getSlot(state.base+i);slot.saoui$x(x+sx);slot.saoui$y(y+sy);
        }
    }
    static void render(Screen screen,GuiGraphicsExtractor g){
        if(!visible(screen))return;place(screen);var p=panel(screen);var client=Minecraft.getInstance();
        FlatContainerUi.panel(g,p.x(),p.y(),W,H,tr("title"),"2 × 2","");
        var state=ContainerCraftingState.get(((AbstractContainerScreen<?>)screen).getMenu());
        if(state==null){
            String key=ClientPlayNetworking.canSend(CraftingRequest.TYPE)?"waiting":"server_required";
            int row=0;for(var line:client.font.split(Component.translatable("saoui.craft."+key),W-24))
                g.text(client.font,line,p.x()+12,p.y()+58+row++*12,ThemePalette.muted(),false);
            return;
        }
        g.fill(p.x()+58,p.y()+101,p.x()+60,p.y()+112,ThemePalette.accent());
        g.fill(p.x()+55,p.y()+110,p.x()+63,p.y()+112,ThemePalette.accent());
        g.fill(p.x()+12,p.y()+151,p.x()+W-12,p.y()+152,ThemePalette.line());
        int row=0;for(var line:client.font.split(Component.translatable("saoui.craft.hint"),W-24))
            g.text(client.font,line,p.x()+12,p.y()+162+row++*11,ThemePalette.muted(),false);
    }
    private static String tr(String key){return Component.translatable("saoui.craft."+key).getString();}
    private ContainerCraftingUi(){}
}
