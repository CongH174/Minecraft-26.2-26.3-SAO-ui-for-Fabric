package io.github.saoui.mixin;

import io.github.saoui.UiAppearance;
import net.minecraft.client.renderer.GlobalSettingsUniform;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(GlobalSettingsUniform.class)
public abstract class SaoBlurMixin {
    @ModifyVariable(method="update",at=@At("HEAD"),argsOnly=true,ordinal=2)
    private int saoui$blurRadius(int original){return UiAppearance.blurRadius(original);}
}
