package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/** Item-supplied text, kept separate from calculated facts and individual enchantment attribution. */
final class ServerItemDescriptions {
    private static final int MAX_LINES=64,MAX_CODE_POINTS=512;
    private ServerItemDescriptions() {}

    static List<Component> describe(ItemStack stack,SaoConfig config) {
        if(!config.serverEnchantmentLore||stack.isEmpty())return List.of();
        if(stack.getEnchantments().isEmpty()
                &&stack.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY).isEmpty())return List.of();
        var lore=stack.get(DataComponents.LORE);
        if(lore==null)return List.of();
        var result=new ArrayList<Component>();
        boolean omitted=lore.lines().size()>MAX_LINES;
        for(int i=0;i<Math.min(MAX_LINES,lore.lines().size());i++) {
            String text=lore.lines().get(i).getString();
            if(text.codePointCount(0,text.length())>MAX_CODE_POINTS) {
                text=text.substring(0,text.offsetByCodePoints(0,MAX_CODE_POINTS));omitted=true;
            }
            // Plain text cannot execute server-provided click or hover actions.
            if(!text.isBlank())result.add(Component.literal(text));
        }
        if(omitted)result.add(Component.translatable("saoui.enchant.item_lore_omitted"));
        return List.copyOf(result);
    }
}
