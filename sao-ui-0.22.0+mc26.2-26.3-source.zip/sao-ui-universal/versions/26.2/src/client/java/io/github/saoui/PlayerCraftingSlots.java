package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;

/** A projected view of the player's existing 2x2 grid, not a separate menu or recipe engine. */
final class PlayerCraftingSlots {
    private final List<FloatingItemSlot> slots=new ArrayList<>();
    PlayerCraftingSlots(InventoryInteraction inventory,Consumer<FloatingItemSlot> add){
        for(int id=0;id<=4;id++){
            var slot=new FloatingItemSlot(()->{});slot.bindInventory(inventory,id);
            slots.add(slot);add.accept(slot);
        }
    }
    int slotAt(double x,double y){
        for(var slot:slots)if(slot.isMouseOver(x,y))return slot.menuSlot();return -1;
    }
    void place(MenuProjection p,double opacity,boolean interactive,boolean inventoryPage){
        var player=Minecraft.getInstance().player;
        for(int id=0;id<slots.size();id++){
            var point=PlayerCraftingLayout.slot(id);var slot=slots.get(id);
            slot.place(p,point.x(),point.y(),20,player.inventoryMenu.getSlot(id).getItem(),opacity,false,false,interactive);
            slot.visible&=inventoryPage&&SaoUiClient.config().craftingVisible;
            slot.active&=inventoryPage&&SaoUiClient.config().craftingVisible;
        }
    }
    void render(GuiGraphicsExtractor g,MenuProjection p,double reveal){
        if(!SaoUiClient.config().craftingVisible)return;
        int x=PlayerCraftingLayout.X,y=PlayerCraftingLayout.Y;
        PlayerPanels.panel(g,p,x,y,PlayerCraftingLayout.WIDTH*reveal,PlayerCraftingLayout.HEIGHT,reveal);
        if(reveal<.65)return;
        double opacity=(reveal-.65)/.35;
        text(g,p,"title",x+14,y+14,ThemePalette.ink(),opacity);
        FloatingDraw.text(g,p,"2 × 2",x+14,y+31,FloatingDraw.alpha(ThemePalette.muted(),opacity));
        int cx=x+59;
        FloatingDraw.rect(g,p,cx-1,-28,2,12,FloatingDraw.alpha(ThemePalette.accent(),opacity));
        FloatingDraw.rect(g,p,cx-4,-19,8,2,FloatingDraw.alpha(ThemePalette.accent(),opacity));
        text(g,p,"result",x+14,24,ThemePalette.muted(),opacity);
        FloatingDraw.rect(g,p,x+14,40,90,.8,FloatingDraw.alpha(ThemePalette.line(),opacity));
        text(g,p,"hint",x+14,52,ThemePalette.muted(),opacity);
        text(g,p,"native",x+14,65,ThemePalette.muted(),opacity);
    }
    private static void text(GuiGraphicsExtractor g,MenuProjection p,String key,double x,double y,int color,double opacity){
        var font=Minecraft.getInstance().font;String text=Component.translatable("item.saoui.crafting."+key).getString();
        FloatingDraw.text(g,p,font.plainSubstrByWidth(text,90),x,y,FloatingDraw.alpha(color,opacity));
    }
}
