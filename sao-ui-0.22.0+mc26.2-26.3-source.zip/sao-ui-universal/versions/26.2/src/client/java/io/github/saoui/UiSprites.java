package io.github.saoui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

public final class UiSprites {
    private static final Identifier GUI = SaoUiClient.id("textures/sao/gui.png");
    private UiSprites() {}

    /** Upstream theme UVs use a 256-unit grid on a 1024-pixel atlas. */
    public static void gui(GuiGraphicsExtractor g, int x, int y, int width, int height,
                           int u, int v, int sourceWidth, int sourceHeight) {
        gui(g, x, y, width, height, u, v, sourceWidth, sourceHeight, 0xFFFFFFFF);
    }

    public static void gui(GuiGraphicsExtractor g, int x, int y, int width, int height,
                           int u, int v, int sourceWidth, int sourceHeight, int color) {
        g.blit(RenderPipelines.GUI_TEXTURED, GUI, x, y, u * 4, v * 4,
                width, height, sourceWidth * 4, sourceHeight * 4, 1024, 1024, color);
    }

    public static void icon(GuiGraphicsExtractor g, Identifier texture, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, texture, x, y, 0, 0, size, size, 64, 64, 64, 64);
    }
}
