package io.github.saoui.mixin;
import io.github.saoui.ThemePalette;

import io.github.saoui.FlatContainerUi;
import net.minecraft.client.gui.ActiveTextCollector;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractButton.class)
public abstract class FlatButtonMixin {
    @Inject(method = "extractDefaultLabel", at = @At("HEAD"), cancellable = true)
    private void saoui$label(ActiveTextCollector collector, CallbackInfo ci) {
        if (FlatContainerUi.nativePass()) {
            FlatContainerUi.buttonLabel((AbstractWidget)(Object)this);
            ci.cancel();
        }
    }
}
