package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;

/** Inventory equipment column above the offhand, backed by real InventoryMenu slots. */
final class PlayerArmorSlots {
    private final List<FloatingItemSlot> slots = new ArrayList<>();
    PlayerArmorSlots(InventoryInteraction inventory, Consumer<FloatingItemSlot> add) {
        for (int index = 0; index < 4; index++) {
            var slot = new FloatingItemSlot(() -> {});
            slot.bindInventory(inventory, 5 + index); // Native HEAD, CHEST, LEGS, FEET slots.
            slots.add(slot); add.accept(slot);
        }
    }
    int slotAt(double x, double y) {
        for (var slot : slots) if (slot.isMouseOver(x, y)) return slot.menuSlot();
        return -1;
    }
    void place(MenuProjection projection, double opacity, boolean interactive, boolean inventoryPage) {
        var player = Minecraft.getInstance().player;
        for (int i = 0; i < slots.size(); i++) {
            var slot = slots.get(i);
            slot.place(projection, 274, -93 + i * 22, 20, player.inventoryMenu.getSlot(5 + i).getItem(),
                    opacity, false, false, interactive);
            slot.visible &= inventoryPage && SaoUiClient.config().armorSlotsVisible;
            slot.active &= inventoryPage && SaoUiClient.config().armorSlotsVisible;
        }
    }
}
