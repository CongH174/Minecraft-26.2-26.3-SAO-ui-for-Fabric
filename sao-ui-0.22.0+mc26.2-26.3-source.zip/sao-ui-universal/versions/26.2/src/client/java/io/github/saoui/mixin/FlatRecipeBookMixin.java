package io.github.saoui.mixin;
import io.github.saoui.ThemePalette;

import io.github.saoui.FlatContainerUi;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(RecipeBookComponent.class)
public abstract class FlatRecipeBookMixin {
    @Inject(method = "updateTabs", at = @At("RETURN"))
    private void saoui$tabs(boolean filtering, CallbackInfo ci) {
        var screen = FlatContainerUi.bookOwner(this);
        if (screen == null) return;
        var origin = FlatContainerUi.recipeOrigin(screen);
        int row = 0;
        for (var tab : ((RecipeBookAccessor)this).saoui$tabs()) if (tab.visible)
            tab.setPosition(origin.x() - 30, origin.y() + 3 + row++ * 27);
    }
    @Inject(method = "getXOrigin", at = @At("HEAD"), cancellable = true)
    private void saoui$x(CallbackInfoReturnable<Integer> ci) {
        var screen = FlatContainerUi.bookOwner(this);
        if (screen != null) ci.setReturnValue(FlatContainerUi.recipeOrigin(screen).x());
    }
    @Inject(method = "getYOrigin", at = @At("HEAD"), cancellable = true)
    private void saoui$y(CallbackInfoReturnable<Integer> ci) {
        var screen = FlatContainerUi.bookOwner(this);
        if (screen != null) ci.setReturnValue(FlatContainerUi.recipeOrigin(screen).y());
    }
    @Inject(method = "updateScreenPosition", at = @At("HEAD"), cancellable = true)
    private void saoui$anchor(int width, int imageWidth, CallbackInfoReturnable<Integer> ci) {
        if (FlatContainerUi.bookOwner(this) != null) ci.setReturnValue((width - imageWidth) / 2);
    }
}
