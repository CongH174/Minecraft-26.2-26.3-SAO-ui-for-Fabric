package io.github.saoui.mixin;

import io.github.saoui.BlockFloatingUi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Covers client-created screens and the final visible screen after nested init events. */
@Mixin(Gui.class)
public abstract class ContainerOpenMixin {
    @Inject(method = "setScreen", at = @At("RETURN"))
    private void saoui$clientOpen(Screen screen, CallbackInfo ci) {
        if (screen != null) BlockFloatingUi.onScreenInit(Minecraft.getInstance(), screen);
    }
}
