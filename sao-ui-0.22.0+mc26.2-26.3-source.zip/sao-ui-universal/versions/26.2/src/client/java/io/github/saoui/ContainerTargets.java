package io.github.saoui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.BlockHitResult;

/** Stable target identities, separate from shared menu types (chest and barrel are distinct). */
public final class ContainerTargets {
    private static final Set<String> PATHS = Set.of("chest", "trapped_chest", "ender_chest", "barrel", "hopper",
            "dispenser", "dropper", "furnace", "blast_furnace", "smoker", "crafting_table", "grindstone",
            "smithing_table", "stonecutter", "enchanting_table", "brewing_stand", "beacon", "loom", "cartography_table", "crafter");
    public record Target(String block, String location, BlockPos position) {}
    private ContainerTargets() {}
    public static List<String> catalog(ContainerUiRules rules) {
        var ids = new java.util.TreeSet<String>();
        for (var id : rules.blocks.keySet()) ids.add(ContainerTypeGroups.key(id));
        for (var block : BuiltInRegistries.BLOCK) {
            var id = BuiltInRegistries.BLOCK.getKey(block);
            if (id.getNamespace().equals("minecraft") && (PATHS.contains(id.getPath()) || block instanceof ShulkerBoxBlock || block instanceof AnvilBlock)) ids.add(ContainerTypeGroups.key(id.toString()));
        }
        return List.copyOf(ids);
    }
    public static Target aimed() {
        var client = Minecraft.getInstance();
        return client.hitResult instanceof BlockHitResult hit && client.level != null ? at(hit.getBlockPos()) : null;
    }
    public static Target at(BlockPos pos) {
        var client = Minecraft.getInstance();
        if (client.level == null) return null;
        String block = BuiltInRegistries.BLOCK.getKey(client.level.getBlockState(pos).getBlock()).toString();
        String world;
        if (client.getSingleplayerServer() != null) world = "local:" + client.getSingleplayerServer().getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize();
        else if (client.getCurrentServer() != null) world = "server:" + client.getCurrentServer().ip.toLowerCase(Locale.ROOT);
        else return new Target(block, null, pos.immutable());
        try {
            String fingerprint = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(world.getBytes(StandardCharsets.UTF_8)));
            String location = fingerprint + "|" + client.level.dimension().identifier() + "|" + pos.getX() + "," + pos.getY() + "," + pos.getZ() + "|" + block;
            return new Target(block, location, pos.immutable());
        } catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
    public static String name(String id) {
        var key = Identifier.tryParse(id);
        return key != null && BuiltInRegistries.BLOCK.containsKey(key) ? BuiltInRegistries.BLOCK.getValue(key).getName().getString() : id;
    }
}
