package io.github.saoui;
/** Scope the virtual inventory identity to IPN hotkey handling, preserving native item clicks. */
public final class IpnInputScope {
    private static int depth;
    public static void enter(){depth++;}
    public static void exit(){depth=Math.max(0,depth-1);}
    public static boolean active(){return depth>0;}
    private IpnInputScope(){}
}
