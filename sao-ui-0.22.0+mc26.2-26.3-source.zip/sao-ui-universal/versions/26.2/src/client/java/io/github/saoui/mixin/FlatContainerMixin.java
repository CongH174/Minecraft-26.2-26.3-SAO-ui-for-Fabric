package io.github.saoui.mixin;

import io.github.saoui.FlatContainerUi;
import io.github.saoui.UniversalContainerUi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class FlatContainerMixin {
    @Inject(method = "extractContents", at = @At("HEAD"), cancellable = true)
    private void saoui$skipNativeBase(GuiGraphicsExtractor g, int x, int y, float delta, CallbackInfo ci) {
        if (FlatContainerUi.nativePass()) ci.cancel();
    }

    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true)
    private void saoui$preserveSubclassContents(GuiGraphicsExtractor g, int x, int y, float delta, CallbackInfo ci) {
        if (FlatContainerUi.nativePass() && !UniversalContainerUi.managed((Screen)(Object)this)) ci.cancel();
    }

    @Inject(method = {"extractCarriedItem", "extractTooltip"}, at = @At("HEAD"), cancellable = true)
    private void saoui$singleCursor(GuiGraphicsExtractor g, int x, int y, CallbackInfo ci) {
        if (FlatContainerUi.nativePass()) ci.cancel();
    }

    @Inject(method = "hasClickedOutside", at = @At("HEAD"), cancellable = true)
    private void saoui$canvasBounds(double x, double y, int left, int top, CallbackInfoReturnable<Boolean> ci) {
        Screen screen = (Screen) (Object) this;
        if (FlatContainerUi.skinned(screen)) ci.setReturnValue(!FlatContainerUi.bounds(screen).contains(x, y));
    }
}
