package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.LongSupplier;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;

public final class SaoMenuScreen extends Screen {
    private final List<FloatingButton> roots = new ArrayList<>();
    private final List<FloatingButton> actions = new ArrayList<>();
    private final LongSupplier clock;
    private long openedAt, panelAt, closedAt, lastFrame;
    private MenuModule selected;
    private List<MenuModule> modules = List.of();
    private boolean closing;
    private Runnable pendingAction;
    private double driftX, driftY;
    private PlayerPanels panels;
    private InventoryInteraction inventory;
    private boolean inventoryGesture;

    public SaoMenuScreen() { this(Util::getMillis); }
    // The test clock captures the real renderer at deterministic animation stages.
    SaoMenuScreen(LongSupplier clock) {
        super(Component.translatable("screen.saoui.menu"));
        this.clock = clock;
    }

    @Override
    protected void init() {
        openedAt = clock.getAsLong();
        panelAt = openedAt + 140;
        lastFrame = openedAt;
        roots.clear();
        clearWidgets();
        modules = SaoUiClient.config().enabledModules();
        if (selected == null || !modules.contains(selected)) selected = SaoUiClient.config().home();
        panels = new PlayerPanels(this::addRenderableWidget, this::removeWidget);
        if (minecraft.player != null) {
            inventory = new InventoryInteraction(panels, this::onClose);
            inventory.init(width, height);
            panels.bindInventory(inventory);
        }
        for (var module : modules) {
            roots.add(addRenderableWidget(new FloatingButton(Component.translatable(module.titleKey()), module.icon(), true,
                    () -> select(module))));
        }
        roots.add(addRenderableWidget(new FloatingButton(Component.translatable("menu.saoui.close"), "logout", true, this::onClose)));
        rebuildActions();
        updateFrames(openedAt);
    }

    private void select(MenuModule module) {
        if (closing || selected == module || !modules.contains(module)) return;
        if (inventory != null) inventory.cancelGesture();
        inventoryGesture = false;
        selected = module;
        panelAt = clock.getAsLong();
        rebuildActions();
        updateFrames(clock.getAsLong());
    }

    private void rebuildActions() {
        for (var button : actions) removeWidget(button);
        actions.clear();
        panels.setPage(selected);
        if (selected == MenuModule.SETTINGS) {
            action("menu_layout", () -> navigate(() -> minecraft.gui.setScreen(new SaoModuleSettingsScreen(this))));
            action("containers", () -> navigate(() -> minecraft.gui.setScreen(new SaoContainerSettingsScreen(this))));
            action("hud_settings", () -> navigate(() -> minecraft.gui.setScreen(new SaoSettingsScreen(this))));
            action("options", () -> navigate(() -> minecraft.gui.setScreen(new OptionsScreen(this, minecraft.options, false))));
        } else if (selected == MenuModule.INVENTORY || selected == MenuModule.EQUIPMENT) {
            action("organize", () -> navigate(() -> {
                if (minecraft.player != null) minecraft.gui.setScreen(new InventoryScreen(minecraft.player));
            }));
        } else {
            if (modules.contains(MenuModule.INVENTORY)) action("inventory", () -> select(MenuModule.INVENTORY));
            if (modules.contains(MenuModule.EQUIPMENT)) action("equipment", () -> select(MenuModule.EQUIPMENT));
        }
    }

    private void action(String key, Runnable action) {
        actions.add(addRenderableWidget(new FloatingButton(Component.translatable("menu.saoui." + key),
                null, false, action)));
    }

    private void navigate(Runnable action) {
        if (closing) return;
        closing = true;
        closedAt = clock.getAsLong();
        pendingAction = action;
        for (var button : roots) button.active = false;
        for (var button : actions) button.active = false;
        if (inventory != null) inventory.cancelGesture();
        inventoryGesture = false;
        updateFrames(closedAt);
    }

    @Override
    public void tick() {
        if (panels != null) panels.refresh();
        if (closing && elapsed(clock.getAsLong(), closedAt) >= MenuMotion.CLOSE_MILLIS) {
            Runnable action = pendingAction;
            closing = false;
            pendingAction = null;
            action.run();
        }
    }

    public boolean isAnimationSettled() {
        long now = clock.getAsLong();
        return !closing && elapsed(now, openedAt) >= MenuMotion.OPEN_MILLIS
                && elapsed(now, panelAt) >= MenuMotion.PANEL_MILLIS;
    }

    private long elapsed(long now,long start) { return UiEffects.elapsed(now-start,SaoUiClient.config().animationRate()); }

    private double visibility(long now) {
        return closing ? 1 - MenuMotion.in(MenuMotion.progress(elapsed(now, closedAt), 0, MenuMotion.CLOSE_MILLIS)) : 1;
    }

    private MenuProjection projection(long now) {
        double arrival = MenuMotion.out(MenuMotion.progress(elapsed(now, openedAt), 0, MenuMotion.OPEN_MILLIS));
        double visible = visibility(now);
        double depth = (1 - arrival) * 160 + (1 - visible) * 130;
        var probe = new MenuProjection(0, 0, 1, depth, 0, 0);
        var bounds = FloatingDraw.bounds(probe, -204, -128, (selected == MenuModule.EQUIPMENT && SaoUiClient.config().enchantmentDetailsVisible ? 754 : PlayerCraftingLayout.menuWidth(selected == MenuModule.INVENTORY && SaoUiClient.config().craftingVisible)), 260);
        double unit=UiEffects.unit(minecraft.getWindow().getHeight(),minecraft.getWindow().getGuiScale());
        double scale=UiEffects.fit(UiEffects.scale(minecraft.getWindow().getHeight(),minecraft.getWindow().getGuiScale(),SaoUiClient.config().uiScale),width,height,bounds.width(),bounds.height(),12*unit);
        scale = Math.max(0.001, scale) * (0.78 + 0.22 * arrival) * (0.9 + 0.1 * visible);
        double dx = BlockSurfaceMotion.clampDrift(driftX, (width - bounds.width() * scale) / 2, bounds.width() * scale, width, 6*unit);
        double dy = BlockSurfaceMotion.clampDrift(driftY, (height - bounds.height() * scale) / 2, bounds.height() * scale, height, 6*unit);
        return new MenuProjection(width / 2.0 - (bounds.left() + bounds.width() / 2.0) * scale + dx,
                height / 2.0 - (bounds.top() + bounds.height() / 2.0) * scale + dy,
                scale, depth, 0, 0);
    }

    private void updateFrames(long now) {
        MenuProjection p = projection(now);
        double visible = visibility(now);
        for (int i = 0; i < roots.size(); i++) {
            double t = MenuMotion.orb(elapsed(now, openedAt), i);
            double radius = 20 * Math.max(0.02, MenuMotion.pop(t)) * (0.6 + 0.4 * visible);
            double y = (i - (roots.size() - 1) / 2.0) * 45 * MenuMotion.out(t) * visible;
            roots.get(i).place(p, -radius, y - radius, radius * 2, radius * 2,
                    MenuMotion.out(t) * visible, i < modules.size() && modules.get(i) == selected, isAnimationSettled());
        }
        double reveal = MenuMotion.out(MenuMotion.progress(elapsed(now, panelAt), 0, MenuMotion.PANEL_MILLIS)) * visible;
        for (int i = 0; i < actions.size(); i++) {
            boolean items = selected == MenuModule.INVENTORY || selected == MenuModule.EQUIPMENT;
            boolean profile = selected == MenuModule.PROFILE;
            actions.get(i).place(p, profile ? 58+i*122 : items ? 58 : 70 + (1 - reveal) * 20,
                    profile ? 104 : items ? 105 : selected == MenuModule.SETTINGS ? -22 + i * 28 : -10 + i * 35, (profile ? 116 : 164) * reveal,
                    profile ? 19 : items ? 18 : 27,
                    MenuMotion.out(MenuMotion.progress(elapsed(now, panelAt), 90 + i * 35L, 170)) * visible,
                    false, isAnimationSettled());
        }
        panels.place(p, reveal, isAnimationSettled());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        // Background blur is requested once by the screen render wrapper.
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        long now = clock.getAsLong();
        double seconds = Math.max(0, now - lastFrame) / 1000.0;
        lastFrame = now;
        if (!inventoryGesture) {
            driftX = UiMath.approach(driftX, Math.clamp((mouseX - width / 2.0) / width, -0.5, 0.5) * 18 * UiEffects.unit(minecraft.getWindow().getHeight(),minecraft.getWindow().getGuiScale()) * SaoUiClient.config().parallaxAmount(), seconds);
            driftY = UiMath.approach(driftY, Math.clamp((mouseY - height / 2.0) / height, -0.5, 0.5) * 14 * UiEffects.unit(minecraft.getWindow().getHeight(),minecraft.getWindow().getGuiScale()) * SaoUiClient.config().parallaxAmount(), seconds);
        }
        updateFrames(now);
        if (inventory != null) inventory.pointer(mouseX, mouseY);
        double visible = visibility(now);
        double reveal = MenuMotion.out(MenuMotion.progress(elapsed(now, panelAt), 0, MenuMotion.PANEL_MILLIS)) * visible;
        g.fill(0, 0, width, height, FloatingDraw.alpha(0x180B1518, visible));
        MenuProjection p = projection(now);
        double arrival = MenuMotion.out(MenuMotion.progress(elapsed(now, openedAt), 80, 360));
        panels.portrait(g, p, mouseX, mouseY, arrival * visible);
        FloatingDraw.rect(g, p, -0.6, -91 * visible, 1.2, 182 * visible,
                FloatingDraw.alpha(0xA8EDF0EE, MenuMotion.out(MenuMotion.progress(elapsed(now, openedAt), 100, 280)) * visible));
        if (reveal > 0.01) {
            double selectedY = (modules.indexOf(selected) - (roots.size() - 1) / 2.0) * 45 * visible;
            int line = FloatingDraw.alpha(0xD9F8FAF6, reveal);
            FloatingDraw.rect(g, p, 22, selectedY - 0.5, 14 * reveal, 1, line);
            FloatingDraw.rect(g, p, 35, Math.min(selectedY, -102), 1, Math.abs(selectedY + 102), line);
            FloatingDraw.rect(g, p, 35, -102.5, 9 * reveal, 1, line);
            PlayerPanels.panel(g, p, 44, -124, 266 * reveal, 252, reveal);
            panels.craftingPanel(g, p, reveal);
            if (reveal > 0.65) {
                if (selected == MenuModule.INVENTORY || selected == MenuModule.EQUIPMENT) panels.contents(g, p, (reveal - 0.65) / 0.35);
                else drawPanelText(g, p, (reveal - 0.65) / 0.35);
            }
        }
        super.extractRenderState(g, mouseX, mouseY, delta);
        if (inventory != null) inventory.extractCarriedItem(g, mouseX, mouseY);
        panels.readingOverlay(g);
    }

    private boolean canMoveItems() {
        return isAnimationSettled() && inventory != null && inventory.available();
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (closing) return true;
        if (isAnimationSettled() && event.button()==com.mojang.blaze3d.platform.InputConstants.MOUSE_BUTTON_LEFT && panels.detailClick(event.x(),event.y(),projection(clock.getAsLong()))) return true;
        if (panels.detailsModal()) return true;
        if (canMoveItems() && panels.inventorySlotAt(event.x(), event.y()) >= 0) {
            panels.selectAt(event.x(), event.y());
            inventory.pointer(event.x(), event.y());
            inventoryGesture = true;
            return inventory.mouseClicked(event, doubleClick);
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (inventoryGesture && canMoveItems()) return inventory.mouseDragged(event, dx, dy);
        return super.mouseDragged(event, dx, dy);
    }

    @Override public boolean mouseReleased(MouseButtonEvent event) {
        if (inventoryGesture) {
            inventoryGesture = false;
            if (canMoveItems()) inventory.mouseReleased(event);
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override public void mouseMoved(double x, double y) {
        if (inventory != null) inventory.pointer(x, y);
        super.mouseMoved(x, y);
    }

    @Override public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        if (isAnimationSettled() && panels.scroll(x,y,vertical,projection(clock.getAsLong()))) return true;
        if (canMoveItems()) {
            inventory.pointer(x, y);
            if (inventory.mouseScrolled(x, y, horizontal, vertical)) return true;
        }
        return super.mouseScrolled(x, y, horizontal, vertical);
    }

    @Override public boolean keyPressed(KeyEvent event) {
        if (closing) return true;
        if (isAnimationSettled() && panels.detailKey(event)) return true;
        if (panels.detailsModal()) return true;
        if (canMoveItems() && inventory.handleKey(event)) return true;
        return super.keyPressed(event);
    }

    @Override public void removed() {
        if (inventory != null) inventory.finish();
        super.removed();
    }

    private void drawPanelText(GuiGraphicsExtractor g, MenuProjection p, double opacity) {
        if(selected==MenuModule.PROFILE){PlayerStatusPanel.render(g,p,opacity);return;}
        int titleColor = FloatingDraw.alpha(ThemePalette.ink(), opacity);
        int muted = FloatingDraw.alpha(ThemePalette.muted(), opacity);
        FloatingDraw.text(g, p, Component.translatable(selected.titleKey()).getString(), 70, -88, titleColor);
        var player = minecraft.player;
        if (player != null) {
            FloatingDraw.text(g, p, font.plainSubstrByWidth(player.getName().getString(), 150), 70, -64, titleColor);
            FloatingDraw.text(g, p, "Lv. " + player.experienceLevel + "    HP "
                    + (int) Math.ceil(player.getHealth()) + " / " + (int) Math.ceil(player.getMaxHealth()), 70, -47, muted);
        }
        FloatingDraw.rect(g, p, 70, -29, 158, 0.8, FloatingDraw.alpha(FloatingDraw.alpha(ThemePalette.line(), .4), opacity));
        FloatingDraw.text(g, p, Component.translatable("screen.saoui.floating_hint").getString(), 70, selected == MenuModule.SETTINGS ? 108 : 76, muted);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { navigate(() -> minecraft.gui.setScreen(null)); }
    public Screen ipnScreen() {
        return SaoUiClient.config().ipnIntegration && !closing && selected == MenuModule.INVENTORY
                && inventory != null && inventory.available() ? inventory : this;
    }
}
