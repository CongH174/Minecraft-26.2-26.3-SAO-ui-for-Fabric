package io.github.saoui;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/** Presentation reads native components only; it never predicts server combat results. */
final class ItemDetails {
    enum Kind { MELEE, RANGED, ARMOR, TOOL, SHIELD, BOOK, OTHER }
    static Kind kind(ItemStack stack) {
        if (stack.is(Items.BOOK) || stack.is(Items.ENCHANTED_BOOK) || stack.has(DataComponents.STORED_ENCHANTMENTS)) return Kind.BOOK;
        if (stack.is(Items.SHIELD)) return Kind.SHIELD;
        var equipment=stack.get(DataComponents.EQUIPPABLE);
        if (equipment!=null && equipment.slot()!=EquipmentSlot.MAINHAND && equipment.slot()!=EquipmentSlot.OFFHAND) return Kind.ARMOR;
        if (stack.getItem() instanceof ProjectileWeaponItem || stack.is(Items.TRIDENT)) return Kind.RANGED;
        if(stack.is(net.minecraft.tags.ItemTags.PICKAXES)||stack.is(net.minecraft.tags.ItemTags.SHOVELS)||stack.is(net.minecraft.tags.ItemTags.HOES))return Kind.TOOL;
        boolean[] weapon={false};
        stack.forEachModifier(EquipmentSlot.MAINHAND,(attribute,modifier)->{if(attribute.equals(Attributes.ATTACK_DAMAGE))weapon[0]=true;});
        if (weapon[0]) return Kind.MELEE;
        if (stack.has(DataComponents.TOOL) || stack.isDamageableItem()) return Kind.TOOL;
        return Kind.OTHER;
    }
    static Component summary(Player player,ItemStack stack) {
        return switch(kind(stack)) {
            case MELEE -> {var s=CombatItems.stats(player,stack);yield Component.translatable("item.saoui.melee_summary",CombatItems.number(s.damage()),CombatItems.number(s.speed()));}
            case ARMOR -> Component.translatable("item.saoui.armor_summary",CombatItems.number(armorValue(stack,Attributes.ARMOR)),CombatItems.number(armorValue(stack,Attributes.ARMOR_TOUGHNESS)));
            case RANGED -> Component.translatable("item.saoui.ranged_note");
            case SHIELD -> Component.translatable("item.saoui.shield_summary");
            case TOOL -> Component.translatable("item.saoui.tool_summary");
            case BOOK -> Component.translatable("item.saoui.book_summary",stack.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY).size());
            case OTHER -> Component.translatable("item.saoui.other_summary");
        };
    }
    private static double armorValue(ItemStack stack,net.minecraft.core.Holder<net.minecraft.world.entity.ai.attributes.Attribute> attribute) {
        var equippable=stack.get(DataComponents.EQUIPPABLE);if(equippable==null)return 0;
        double[] modifiers={0,0,1};
        stack.forEachModifier(equippable.slot(),(type,modifier)->{if(!type.equals(attribute))return;switch(modifier.operation()){
            case ADD_VALUE -> modifiers[0]+=modifier.amount();case ADD_MULTIPLIED_BASE -> modifiers[1]+=modifier.amount();case ADD_MULTIPLIED_TOTAL -> modifiers[2]*=1+modifier.amount();
        }});
        return CombatMath.attribute(0,modifiers[0],modifiers[1],modifiers[2]);
    }
    private ItemDetails() {}
}
