package io.github.saoui;

import io.github.saoui.FlatContainerLayout.Kind;
import io.github.saoui.mixin.ContainerScreenAccessor;
import io.github.saoui.mixin.RecipeBookAccessor;
import io.github.saoui.mixin.RecipeScreenAccessor;
import io.github.saoui.mixin.SlotPositionAccessor;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.world.inventory.*;

/** Flat, family-specific views over real vanilla menus. Only client slot geometry changes. */
public final class FlatContainerUi {
    private static final Map<Screen, Layout> LAYOUTS = new WeakHashMap<>();
    private record Layout(Kind kind, String id, int workWidth, ContainerPanelLayout.Placement placement) {}
    public record Anchor(double x, double y) {}
    public record Bounds(int x, int y, int width, int height) {
        public boolean contains(double px, double py) {
            return px >= x && py >= y && px < x + width && py < y + height;
        }
    }
    private static GuiGraphicsExtractor nativeGraphics;
    public static boolean nativePass() { return nativeGraphics != null; }
    private FlatContainerUi() {}

    public static void attach(Screen screen) {
        if (!BlockFloatingUi.active(screen) || !(screen instanceof AbstractContainerScreen<?> container) || screen instanceof InventoryInteraction) return;
        var type = ((io.github.saoui.mixin.MenuTypeAccessor)container.getMenu()).saoui$type();
        var key = type == null ? null : BuiltInRegistries.MENU.getKey(type);
        Kind kind = key != null && key.getNamespace().equals("minecraft") ? FlatContainerLayout.kind(key.getPath()) : null;
        if (kind == null || !compatible(kind, container.getMenu())
                || !screen.getClass().getName().startsWith("net.minecraft.client.gui.screens.inventory.")) {
            if (SaoUiClient.config().replaceAllContainers) UniversalContainerUi.attach(screen);
            return;
        }
        int width = FlatContainerLayout.workWidth(((ContainerScreenAccessor) screen).saoui$width());
        var placement = ContainerPanelLayout.place(width, BlockFloatingUi.profile(screen));
        LAYOUTS.put(screen, new Layout(kind, key.getPath(), width, placement));
        int storageIndex = 0;
        for (var slot : container.getMenu().slots) {
            if (ContainerCraftingUi.extraSlot(container,slot.index)) continue;
            FlatContainerLayout.Point point = null;
            if (playerSlot(slot)) {
                var p = FlatContainerLayout.playerSlot(slot.getContainerSlot(), width);
                point = new FlatContainerLayout.Point(p.x() - FlatContainerLayout.playerX(width) + placement.backpackX(), p.y() + placement.backpackY());
            }
            else if (kind == Kind.STORAGE) point = FlatContainerLayout.storageSlot(storageIndex++, FlatContainerLayout.columns(key.getPath()), width);
            else point = FlatContainerLayout.workSlot(kind, slot.index);
            if (point != null) {
                ((SlotPositionAccessor) slot).saoui$x(point.x());
                ((SlotPositionAccessor) slot).saoui$y(point.y());
            }
        }
        if (screen instanceof RecipeScreenAccessor recipe) {
            recipe.saoui$narrow(false);
            var a = (ContainerScreenAccessor) screen;
            int next = (screen.width - a.saoui$width()) / 2;
            a.saoui$left(next);
            for (var child : screen.children()) if (child instanceof AbstractWidget widget) widget.setPosition(next + width - 30, a.saoui$top() + 8);
            if (recipe.saoui$book().isVisible()) ((RecipeBookAccessor)recipe.saoui$book()).saoui$layout();
        }
        if (kind == Kind.ANVIL) for (var child : screen.children()) if (child instanceof EditBox edit) {
            var a = (ContainerScreenAccessor) screen;
            edit.setPosition(a.saoui$left() + 18, a.saoui$top() + 26); edit.setWidth(width - 36);
        }
    }

    private static boolean compatible(Kind kind, AbstractContainerMenu menu) {
        return switch (kind) {
            case STORAGE -> menu instanceof ChestMenu || menu instanceof DispenserMenu || menu instanceof HopperMenu || menu instanceof ShulkerBoxMenu;
            case SMELTING -> menu instanceof AbstractFurnaceMenu;
            case CRAFTING -> menu instanceof CraftingMenu;
            case ANVIL -> menu instanceof AnvilMenu;
            case GRINDSTONE -> menu instanceof GrindstoneMenu;
            case SMITHING -> menu instanceof SmithingMenu;
            case STONECUTTER -> menu instanceof StonecutterMenu;
            case ENCHANTING -> menu instanceof EnchantmentMenu;
            case BREWING -> menu instanceof BrewingStandMenu;
            case BEACON -> menu instanceof BeaconMenu;
            case LOOM -> menu instanceof LoomMenu;
            case CARTOGRAPHY -> menu instanceof CartographyTableMenu;
            case CRAFTER -> menu instanceof CrafterMenu;
        };
    }
    public static boolean skinned(Screen screen) { return BlockFloatingUi.active(screen) && (LAYOUTS.containsKey(screen) || UniversalContainerUi.managed(screen)); }
    public static Screen bookOwner(Object book) {
        Screen screen = Minecraft.getInstance().gui.screen();
        return skinned(screen) && screen instanceof RecipeScreenAccessor recipe && recipe.saoui$book() == book ? screen : null;
    }
    public static FlatContainerLayout.Point recipeOrigin(Screen screen) {
        var a = (ContainerScreenAccessor)screen;
        if (UniversalContainerUi.managed(screen)) {
            var b = UniversalContainerUi.contentBounds(screen);
            return new FlatContainerLayout.Point(b.x() - 160, b.y() + 8);
        }
        var b = LAYOUTS.get(screen).placement.bounds();
        return new FlatContainerLayout.Point(a.saoui$left() + b.x() - 160, a.saoui$top() + b.y() + 8);
    }
    public static Anchor anchor(Screen screen) {
        if (ContainerCraftingUi.visible(screen)) { var b=bounds(screen); return new Anchor(b.x()+b.width()/2.0,b.y()+b.height()/2.0); }
        if (UniversalContainerUi.managed(screen)) { var b = bounds(screen); return new Anchor(b.x() + b.width() / 2.0, b.y() + b.height() / 2.0); }
        var a = (ContainerScreenAccessor)screen;
        var b = LAYOUTS.get(screen).placement.baseline();
        if (screen instanceof RecipeScreenAccessor recipe && recipe.saoui$book().isVisible())
            b = b.union(new ContainerPanelLayout.Rect(b.x() - 190, b.y() + 4, 180, 174));
        return new Anchor(a.saoui$left() + b.centerX(), a.saoui$top() + b.centerY());
    }
    public static Bounds entityPreview() {
        Screen screen = Minecraft.getInstance().gui.screen();
        if (!skinned(screen) || UniversalContainerUi.managed(screen) || LAYOUTS.get(screen).kind != Kind.SMITHING) return null;
        var a = (ContainerScreenAccessor)screen;
        return new Bounds(a.saoui$left() + 62, a.saoui$top() + 66, 96, 68);
    }
    private static boolean playerSlot(Slot slot) {
        var player = Minecraft.getInstance().player;
        return player != null && slot.container == player.getInventory() && slot.getContainerSlot() >= 0 && slot.getContainerSlot() < 36;
    }
    public static Bounds bounds(Screen screen) { return ContainerCraftingUi.expand(screen,nativeBounds(screen)); }
    static Bounds nativeBounds(Screen screen) {
        if (UniversalContainerUi.managed(screen)) return UniversalContainerUi.bounds(screen);
        var a = (ContainerScreenAccessor) screen;
        Layout layout = LAYOUTS.get(screen);
        if (layout == null) return new Bounds(a.saoui$left() - 5, a.saoui$top() - 5, a.saoui$width() + 10, a.saoui$height() + 10);
        var b = layout.placement.bounds();
        int x = a.saoui$left() + b.x(), y = a.saoui$top() + b.y();
        int right = x + b.width(), bottom = y + b.height();
        if (screen instanceof RecipeScreenAccessor recipe && recipe.saoui$book().isVisible()) {
            var book = (RecipeBookAccessor) recipe.saoui$book();
            x = Math.min(x, book.saoui$x() - 30);
            y = Math.min(y, book.saoui$y() - 4);
            right = Math.max(right, book.saoui$x() + 150);
            bottom = Math.max(bottom, book.saoui$y() + 170);
        }
        return new Bounds(x, y, right - x, bottom - y);
    }

    public static void render(Screen screen, GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (UniversalContainerUi.managed(screen)) { UniversalContainerUi.render(screen, g, mouseX, mouseY, delta); return; }
        var container = (AbstractContainerScreen<?>) screen;
        var a = (ContainerScreenAccessor) screen;
        var layout = LAYOUTS.get(screen);
        int left = a.saoui$left(), top = a.saoui$top(), work = layout.workWidth;
        if (screen instanceof RecipeScreenAccessor recipe) {
            recipe.saoui$narrow(false);
            for (var child : screen.children()) if (child instanceof AbstractWidget widget)
                widget.setPosition(left + work - 30, top + 8);
        }
        g.pose().pushMatrix();
        g.pose().translate(left, top);
        panel(g, 0, -36, work, FlatContainerLayout.height(), screen.getTitle().getString(), subtitle(layout.kind), "items");
        int playerX = layout.placement.backpackX(), playerY = layout.placement.backpackY();
        panel(g, playerX, playerY - 36, 222, FlatContainerLayout.height(), tr("inventory"), Minecraft.getInstance().player.getName().getString(), "profile");
        text(g, tr("bag"), playerX + 14, playerY + 8, ThemePalette.muted());
        text(g, tr("hotbar"), playerX + 14, playerY + 98, ThemePalette.muted());
        g.fill(playerX + 14, playerY + 91, playerX + 208, playerY + 92, ThemePalette.line());
        fitText(g, tr("controls"), playerX + 14, playerY + 151, 194, ThemePalette.muted());
        workflow(g, container.getMenu(), layout, mouseX - left, mouseY - top);
        Slot hovered = a.saoui$findSlot(mouseX, mouseY);
        if (hovered != a.saoui$hovered() && a.saoui$hovered() != null) a.saoui$stopHover(a.saoui$hovered());
        a.saoui$hovered(hovered);
        for (var slot : container.getMenu().slots) {
            if (!slot.isActive()) continue;
            boolean disabled = container.getMenu() instanceof CrafterMenu crafter && !playerSlot(slot) && slot.index < 9 && crafter.isSlotDisabled(slot.index);
            cell(g, slot.x - 2, slot.y - 2, 20, 20, slot == hovered, disabled);
            if (disabled) text(g, "×", slot.x + 5, slot.y + 4, ThemePalette.muted());
        }
        g.pose().popMatrix();

        ContainerCraftingUi.render(screen,g);
        nativeDetails(screen, g, mouseX, mouseY, delta, layout.kind != Kind.STORAGE && layout.kind != Kind.ENCHANTING);
        slotsAndCursor(screen, g, mouseX, mouseY);
    }
    static void nativeDetails(Screen screen, GuiGraphicsExtractor g, int mouseX, int mouseY, float delta, boolean drawBackground) {
        nativeGraphics = g;
        try {
            if (drawBackground) screen.extractBackground(g, mouseX, mouseY, delta);
            if (screen instanceof RecipeScreenAccessor recipe && recipe.saoui$book().isVisible()) {
                var book = (RecipeBookAccessor) recipe.saoui$book();
                panel(g, book.saoui$x() - 2, book.saoui$y() - 4, 150, 174, "", "", "");
                styleEdit(g, book.saoui$search());
            }
            Iterable<?> details = UniversalContainerUi.managed(screen)
                    ? ((io.github.saoui.mixin.ScreenRenderablesAccessor)screen).saoui$renderables() : screen.children();
            for (var child : details) {
                if (child instanceof RecipeBookComponent<?>) continue; // Recipe screen draws it once below.
                if (child instanceof EditBox edit) styleEdit(g, edit);
                if (child instanceof Renderable widget) widget.extractRenderState(g, mouseX, mouseY, delta);
            }
            screen.extractRenderState(g, mouseX, mouseY, delta);
            if (UniversalContainerUi.managed(screen)) {
                var a = (ContainerScreenAccessor)screen;
                g.pose().pushMatrix(); g.pose().translate(a.saoui$left(), a.saoui$top());
                a.saoui$labels(g, mouseX, mouseY);
                g.pose().popMatrix();
            }
        } finally { nativeGraphics = null; }
    }
    static void slotsAndCursor(Screen screen, GuiGraphicsExtractor g, int mouseX, int mouseY) {
        var container = (AbstractContainerScreen<?>)screen; var a = (ContainerScreenAccessor)screen;
        int left = a.saoui$left(), top = a.saoui$top();
        g.pose().pushMatrix();
        g.pose().translate(left, top);
        a.saoui$slots(g, mouseX, mouseY);
        g.pose().popMatrix();
        g.nextStratum();
        container.extractCarriedItem(g, mouseX, mouseY);
        a.saoui$tooltip(g, mouseX, mouseY);
    }

    private static void styleEdit(GuiGraphicsExtractor g, EditBox edit) {
        if (edit == null || !edit.isVisible()) return;
        edit.setTextColor(ThemePalette.ink()); edit.setTextColorUneditable(ThemePalette.muted()); edit.setTextShadow(false);
        cell(g, edit.getX() - 2, edit.getY() - 2, edit.getWidth() + 4, edit.getHeight() + 4, edit.isFocused(), false);
    }

    static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, String title, String sub, String icon) {
        g.fill(x + 3, y + 4, x + w + 3, y + h + 4, 0x24000000);
        g.fill(x, y, x + w, y + h, ThemePalette.background());
        g.fill(x, y, x + w, y + 2, ThemePalette.edge());
        g.fill(x, y, x + 3, y + 29, ThemePalette.accent());
        if (!title.isEmpty()) {
            if (!icon.isEmpty()) g.blit(RenderPipelines.GUI_TEXTURED, SaoUiClient.id("textures/sao/menu/icons/" + icon + ".png"), x + 10, y + 9, 0, 0, 22, 22, 64, 64, 64, 64, ThemePalette.ink());
            fitText(g, title, x + 40, y + 9, w - 50, ThemePalette.ink());
            fitText(g, sub, x + 40, y + 23, w - 50, ThemePalette.muted());
            g.fill(x + 12, y + 40, x + w - 12, y + 41, ThemePalette.line());
        }
    }

    public static void cell(GuiGraphicsExtractor g, int x, int y, int w, int h, boolean selected, boolean disabled) {
        g.fill(x, y, x + w, y + h, selected ? ThemePalette.accent() : disabled ? ThemePalette.disabled() : ThemePalette.line());
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, selected ? ThemePalette.selected() : disabled ? ThemePalette.disabled() : ThemePalette.cell());
    }
    private static void text(GuiGraphicsExtractor g, String value, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, value, x, y, color, false);
    }
    private static void fitText(GuiGraphicsExtractor g, String value, int x, int y, int width, int color) {
        var font = Minecraft.getInstance().font;
        float scale = Math.min(1, width / (float)Math.max(1, font.width(value)));
        g.pose().pushMatrix();
        g.pose().translate(x, y); g.pose().scale(scale);
        g.text(font, value, 0, 0, color, false);
        g.pose().popMatrix();
    }
    private static String tr(String key, Object... args) { return Component.translatable("saoui.container." + key, args).getString(); }
    private static String subtitle(Kind kind) { return tr("type." + kind.name().toLowerCase(java.util.Locale.ROOT)); }
    private static void arrow(GuiGraphicsExtractor g, int x, int y, int width, double progress) {
        g.fill(x, y + 5, x + width, y + 8, ThemePalette.line());
        g.fill(x, y + 5, x + (int)(width * Math.clamp(progress, 0, 1)), y + 8, ThemePalette.accent());
        g.fill(x + width - 3, y + 2, x + width, y + 11, ThemePalette.accent());
    }
    private static void bar(GuiGraphicsExtractor g, int x, int y, int w, double value) {
        g.fill(x, y, x + w, y + 4, ThemePalette.line());
        g.fill(x, y, x + (int)(w * Math.clamp(value, 0, 1)), y + 4, ThemePalette.accent());
    }
    private static void footer(GuiGraphicsExtractor g, Layout layout, String value) {
        g.fill(14, 142, layout.workWidth - 14, 143, ThemePalette.line());
        fitText(g, value, 14, 153, layout.workWidth - 28, ThemePalette.muted());
    }
    private static void workflow(GuiGraphicsExtractor g, AbstractContainerMenu menu, Layout l, int mx, int my) {
        switch (l.kind) {
            case STORAGE -> {
                int total = 0, occupied = 0;
                for (var slot : menu.slots) if (!playerSlot(slot) && (ContainerCraftingState.get(menu)==null || !ContainerCraftingState.get(menu).contains(slot.index))) { total++; if (slot.hasItem()) occupied++; }
                text(g, tr("storage"), 14, 8, ThemePalette.muted());
                text(g, tr("capacity", occupied, total), 14, 156, ThemePalette.muted());
                bar(g, 14, 168, l.workWidth - 28, occupied / (double)Math.max(1, total));
            }
            case SMELTING -> {
                var furnace = (AbstractFurnaceMenu) menu;
                text(g, tr("input"), 40, 18, ThemePalette.muted()); text(g, tr("output"), 147, 42, ThemePalette.muted());
                text(g, tr("fuel"), 40, 115, ThemePalette.muted());
                arrow(g, 82, 59, 56, furnace.getBurnProgress());
                bar(g, 44, 108, 30, furnace.getLitProgress());
                footer(g, l, tr(furnace.isLit() ? "smelting" : "idle"));
            }
            case CRAFTING, CRAFTER -> {
                text(g, tr("ingredients"), 28, 14, ThemePalette.muted()); text(g, tr("result"), 155, 42, ThemePalette.muted());
                arrow(g, 110, 59, 38, menu.getSlot(l.kind == Kind.CRAFTER ? (ContainerCraftingState.get(menu)==null?menu.slots.size():ContainerCraftingState.get(menu).base) - 1 : 0).hasItem() ? 1 : 0);
                footer(g, l, menu instanceof CrafterMenu crafter ? tr(crafter.isPowered() ? "powered" : "crafter_hint") : tr("crafting_hint"));
            }
            case ANVIL -> {
                text(g, tr("rename"), 14, 8, ThemePalette.muted());
                text(g, "+", 63, 77, ThemePalette.muted()); arrow(g, 118, 74, 30, menu.getSlot(2).hasItem() ? 1 : 0);
                var anvil = (AnvilMenu) menu;
                footer(g, l, anvil.getCost() > 0 ? tr("cost", anvil.getCost()) : tr("anvil_hint"));
            }
            case GRINDSTONE -> {
                text(g, tr("ingredients"), 28, 14, ThemePalette.muted()); text(g, tr("result"), 147, 42, ThemePalette.muted());
                text(g, "+", 51, 65, ThemePalette.muted());
                arrow(g, 82, 59, 56, menu.getSlot(2).hasItem() ? 1 : 0);
                footer(g, l, tr("grindstone_hint"));
            }
            case SMITHING -> {
                fitText(g, tr("template"), 14, 20, 36, ThemePalette.muted()); fitText(g, tr("base"), 58, 20, 36, ThemePalette.muted()); fitText(g, tr("material"), 102, 20, 36, ThemePalette.muted());
                arrow(g, 136, 39, 22, menu.getSlot(3).hasItem() ? 1 : 0);
                cell(g, 62, 66, 96, 68, false, false);
                footer(g, l, tr("smithing_hint"));
            }
            case STONECUTTER -> {
                text(g, tr("material"), 10, 8, ThemePalette.muted()); text(g, tr("recipes"), 54, 8, ThemePalette.muted());
                footer(g, l, tr("recipe_count", ((StonecutterMenu)menu).getNumberOfVisibleRecipes()));
            }
            case ENCHANTING -> {
                var enchant = (EnchantmentMenu) menu;
                for (int i = 0; i < 3; i++) {
                    int y = 14 + i * 19, cost = enchant.costs[i];
                    boolean enabled = cost > 0;
                    boolean hover = mx >= 60 && mx < 168 && my >= y && my < y + 19;
                    cell(g, 60, y, 108, 18, hover && enabled, !enabled);
                    text(g, tr("enchant_tier", i + 1), 65, y + 5, enabled ? ThemePalette.ink() : ThemePalette.muted());
                    text(g, cost > 0 ? "Lv." + cost : "—", 135, y + 5, enabled ? ThemePalette.ink() : ThemePalette.muted());
                }
                fitText(g, tr("item"), 12, 35, 20, ThemePalette.muted()); fitText(g, tr("catalyst"), 36, 35, 22, ThemePalette.muted());
                footer(g, l, tr("enchant_hint", Minecraft.getInstance().player.experienceLevel));
            }
            case BREWING -> {
                var brew = (BrewingStandMenu) menu;
                text(g, tr("fuel"), 18, 10, ThemePalette.muted()); text(g, tr("ingredient"), 82, 10, ThemePalette.muted());
                bar(g, 22, 49, 22, brew.getFuel() / (double)net.minecraft.world.level.block.entity.BrewingStandBlockEntity.FUEL_USES);
                double progress = brew.getBrewingTicks() <= 0 ? 0 : 1 - brew.getBrewingTicks() / (double)400;
                bar(g, 60, 55, 96, progress);
                g.fill(97, 47, 99, 74, ThemePalette.line()); g.fill(47, 73, 149, 75, ThemePalette.line());
                for (int x : new int[]{47, 97, 147}) g.fill(x, 73, x + 2, 81, ThemePalette.line());
                text(g, tr("bottles"), 80, 113, ThemePalette.muted());
                footer(g, l, tr(brew.getBrewingTicks() > 0 ? "brewing" : "brewing_hint"));
            }
            case BEACON -> {
                text(g, tr("primary"), 18, 8, ThemePalette.muted()); text(g, tr("secondary"), 144, 8, ThemePalette.muted());
                text(g, tr("payment"), 12, 110, ThemePalette.muted());
                footer(g, l, tr("beacon_level", ((BeaconMenu)menu).getLevels()));
            }
            case LOOM -> {
                text(g, tr("material"), 9, 8, ThemePalette.muted()); text(g, tr("patterns"), 59, 8, ThemePalette.muted());
                footer(g, l, tr("pattern_count", ((LoomMenu)menu).getSelectablePatterns().size()));
            }
            case CARTOGRAPHY -> {
                text(g, tr("material"), 9, 8, ThemePalette.muted()); text(g, tr("map_preview"), 81, 8, ThemePalette.muted());
                footer(g, l, tr("cartography_hint"));
            }
        }
    }

    /** Replace vanilla chrome only in the scoped details pass, retaining functional icons. */
    public static boolean sprite(GuiGraphicsExtractor g, Identifier id, int x, int y, int w, int h) {
        String p = id.getPath();
        if (p.equals("container/crafter/disabled_slot") && skinned(Minecraft.getInstance().gui.screen())) return true;
        if (!nativePass()) return false;
        if (UniversalContainerUi.managed(Minecraft.getInstance().gui.screen()) && UniversalContainerUi.sprite(g, id, x, y, w, h)) return true;
        if (p.startsWith("container/crafter/")) return true;
        if (p.startsWith("container/anvil/")) return true;
        if (p.contains("furnace/") || p.contains("brewing_stand/") || p.endsWith("/error")) return true;
        if (p.contains("scroller")) {
            g.fill(x, y, x + w, y + h, p.contains("disabled") ? ThemePalette.line() : ThemePalette.accent()); return true;
        }
        if (p.equals("recipe_book/button") || p.equals("recipe_book/button_highlighted")) {
            cell(g, x, y, w, h, p.contains("highlighted"), false);
            for (int row = 0; row < 3; row++) g.fill(x + 5, y + 4 + row * 4, x + w - 5, y + 5 + row * 4, ThemePalette.ink());
            return true;
        }
        if (p.contains("button") || p.contains("text_field") || p.contains("stonecutter/recipe")
                || p.contains("loom/pattern") || p.contains("recipe_book/slot") || p.contains("recipe_book/tab")
                || p.contains("cartography_table/")) {
            cell(g, x, y, w, h, p.contains("highlighted") || p.contains("selected"), p.contains("disabled"));
            return true;
        }
        return false;
    }

    public static void buttonLabel(AbstractWidget widget) {
        var font = Minecraft.getInstance().font;
        String label = font.plainSubstrByWidth(widget.getMessage().getString(), Math.max(0, widget.getWidth() - 6));
        text(nativeGraphics, label, widget.getX() + (widget.getWidth() - font.width(label)) / 2,
                widget.getY() + (widget.getHeight() - 8) / 2, widget.active ? ThemePalette.ink() : ThemePalette.muted());
    }
}
