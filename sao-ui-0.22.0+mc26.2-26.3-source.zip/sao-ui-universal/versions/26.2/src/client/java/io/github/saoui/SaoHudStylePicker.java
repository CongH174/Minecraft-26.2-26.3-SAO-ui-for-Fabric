package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** An in-place choice menu. Enum values provide an expandable list without another settings page. */
final class SaoHudStylePicker {
    final SaoButton control;
    private final Consumer<HudBarStyle> apply;
    private final List<SaoButton> options=new ArrayList<>();
    private HudBarStyle selected;
    private boolean open;
    private int highlighted,first,visible,left,top,width,height;
    SaoHudStylePicker(HudBarStyle initial,Consumer<HudBarStyle> apply){
        this.selected=initial==null?HudBarStyle.SAO:initial;this.apply=apply;
        control=new SaoButton(0,0,196,20,label(),null,()->{open=!open;if(open){highlighted=selected.ordinal();first=0;build();}});
    }
    private Component label(){return Component.translatable("settings.saoui.hud_style",Component.translatable(selected.titleKey()));}
    private void build(){options.clear();for(var style:HudBarStyle.values())options.add(new SaoButton(0,0,160,20,Component.translatable(style.titleKey()),Component.literal(style==selected?"✓ ":"  ").append(Component.translatable(style.titleKey())),null,()->choose(style)));}
    private void choose(HudBarStyle value){selected=value;apply.accept(value);control.setMessage(label());SettingsHelp.attach(control);open=false;}
    private void place(Screen screen){
        width=Math.min(Math.max(160,control.getWidth()),screen.width-16);visible=Math.max(1,Math.min(options.size(),(screen.height-24)/22));height=visible*22+4;
        left=Math.clamp(control.getX(),8,Math.max(8,screen.width-width-8));int below=control.getBottom()+2;
        top=Math.clamp(below+height<=screen.height-8?below:control.getY()-height-2,8,Math.max(8,screen.height-height-8));first=Math.clamp(first,0,Math.max(0,options.size()-visible));
        for(int i=0;i<options.size();i++){var button=options.get(i);button.visible=i>=first&&i<first+visible;button.setFocused(i==highlighted);button.setRectangle(width-4,20,left+2,top+2+(i-first)*22);}
    }
    void render(GuiGraphicsExtractor g,int mx,int my,float delta,Screen screen){if(!open)return;place(screen);g.nextStratum();g.fill(left+3,top+3,left+width+3,top+height+3,0x80000000);g.fill(left,top,left+width,top+height,ThemePalette.line());for(var option:options)if(option.visible)option.extractRenderState(g,mx,my,delta);}
    boolean click(MouseButtonEvent event,boolean doubleClick,Screen screen){
        if(!open)return false;place(screen);
        if(control.isMouseOver(event.x(),event.y())){open=false;return true;}
        if(event.x()>=left&&event.x()<left+width&&event.y()>=top&&event.y()<top+height){for(var option:options)if(option.visible&&option.mouseClicked(event,doubleClick))return true;return true;}
        open=false;return true;
    }
    boolean key(KeyEvent event){if(!open)return false;int key=event.key();if(key==InputConstants.KEY_ESCAPE)open=false;else if(key==InputConstants.KEY_UP||key==InputConstants.KEY_DOWN){highlighted=Math.floorMod(highlighted+(key==InputConstants.KEY_UP?-1:1),options.size());if(highlighted<first)first=highlighted;if(highlighted>=first+visible)first=highlighted-visible+1;}else if(key==InputConstants.KEY_RETURN||key==InputConstants.KEY_SPACE)choose(HudBarStyle.values()[highlighted]);return true;}
    boolean scroll(double amount){if(!open)return false;if(amount!=0)first=Math.clamp(first-(int)Math.copySign(1,amount),0,Math.max(0,options.size()-visible));return true;}
}
