package io.github.saoui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.saoui.BlockFloatingUi;
import io.github.saoui.FlatContainerUi;
import io.github.saoui.UiAppearance;
import io.github.saoui.SaoMenuScreen;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class FloatingScreenMixin {
    @WrapMethod(method = "extractRenderStateWithTooltipAndSubtitles")
    private void saoui$extract(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta, Operation<Void> original) {
        Screen screen = (Screen) (Object) this;
        if(screen instanceof SaoMenuScreen) {
            UiAppearance.background(g);UiAppearance.begin();
            try { original.call(g,mouseX,mouseY,delta); } finally { UiAppearance.end(); }
            return;
        }
        if (!BlockFloatingUi.active(screen)) { original.call(g, mouseX, mouseY, delta); return; }
        UiAppearance.background(g);
        var frame = BlockFloatingUi.update(screen, mouseX, mouseY);
        g.pose().pushMatrix();
        UiAppearance.begin();
        try {
            g.pose().translate((float) frame.x(), (float) frame.y());
            g.pose().scale((float) frame.scale());
            int x = (int) frame.localX(mouseX), y = (int) frame.localY(mouseY);
            if (FlatContainerUi.skinned(screen)) {
                FlatContainerUi.render(screen, g, x, y, delta);
                g.extractDeferredElements(x, y, delta);
            } else {
                BlockFloatingUi.extractBorder(screen, g);
                original.call(g, x, y, delta);
            }
        } finally { g.pose().popMatrix(); UiAppearance.end(); }
    }

    @Inject(method = {"extractBlurredBackground", "extractTransparentBackground"}, at = @At("HEAD"), cancellable = true)
    private void saoui$sharpWorld(GuiGraphicsExtractor g, CallbackInfo ci) {
        if (BlockFloatingUi.active((Screen) (Object) this)) ci.cancel();
    }
}
