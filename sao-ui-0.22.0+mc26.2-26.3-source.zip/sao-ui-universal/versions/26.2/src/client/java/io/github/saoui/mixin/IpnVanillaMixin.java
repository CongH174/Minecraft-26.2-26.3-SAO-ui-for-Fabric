package io.github.saoui.mixin;

import io.github.saoui.SaoMenuScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Let libIPN see the native InventoryMenu bridge while its normal hotkey handlers run. */
@Pseudo
@Mixin(targets="org.anti_ad.mc.common.vanilla.Vanilla",remap=false)
public abstract class IpnVanillaMixin {
    @Inject(method="screen",at=@At("RETURN"),cancellable=true,remap=false,require=0)
    private void saoui$inventoryScreen(CallbackInfoReturnable<Screen> cir){
        if(io.github.saoui.IpnInputScope.active() && cir.getReturnValue() instanceof SaoMenuScreen menu)cir.setReturnValue(menu.ipnScreen());
    }
}
