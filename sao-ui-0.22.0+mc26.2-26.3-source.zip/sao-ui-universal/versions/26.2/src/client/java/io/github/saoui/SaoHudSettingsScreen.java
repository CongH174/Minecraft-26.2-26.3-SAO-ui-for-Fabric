package io.github.saoui;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Two compact columns edit an isolated draft; the parent owns the final disk save. */
public final class SaoHudSettingsScreen extends Screen {
    private final Screen parent;
    private final Consumer<HudOptions> apply;
    private final HudOptions draft;
    private int left, top, step, rowHeight, columnWidth, panelWidth;
    public SaoHudSettingsScreen(Screen parent, HudOptions initial, Consumer<HudOptions> apply) {
        super(Component.translatable("settings.saoui.hud_bars"));
        this.parent = parent; this.apply = apply; draft = initial.copy();
    }
    @Override protected void init() {
        panelWidth = Math.min(430, width - 24); columnWidth = (panelWidth - 12) / 2;
        left = (width - panelWidth) / 2; rowHeight = Math.clamp((height - 105) / 6 - 3, 13, 21);
        step = rowHeight + 3; top = Math.max(2, (height - (30 + 6 * step + 48)) / 2);
        toggle(0, 0, "health", draft.health, () -> draft.health = !draft.health);
        toggle(0, 1, "hunger", draft.hunger, () -> draft.hunger = !draft.hunger);
        toggle(0, 2, "experience", draft.experience, () -> draft.experience = !draft.experience);
        toggle(0, 3, "armor", draft.armor, () -> draft.armor = !draft.armor);
        toggle(0, 4, "saturation", draft.saturation, () -> draft.saturation = !draft.saturation);
        toggle(1, 0, "hide_vanilla_health", draft.hideVanillaHealth, () -> draft.hideVanillaHealth = !draft.hideVanillaHealth);
        toggle(1, 1, "hide_vanilla_hunger", draft.hideVanillaHunger, () -> draft.hideVanillaHunger = !draft.hideVanillaHunger);
        toggle(1, 2, "hide_vanilla_experience", draft.hideVanillaExperience, () -> draft.hideVanillaExperience = !draft.hideVanillaExperience);
        toggle(1, 3, "hide_vanilla_armor", draft.hideVanillaArmor, () -> draft.hideVanillaArmor = !draft.hideVanillaArmor);
        toggle(1, 4, "hide_vanilla_crosshair", draft.hideVanillaCrosshair, () -> draft.hideVanillaCrosshair = !draft.hideVanillaCrosshair);
        int y = top + 30 + 5 * step + 3;
        addRenderableWidget(new SaoButton(left, y, columnWidth, rowHeight, Component.translatable("gui.done"), null,
                () -> { apply.accept(draft.copy()); onClose(); }));
        addRenderableWidget(new SaoButton(left + columnWidth + 12, y, columnWidth, rowHeight,
                Component.translatable("gui.cancel"), null, this::onClose));
    }
    private void toggle(int column, int row, String key, boolean enabled, Runnable change) {
        addRenderableWidget(new SaoButton(left + column * (columnWidth + 12), top + 30 + row * step, columnWidth, rowHeight,
                Component.translatable("settings.saoui.bar." + key, Component.translatable(enabled ? "options.on" : "options.off")),
                null, () -> { change.run(); rebuildWidgets(); }));
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xDA101820);
        g.text(font, title, left, top, 0xFFF3A72E, true);
        g.text(font, Component.translatable("settings.saoui.sao_column"), left, top + 17, 0xFFE2E9E7, false);
        g.text(font, Component.translatable("settings.saoui.vanilla_column"), left + columnWidth + 12, top + 17, 0xFFE2E9E7, false);
        int y = top + 30 + 5 * step + 3 + rowHeight + 8;
        g.text(font, Component.translatable("settings.saoui.hotbar_kept"), left, y, 0xFFE2E9E7, false);
        g.text(font, Component.translatable(AppleSkinBridge.AVAILABLE ? "settings.saoui.appleskin_ready" : "settings.saoui.appleskin_missing"), left, y + 10, 0xFFFFDF64, false);
        g.text(font, Component.translatable("settings.saoui.appleskin_sync"), left, y + 20, 0xFFB6C3CD, false);
        g.text(font, Component.translatable("settings.saoui.hud_draft_hint"), left, y + 30, 0xFFB6C3CD, false);
        super.extractRenderState(g, mouseX, mouseY, delta);
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
}
