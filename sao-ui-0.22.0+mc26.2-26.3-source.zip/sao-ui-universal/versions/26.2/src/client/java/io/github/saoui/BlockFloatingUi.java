package io.github.saoui;

import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.LongSupplier;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.HorseInventoryScreen;
import net.minecraft.client.gui.screens.inventory.MerchantScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Util;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.phys.Vec3;
import io.github.saoui.mixin.ContainerScreenAccessor;

/** Adds a world-origin entrance to native block menus without replacing their screens or menus. */
public final class BlockFloatingUi {
    private static final Map<Screen, State> STATES = new WeakHashMap<>();
    private static BlockPos pending;
    private static Object pendingLevel;
    private static long pendingAt;
    private static LongSupplier clock = Util::getMillis;

    private static final class State {
        final BlockPos block;
        final double sourceX, sourceY;
        final long openedAt;
        final ContainerUiProfile profile;
        long lastFrame;
        double driftX, driftY;
        int heldButtons;
        BlockSurfaceMotion.Frame frame = new BlockSurfaceMotion.Frame(1, 0, 0);
        State(BlockPos block, double sourceX, double sourceY, ContainerUiProfile profile) {
            this.block = block; this.sourceX = sourceX; this.sourceY = sourceY;
            this.profile = profile;
            openedAt = lastFrame = clock.getAsLong();
        }
    }

    private BlockFloatingUi() {}

    public static void register() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            var client = Minecraft.getInstance();
            if (player == client.player && level == client.level && client.gui.screen() == null) remember(hit.getBlockPos());
            return InteractionResult.PASS;
        });
    }

    static void remember(BlockPos position) {
        pending = position.immutable();
        pendingLevel = Minecraft.getInstance().level;
        pendingAt = clock.getAsLong();
    }

    public static void onScreenInit(Minecraft client, Screen screen) {
        // ScreenEvents also fires for the K menu's hidden native inventory bridge.
        if (client.player == null || client.level == null || screen != client.gui.screen()
                || !(screen instanceof AbstractContainerScreen<?>) || screen instanceof InventoryInteraction) return;
        if (STATES.containsKey(screen)) { FlatContainerUi.attach(screen); return; }
        boolean all = SaoUiClient.config().replaceAllContainers;
        if (!all && (!SaoUiClient.config().blockUiEnabled || screen instanceof InventoryScreen
                || screen instanceof CreativeModeInventoryScreen || screen instanceof HorseInventoryScreen
                || screen instanceof MerchantScreen)) return;
        boolean recentBlock = pending != null && pendingLevel == client.level && clock.getAsLong() - pendingAt <= 1800;
        if (!all && !recentBlock) return;
        BlockPos source = recentBlock ? pending : null;
        pending = null; pendingLevel = null;
        var target = source == null ? null : ContainerTargets.at(source);
        var profile = target == null ? SaoUiClient.config().containers.defaults.copy()
                : SaoUiClient.config().containers.resolve(target.block(), target.location()).copy();
        if (all) profile.enabled = true;
        if (!profile.enabled) return;
        double sourceX = .5, sourceY = .5;
        if (source != null) {
            Vec3 point = Vec3.atLowerCornerOf(source).add(.5, .7, .5);
            var relative = point.subtract(client.gameRenderer.mainCamera().position());
            var forward = client.gameRenderer.mainCamera().forwardVector();
            double dot = relative.x * forward.x() + relative.y * forward.y() + relative.z * forward.z();
            if (dot <= .05 && !all) return;
            if (dot > .05) {
                var ndc = client.gameRenderer.projectPointToScreen(point);
                if (Double.isFinite(ndc.x) && Double.isFinite(ndc.y)) {
                    sourceX = Math.clamp((ndc.x + 1) / 2, .04, .96);
                    sourceY = Math.clamp((1 - ndc.y) / 2, .04, .96);
                }
            }
        }
        STATES.put(screen, new State(source, sourceX, sourceY, profile));
        FlatContainerUi.attach(screen);
    }

    public static void tick(Minecraft client) {
        STATES.keySet().removeIf(screen -> screen != client.gui.screen());
        if (pending != null && (pendingLevel != client.level || clock.getAsLong() - pendingAt > 1800)) {
            pending = null; pendingLevel = null;
        }
    }

    public static boolean active(Screen screen) {
        return (SaoUiClient.config().blockUiEnabled || SaoUiClient.config().replaceAllContainers) && STATES.containsKey(screen) && Minecraft.getInstance().level != null;
    }
    public static ContainerUiProfile profile(Screen screen) { return STATES.get(screen).profile; }
    public static void holdPointer(Screen screen, int button, boolean held) {
        var state = STATES.get(screen);
        if (state == null || button < 0 || button >= 31) return;
        if (held) state.heldButtons |= 1 << button;
        else state.heldButtons &= ~(1 << button);
    }

    public static boolean ready(Screen screen) {
        State state = STATES.get(screen);
        return !active(screen) || state != null && UiEffects.elapsed(clock.getAsLong()-state.openedAt,SaoUiClient.config().animationRate()) >= BlockSurfaceMotion.OPEN_MILLIS;
    }

    public static BlockSurfaceMotion.Frame update(Screen screen, int mouseX, int mouseY) {
        State state = STATES.get(screen);
        if (state.heldButtons != 0) { state.lastFrame = clock.getAsLong(); return state.frame; }
        var bounds = FlatContainerUi.bounds(screen);
        long now = clock.getAsLong();
        double dt = Math.max(0, now - state.lastFrame) / 1000.0;
        state.lastFrame = now;
        double strength = SaoUiClient.config().parallaxAmount();
        double unit=UiEffects.unit(Minecraft.getInstance().getWindow().getHeight(),Minecraft.getInstance().getWindow().getGuiScale());
        state.driftX = UiMath.approach(state.driftX, Math.clamp((mouseX - screen.width / 2.0) / screen.width, -0.5, 0.5) * 18 * unit * strength, dt);
        state.driftY = UiMath.approach(state.driftY, Math.clamp((mouseY - screen.height / 2.0) / screen.height, -0.5, 0.5) * 14 * unit * strength, dt);
        double anchorX = bounds.x() + bounds.width() / 2.0, anchorY = bounds.y() + bounds.height() / 2.0;
        if (FlatContainerUi.skinned(screen)) {
            var anchor=FlatContainerUi.anchor(screen);anchorX=anchor.x();anchorY=anchor.y();
        }
        double extentX=Math.max(Math.abs(bounds.x()-anchorX+state.profile.containerX),Math.abs(bounds.x()+bounds.width()-anchorX+state.profile.containerX));
        double extentY=Math.max(Math.abs(bounds.y()-anchorY+state.profile.containerY),Math.abs(bounds.y()+bounds.height()-anchorY+state.profile.containerY));
        double scale=UiEffects.fit(UiEffects.scale(Minecraft.getInstance().getWindow().getHeight(),Minecraft.getInstance().getWindow().getGuiScale(),SaoUiClient.config().uiScale),screen.width,screen.height,2*extentX,2*extentY,14*unit);
        double cx=screen.width/2.0+state.profile.containerX*scale,cy=screen.height/2.0+state.profile.containerY*scale;
        state.driftX = BlockSurfaceMotion.clampDrift(state.driftX, cx + (bounds.x() - anchorX) * scale, bounds.width() * scale, screen.width, 6*unit);
        state.driftY = BlockSurfaceMotion.clampDrift(state.driftY, cy + (bounds.y() - anchorY) * scale, bounds.height() * scale, screen.height, 6*unit);
        state.frame = BlockSurfaceMotion.frameTo(UiEffects.elapsed(now-state.openedAt,SaoUiClient.config().animationRate()), state.sourceX * screen.width, state.sourceY * screen.height,
                anchorX, anchorY,
                cx, cy, scale, state.driftX, state.driftY);
        return state.frame;
    }

    public static BlockSurfaceMotion.Frame frame(Screen screen) { return STATES.get(screen).frame; }

    public static MouseButtonEvent pointer(Screen screen, MouseButtonEvent event) {
        if (!active(screen)) return event;
        var frame = frame(screen);
        return new MouseButtonEvent(frame.localX(event.x()), frame.localY(event.y()), event.buttonInfo());
    }

    public static void extractBorder(Screen screen, GuiGraphicsExtractor g) {
        var bounds = (ContainerScreenAccessor) screen;
        int x = bounds.saoui$left(), y = bounds.saoui$top(), w = bounds.saoui$width(), h = bounds.saoui$height();
        g.fill(x - 5, y - 5, x + w + 5, y + h + 5, 0xB0E3E8E3);
        g.fill(x - 5, y - 5, x + w + 5, y - 3, 0xF0F8FAF6);
        g.fill(x - 5, y - 5, x - 3, y + Math.min(32, h), 0xFFF0AD28);
    }

    // Deterministic game-test capture; production always uses real elapsed time.
    static void testClock(LongSupplier next) { clock = next == null ? Util::getMillis : next; }
    static BlockPos source(Screen screen) { return STATES.get(screen).block; }
}
