package io.github.saoui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public final class ConfigStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file;

    public ConfigStore(Path file) { this.file = file; }

    public SaoConfig load() {
        if (!Files.exists(file)) return new SaoConfig();
        try (var reader = Files.newBufferedReader(file)) {
            SaoConfig loaded = GSON.fromJson(reader, SaoConfig.class);
            if (loaded == null) throw new IOException("Empty configuration");
            return loaded.validated();
        } catch (IOException | RuntimeException error) {
            SaoUiClient.LOGGER.warn("Cannot read {}; using defaults", file, error);
            try {
                Files.copy(file, file.resolveSibling(file.getFileName() + ".invalid-" + System.currentTimeMillis()));
            } catch (IOException backupError) {
                SaoUiClient.LOGGER.warn("Cannot back up invalid configuration", backupError);
            }
            return new SaoConfig();
        }
    }

    public void save(SaoConfig config) throws IOException {
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), "saoui-", ".tmp");
        try {
            Files.writeString(temp, GSON.toJson(config.validated()) + "\n");
            try {
                Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }
}
