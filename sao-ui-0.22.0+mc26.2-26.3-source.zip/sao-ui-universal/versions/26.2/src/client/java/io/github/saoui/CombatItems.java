package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.component.ItemAttributeModifiers;

public final class CombatItems {
    public record Entry(ItemStack stack, int inventorySlot, EquipmentSlot equipmentSlot) {
        public Component location() {
            if (equipmentSlot != null) return Component.translatable("item.saoui." + equipmentSlot.getName());
            return Component.translatable(inventorySlot < 9 ? "item.saoui.hotbar" : "item.saoui.backpack",
                    inventorySlot < 9 ? inventorySlot + 1 : inventorySlot - 8);
        }
    }

    public record Stats(double damage, double speed, double reach, boolean ranged) {
        public double dps() { return damage * speed; }
    }

    private CombatItems() {}
    public static String number(double value) { return String.format(Locale.ROOT, "%.1f", value); }

    public static boolean isEnchantable(Player player, ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (stack.has(DataComponents.ENCHANTABLE) || !stack.getEnchantments().isEmpty()
                || !stack.getOrDefault(DataComponents.STORED_ENCHANTMENTS, net.minecraft.world.item.enchantment.ItemEnchantments.EMPTY).isEmpty()
                || stack.is(net.minecraft.world.item.Items.BOOK)) return true;
        return player.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                .listElements().anyMatch(enchantment -> enchantment.value().isSupportedItem(stack));
    }

    public static List<Entry> scan(Player player) {
        List<Entry> result = new ArrayList<>();
        for (int i = 0; i < 36; i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (isEnchantable(player, stack)) result.add(new Entry(stack, i, null));
        }
        for (var slot : new EquipmentSlot[]{EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
                EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = player.getItemBySlot(slot);
            if (isEnchantable(player, stack)) result.add(new Entry(stack, -1, slot));
        }
        return result;
    }

    public static Stats stats(Player player, ItemStack stack) {
        var range = stack.get(DataComponents.ATTACK_RANGE);
        return new Stats(attribute(player, stack, Attributes.ATTACK_DAMAGE),
                attribute(player, stack, Attributes.ATTACK_SPEED),
                range == null ? player.entityInteractionRange() : range.effectiveMaxRange(player),
                stack.getItem() instanceof ProjectileWeaponItem);
    }

    private static double attribute(Player player, ItemStack stack, Holder<Attribute> attribute) {
        double[] modifiers = {0, 0, 1};
        stack.forEachModifier(EquipmentSlot.MAINHAND, (type, modifier) -> {
            if (!type.equals(attribute)) return;
            switch (modifier.operation()) {
                case ADD_VALUE -> modifiers[0] += modifier.amount();
                case ADD_MULTIPLIED_BASE -> modifiers[1] += modifier.amount();
                case ADD_MULTIPLIED_TOTAL -> modifiers[2] *= 1 + modifier.amount();
            }
        });
        return attribute.value().sanitizeValue(CombatMath.attribute(player.getAttributeBaseValue(attribute),
                modifiers[0], modifiers[1], modifiers[2]));
    }
}
