package io.github.saoui.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.inventory.Slot;

@Mixin(AbstractContainerScreen.class)
public interface ContainerScreenAccessor {
    @Accessor("leftPos") int saoui$left();
    @Accessor("leftPos") void saoui$left(int value);
    @Accessor("topPos") int saoui$top();
    @Accessor("imageWidth") int saoui$width();
    @Accessor("imageHeight") int saoui$height();
    @Accessor("hoveredSlot") Slot saoui$hovered();
    @Accessor("hoveredSlot") void saoui$hovered(Slot slot);
    @Invoker("getHoveredSlot") Slot saoui$findSlot(double x, double y);
    @Invoker("onStopHovering") void saoui$stopHover(Slot slot);
    @Invoker("extractSlots") void saoui$slots(GuiGraphicsExtractor g, int x, int y);
    @Invoker("extractLabels") void saoui$labels(GuiGraphicsExtractor g, int x, int y);
    @Invoker("extractTooltip") void saoui$tooltip(GuiGraphicsExtractor g, int x, int y);
}
