package io.github.saoui;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Nested draft; parent save is the only operation that changes live configuration. */
public final class SaoEffectsSettingsScreen extends Screen {
    private final Screen parent;
    private final SaoConfig draft;
    private final Consumer<SaoConfig> apply;
    private int left,top,step;
    public SaoEffectsSettingsScreen(Screen parent,SaoConfig config,Consumer<SaoConfig> apply) {
        super(Component.translatable("settings.saoui.effects"));this.parent=parent;draft=config.copy();this.apply=apply;
    }
    @Override protected void init() {
        left=(width-280)/2;step=Math.clamp((height-64)/7,19,28);top=Math.max(4,(height-7*step-40)/2);
        slider(0,"ui_scale",draft.uiScale,v->draft.uiScale=v);
        effect(1,"parallax",draft.parallaxStrength,v->draft.parallaxStrength=v,"parallax_enabled",draft.parallaxEnabled,()->draft.parallaxEnabled=!draft.parallaxEnabled);
        effect(2,"animation_speed",draft.animationSpeed,v->draft.animationSpeed=v,"animations_enabled",draft.animationsEnabled,()->draft.animationsEnabled=!draft.animationsEnabled);
        effect(3,"blur",draft.blurStrength,v->draft.blurStrength=v,"blur_enabled",draft.blurEnabled,()->draft.blurEnabled=!draft.blurEnabled);
        slider(4,"opacity",draft.uiOpacity,v->draft.uiOpacity=v);
        addRenderableWidget(new SaoButton(left,top+24+5*step,280,20,Component.translatable("settings.saoui.effects.reset"),null,()->{
            draft.parallaxEnabled=draft.animationsEnabled=draft.blurEnabled=true;
            draft.uiScale=draft.parallaxStrength=draft.animationSpeed=draft.blurStrength=1;draft.uiOpacity=1.9f;rebuildWidgets();
        }));
        addRenderableWidget(new SaoButton(left,top+24+6*step,138,20,Component.translatable("gui.done"),null,()->{apply.accept(draft.copy());onClose();}));
        addRenderableWidget(new SaoButton(left+142,top+24+6*step,138,20,Component.translatable("gui.cancel"),null,this::onClose));
    }
    private void effect(int row,String key,float value,Consumer<Float> apply,String toggle,boolean enabled,Runnable change) {
        var slider=addRenderableWidget(new SaoSlider(left,top+24+row*step,192,20,"settings.saoui."+key,value,apply));
        SettingsHelp.attach(slider);
        addRenderableWidget(new SaoButton(left+196,top+24+row*step,84,20,Component.translatable("settings.saoui."+toggle,Component.translatable(enabled?"options.on":"options.off")),null,()->{change.run();rebuildWidgets();}));
    }
    private void slider(int row,String key,float value,Consumer<Float> apply) {
        var slider=addRenderableWidget(new SaoSlider(left,top+24+row*step,280,20,"settings.saoui."+key,value,apply));
        SettingsHelp.attach(slider);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float delta) {
        g.fill(0,0,width,height,0xED101820);g.text(font,title,left,top,ThemePalette.font(0xFFF3A72E),false);
        super.extractRenderState(g,x,y,delta);
    }
    @Override public boolean isPauseScreen(){return false;}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
}
