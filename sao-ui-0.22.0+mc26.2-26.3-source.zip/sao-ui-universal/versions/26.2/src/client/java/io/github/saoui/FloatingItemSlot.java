package io.github.saoui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** Projected inventory slot; equipment catalogue entries remain inspectable. */
public final class FloatingItemSlot extends Button {
    private MenuProjection projection;
    private ItemStack stack = ItemStack.EMPTY;
    private double x, y, size, opacity;
    private boolean selected, held;
    private InventoryInteraction inventory;
    private int menuSlot = -1;

    public FloatingItemSlot(Runnable select) {
        super(0, 0, 1, 1, Component.empty(), ignored -> select.run(), DEFAULT_NARRATION);
    }

    public void place(MenuProjection p, double x, double y, double size, ItemStack stack,
                      double opacity, boolean selected, boolean held, boolean active) {
        this.projection = p; this.x = x; this.y = y; this.size = size;
        this.stack = stack; this.opacity = opacity; this.selected = selected; this.held = held;
        this.active = active;
        visible = opacity > 0.01;
        setMessage(stack.isEmpty() ? Component.translatable("item.saoui.empty") : stack.getHoverName());
        var bounds = FloatingDraw.bounds(p, x, y, size, size);
        setX(bounds.left()); setY(bounds.top()); setWidth(bounds.width()); setHeight(bounds.height());
    }

    public ItemStack displayedStack() { return stack; }

    void bindInventory(InventoryInteraction inventory, int menuSlot) {
        this.inventory = inventory;
        this.menuSlot = menuSlot;
    }

    int menuSlot() { return menuSlot; }

    @Override public boolean isMouseOver(double mouseX, double mouseY) {
        if (!active || !visible || projection == null) return false;
        var at = projection.unproject(mouseX, mouseY);
        return at.x() >= x && at.x() < x + size && at.y() >= y && at.y() < y + size;
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        return isMouseOver(event.x(), event.y()) && super.mouseClicked(event, doubleClick);
    }

    @Override protected void extractContents(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (projection == null || opacity <= 0.01) return;
        boolean hover = isMouseOver(mouseX, mouseY);
        FloatingDraw.rect(g, projection, x, y, size, size,
                FloatingDraw.alpha(selected || hover || isFocused() ? ThemePalette.accent() : held ? 0xFF97AD99 : ThemePalette.line(), opacity));
        FloatingDraw.rect(g, projection, x + 0.8, y + 0.8, size - 1.6, size - 1.6,
                FloatingDraw.alpha(ThemePalette.cell(), opacity));
        if (opacity > 0.35) {
            if (inventory != null && menuSlot >= 0)
                inventory.extractProjectedSlot(g, projection, menuSlot, x + (size - 16) / 2, y + (size - 16) / 2);
            else if (!stack.isEmpty()) FloatingDraw.item(g, projection, stack, x + (size - 16) / 2, y + (size - 16) / 2);
            if (hover && !stack.isEmpty() && Minecraft.getInstance().player.inventoryMenu.getCarried().isEmpty())
                g.setTooltipForNextFrame(Minecraft.getInstance().font, stack, mouseX, mouseY);
        }
    }
}
