package io.github.saoui.mixin;

import io.github.saoui.BlockFloatingUi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.protocol.game.ClientboundOpenScreenPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Observe native server open packets, including plugin menus with no recent block use. */
@Mixin(ClientPacketListener.class)
public abstract class ServerContainerOpenMixin {
    @Inject(method = "handleOpenScreen", at = @At("RETURN"))
    private void saoui$serverOpen(ClientboundOpenScreenPacket packet, CallbackInfo ci) {
        var client = Minecraft.getInstance(); var screen = client.gui.screen();
        if (screen instanceof AbstractContainerScreen<?> container && container.getMenu().containerId == packet.getContainerId())
            BlockFloatingUi.onScreenInit(client, screen);
    }
}
