package io.github.saoui;

import java.util.List;
import java.util.ArrayList;
import java.util.function.BiConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;

/** Vanilla scrolling, clipping, mouse capture, focus and narration over SAO option widgets. */
final class SaoSettingsList extends ContainerObjectSelectionList<SaoSettingsList.Row> {
    private final int rowWidth;
    SaoSettingsList(Minecraft client,int width,int height,int top){super(client,width,height,top,24);rowWidth=Math.min(400,width-24);centerListVertically=false;}
    @Override public int getRowWidth(){return rowWidth;}
    @Override protected void extractListBackground(GuiGraphicsExtractor g){}
    void row(AbstractWidget... widgets){for(var widget:widgets)SettingsHelp.attach(widget);addEntry(new Row(List.of(widgets),null));}
    void drawing(int height,BiConsumer<GuiGraphicsExtractor,Row> draw){addEntry(new Row(List.of(),draw),height);}
    List<AbstractWidget> widgets(){var result=new ArrayList<AbstractWidget>();for(var row:children())result.addAll(row.widgets);return result;}
    void reveal(AbstractWidget widget){for(var row:children())if(row.widgets.contains(widget)){scrollToEntry(row);return;}}
    static final class Row extends ContainerObjectSelectionList.Entry<Row> {
        final List<AbstractWidget> widgets;
        private final BiConsumer<GuiGraphicsExtractor,Row> draw;
        Row(List<AbstractWidget> widgets,BiConsumer<GuiGraphicsExtractor,Row> draw){this.widgets=widgets;this.draw=draw;}
        private void position(){
            if(widgets.isEmpty())return;int width=(getContentWidth()-8*(widgets.size()-1))/widgets.size();
            for(int i=0;i<widgets.size();i++){var widget=widgets.get(i);widget.setWidth(width);widget.setPosition(getContentX()+i*(width+8),getContentY());}
        }
        @Override public void setX(int x){super.setX(x);position();}
        @Override public void setY(int y){super.setY(y);position();}
        @Override public void setWidth(int width){super.setWidth(width);position();}
        @Override public void extractContent(GuiGraphicsExtractor g,int x,int y,boolean hovered,float delta){position();if(draw!=null)draw.accept(g,this);for(var widget:widgets)widget.extractRenderState(g,x,y,delta);}
        @Override public List<? extends GuiEventListener> children(){return widgets;}
        @Override public List<? extends NarratableEntry> narratables(){return widgets;}
    }
}
