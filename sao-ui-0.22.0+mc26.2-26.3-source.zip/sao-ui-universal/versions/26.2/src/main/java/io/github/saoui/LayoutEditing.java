package io.github.saoui;

/** Coordinate conversions shared by visual editors, independent of rendering and inventory state. */
public final class LayoutEditing {
    public static int snap(double value,double minimum,double maximum,double threshold){
        double v=Math.clamp(value,minimum,Math.max(minimum,maximum));
        for(double anchor:new double[]{minimum,(minimum+maximum)/2,maximum})if(Math.abs(v-anchor)<=threshold)return (int)Math.round(anchor);
        return (int)Math.round(v);
    }
    public static int referenceOffset(double pointer,double grab,double unit,double viewport,double extent){
        return Math.clamp((int)Math.round(snap(pointer-grab,0,Math.max(0,viewport-extent),6*unit)/Math.max(.001,unit)),0,8192);
    }
    private LayoutEditing(){}
}
