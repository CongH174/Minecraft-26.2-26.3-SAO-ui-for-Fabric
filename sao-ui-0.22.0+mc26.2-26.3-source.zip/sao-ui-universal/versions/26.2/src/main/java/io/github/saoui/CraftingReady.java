package io.github.saoui;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
public record CraftingReady(int menuId,int baseSlots) implements CustomPacketPayload {
    public static final Type<CraftingReady> TYPE=new Type<>(Identifier.fromNamespaceAndPath("saoui","crafting_ready_v1"));
    public static final StreamCodec<RegistryFriendlyByteBuf,CraftingReady> CODEC=CustomPacketPayload.codec(CraftingReady::write,CraftingReady::new);
    private CraftingReady(RegistryFriendlyByteBuf b){this(b.readVarInt(),b.readVarInt());}
    private void write(RegistryFriendlyByteBuf b){b.writeVarInt(menuId);b.writeVarInt(baseSlots);}
    @Override public Type<CraftingReady> type(){return TYPE;}
}
