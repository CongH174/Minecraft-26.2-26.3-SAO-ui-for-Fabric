package io.github.saoui;

/** Shared, deterministic effect values and physical-window scaling. */
public final class UiEffects {
    public static float value(float value, float fallback) {
        return Math.round(Math.clamp(Float.isFinite(value) ? value : fallback, .2f, 2f) * 100f) / 100f;
    }
    public static long elapsed(long millis, float speed) {
        return speed <= 0 ? 1_000_000L : Math.round(Math.max(0, millis) * (double)speed);
    }
    // 480 physical pixels high is the design reference. Never use vanilla GUI scale as a size preference.
    public static double unit(int physicalHeight, int nativeGuiScale) {
        return Math.max(1, physicalHeight) / 480.0 / Math.max(1, nativeGuiScale);
    }
    public static double scale(int physicalHeight, int nativeGuiScale, float requested) {
        return unit(physicalHeight, nativeGuiScale) * value(requested, 1);
    }
    public static double fit(double requested, double width, double height, double contentWidth, double contentHeight, double margin) {
        return Math.max(.001, Math.min(requested, Math.min(Math.max(1,width-2*margin)/Math.max(1,contentWidth), Math.max(1,height-2*margin)/Math.max(1,contentHeight))));
    }
    public static int alpha(int color, float opacity) {
        return color & 0xFFFFFF | (int)Math.round((color >>> 24) * value(opacity, 1.9f) / 2.0) << 24;
    }
    public static int blurRadius(float strength) { return strength<=0?0:Math.round(value(strength, 1) * 5); }
    private UiEffects() {}
}
