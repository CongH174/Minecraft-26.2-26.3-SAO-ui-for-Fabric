package io.github.saoui;

import java.util.Locale;

/** Persisted panel colors; HUD status colors deliberately remain independent. */
public final class UiTheme {
    public static final int DEFAULT_BACKGROUND = 0xE3E8E3, DEFAULT_ACCENT = 0xF1B438;
    public int background = DEFAULT_BACKGROUND;
    public int accent = DEFAULT_ACCENT;
    public int font = 0x404443;
    public boolean customFont = false;
    public UiTheme validated() {
        if(background < 0 || background > 0xFFFFFF) background = DEFAULT_BACKGROUND;
        if(accent < 0 || accent > 0xFFFFFF) accent = DEFAULT_ACCENT;
        if(font < 0 || font > 0xFFFFFF) font=0x404443;
        return this;
    }
    public UiTheme copy() { var t = new UiTheme(); t.background=background; t.accent=accent; t.font=font; t.customFont=customFont; return t; }
    public static Integer parse(String value) {
        if(value==null) return null;
        String s=value.trim(); if(s.startsWith("#")) s=s.substring(1);
        if(!s.matches("[0-9a-fA-F]{6}")) return null;
        return Integer.parseInt(s,16);
    }
    public static String hex(int color) { return String.format(Locale.ROOT,"#%06X",color & 0xFFFFFF); }
    public static int mix(int a,int b,double ratio) {
        double t=Math.clamp(ratio,0,1); int rgb=0;
        for(int shift:new int[]{16,8,0}) rgb|=(int)Math.round(((a>>shift)&255)*(1-t)+((b>>shift)&255)*t)<<shift;
        return 0xFF000000|rgb;
    }
    private static double linear(int channel) { double v=channel/255.0; return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4); }
    public static double luminance(int color) { return .2126*linear(color>>16&255)+.7152*linear(color>>8&255)+.0722*linear(color&255); }
    public static int text(int background) { return luminance(background)>.179?0xFF000000:0xFFFFFFFF; }
}
