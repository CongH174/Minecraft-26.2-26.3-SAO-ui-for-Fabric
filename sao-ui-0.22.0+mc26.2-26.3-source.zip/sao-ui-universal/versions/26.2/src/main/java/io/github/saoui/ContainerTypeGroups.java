package io.github.saoui;

import java.util.Set;

/** User-facing vanilla families; coordinate identities continue to use the actual block ID. */
public final class ContainerTypeGroups {
    private static final Set<String> COLORS = Set.of("white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black");
    public static String key(String block) {
        if ("minecraft:chipped_anvil".equals(block) || "minecraft:damaged_anvil".equals(block)) return "minecraft:anvil";
        if (block != null && block.startsWith("minecraft:") && block.endsWith("_shulker_box")) {
            String color = block.substring(10, block.length() - "_shulker_box".length());
            if (COLORS.contains(color)) return "minecraft:shulker_box";
        }
        return block;
    }
    private ContainerTypeGroups() {}
}
