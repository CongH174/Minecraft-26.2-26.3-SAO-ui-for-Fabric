package io.github.saoui.mixin.common;
import io.github.saoui.ContainerCraftingState;
import io.github.saoui.CraftingExtension;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
@Mixin(AbstractContainerMenu.class)
public abstract class ContainerCraftingMixin implements CraftingExtension {
    @Unique private ContainerCraftingState saoui$crafting;
    @Override public ContainerCraftingState saoui$crafting(){return saoui$crafting;}
    @Override public void saoui$crafting(ContainerCraftingState state){saoui$crafting=state;}
    @WrapMethod(method="clicked")
    private void saoui$click(int id,int button,ContainerInput input,Player player,Operation<Void> original){
        var state=saoui$crafting;
        if(state==null){original.call(id,button,input,player);return;}
        state.currentInput=input;
        try{
            if(state.contains(id)&&input==ContainerInput.QUICK_MOVE){state.shift(id);return;}
            original.call(id,button,input,player);
        }finally{state.currentInput=null;}
    }
    @WrapMethod(method="moveItemStackTo")
    private boolean saoui$nativeQuickMove(ItemStack stack,int start,int end,boolean reverse,Operation<Boolean> original){
        // Original menus sometimes use slots.size() as their inventory range.
        // Keep their Shift-transfer behavior inside the original slots.
        if(saoui$crafting!=null)end=Math.min(end,saoui$crafting.base);
        return start<end&&original.call(stack,start,end,reverse);
    }
    @Inject(method="removed",at=@At("HEAD"))
    private void saoui$returnIngredients(Player player,CallbackInfo ci){if(saoui$crafting!=null)saoui$crafting.close();}
}
