package io.github.saoui;
public interface CraftingExtension {
    ContainerCraftingState saoui$crafting();
    void saoui$crafting(ContainerCraftingState state);
}
