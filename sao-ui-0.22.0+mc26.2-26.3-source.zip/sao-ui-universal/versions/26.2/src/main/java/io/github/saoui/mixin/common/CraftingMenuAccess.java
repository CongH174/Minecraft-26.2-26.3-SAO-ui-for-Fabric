package io.github.saoui.mixin.common;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(AbstractContainerMenu.class)
public interface CraftingMenuAccess {
    @Invoker("addSlot") Slot saoui$addSlot(Slot slot);
    @Invoker("moveItemStackTo") boolean saoui$move(ItemStack stack,int start,int end,boolean reverse);
    @Invoker("clearContainer") void saoui$clear(Player player,Container container);
    @Accessor("synchronizer") ContainerSynchronizer saoui$synchronizer();
}
