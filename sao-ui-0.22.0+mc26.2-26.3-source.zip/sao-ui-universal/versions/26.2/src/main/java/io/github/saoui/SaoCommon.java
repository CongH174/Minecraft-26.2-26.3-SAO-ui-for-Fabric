package io.github.saoui;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import io.github.saoui.mixin.common.CraftingMenuAccess;

/** Optional server companion in the same universal jar; vanilla clients keep unchanged menus. */
public final class SaoCommon implements ModInitializer {
    @Override public void onInitialize(){
        PayloadTypeRegistry.serverboundPlay().register(CraftingRequest.TYPE,CraftingRequest.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(CraftingReady.TYPE,CraftingReady.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(CraftingRequest.TYPE,(request,context)->{
            var player=context.player();var menu=player.containerMenu;
            if(request.menuId()<=0||menu.containerId!=request.menuId()||player.isSpectator()||player.isDeadOrDying()
                    ||!menu.stillValid(player)||!ServerPlayNetworking.canSend(player,CraftingReady.TYPE))return;
            var current=ContainerCraftingState.get(menu);
            if(current==null){
                if(menu.slots.size()!=request.baseSlots()||menu.slots.stream().filter(s->s.container==player.getInventory()&&s.getContainerSlot()>=0&&s.getContainerSlot()<36).count()<9)return;
                current=ContainerCraftingState.attach(menu,player);
            }
            // Attach message precedes full vanilla content sync on this connection.
            ServerPlayNetworking.send(player,new CraftingReady(menu.containerId,current.base));
            var synchronizer=((CraftingMenuAccess)menu).saoui$synchronizer();
            if(synchronizer!=null)menu.setSynchronizer(synchronizer);else menu.sendAllDataToRemote();
        });
    }
}
