package io.github.saoui;

public final class MenuMotion {
    public static final int OPEN_MILLIS = 520;
    public static final int CLOSE_MILLIS = 240;
    public static final int PANEL_MILLIS = 260;
    private MenuMotion() {}

    public static double progress(long elapsed, long delay, long duration) {
        return Math.clamp((elapsed - delay) / (double) duration, 0, 1);
    }

    public static double out(double t) { return 1 - Math.pow(1 - Math.clamp(t, 0, 1), 3); }
    public static double in(double t) { return Math.pow(Math.clamp(t, 0, 1), 3); }

    public static double pop(double t) {
        double u = Math.clamp(t, 0, 1) - 1;
        return 1 + 2.70158 * u * u * u + 1.70158 * u * u;
    }

    public static double orb(long elapsed, int index) {
        return progress(elapsed, index * 32L, 340);
    }
}
