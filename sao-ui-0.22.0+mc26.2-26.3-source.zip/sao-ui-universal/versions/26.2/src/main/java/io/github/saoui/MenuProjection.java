package io.github.saoui;

/** Perspective projection and its inverse for a plane floating in front of the viewer. */
public final class MenuProjection {
    public record Point(double x, double y) {}
    public record Tangent(double xx, double xy, double yx, double yy, double x, double y) {}
    private final double anchorX, anchorY, a, c, d, wx, wy, w0;

    public MenuProjection(double anchorX, double anchorY, double scale, double depth,
                          double yawDegrees, double pitchDegrees) {
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        double yaw = Math.toRadians(yawDegrees), pitch = Math.toRadians(pitchDegrees);
        double focal = 520;
        a = scale * focal * Math.cos(yaw);
        c = scale * focal * Math.sin(pitch) * Math.sin(yaw);
        d = scale * focal * Math.cos(pitch);
        wx = -Math.cos(pitch) * Math.sin(yaw);
        wy = Math.sin(pitch);
        w0 = focal + depth;
    }

    public Point project(double x, double y) {
        double w = w0 + wx * x + wy * y;
        return new Point(anchorX + a * x / w, anchorY + (c * x + d * y) / w);
    }

    public Point unproject(double screenX, double screenY) {
        double u = screenX - anchorX, v = screenY - anchorY;
        double aa = a - u * wx, ab = -u * wy;
        double ba = c - v * wx, bb = d - v * wy;
        double determinant = aa * bb - ab * ba;
        return new Point(w0 * (u * bb - ab * v) / determinant,
                         w0 * (aa * v - u * ba) / determinant);
    }

    /** A local tangent for native font glyphs and icons, avoiding a separate font renderer. */
    public Tangent tangent(double x, double y) {
        double w = w0 + wx * x + wy * y, square = w * w;
        Point at = project(x, y);
        double ny = c * x + d * y;
        return new Tangent((a * w - a * x * wx) / square, (c * w - ny * wx) / square,
                -a * x * wy / square, (d * w - ny * wy) / square, at.x(), at.y());
    }
}
