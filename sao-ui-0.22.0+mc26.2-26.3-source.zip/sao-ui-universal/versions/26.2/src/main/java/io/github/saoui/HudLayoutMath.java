package io.github.saoui;

/** HUD offsets are measured from the selected screen edge; text orientation is independent. */
public final class HudLayoutMath {
    public static int left(int offset,double unit,int viewport,int extent,boolean right){
        int margin=(int)Math.round(offset*unit);
        return UiMath.fitPosition(right?viewport-extent-margin:margin,viewport,extent);
    }
    public static int dragOffset(double pointer,double grab,double unit,int viewport,int extent,boolean right){
        double x=LayoutEditing.snap(pointer-grab,0,Math.max(0,viewport-extent),6*unit);
        return Math.clamp((int)Math.round((right?viewport-extent-x:x)/Math.max(.001,unit)),0,8192);
    }
    private HudLayoutMath(){}
}
