package io.github.saoui;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;

public final class SaoConfig {
    public boolean hudEnabled = true;
    public HudOptions hud = new HudOptions();
    public UiTheme theme = new UiTheme();
    public boolean smoothHealth = true;
    public boolean parallaxEnabled = true, animationsEnabled = true, blurEnabled = true;
    public float scale = 1f;
    public float uiScale = 1f;
    public float animationSpeed = 1f;
    public float healthSmoothing = 1f;
    public float blurStrength = 1f;
    public float uiOpacity = 1.9f;
    public int x = 12;
    public int y = 12;
    public List<String> moduleOrder = new ArrayList<>(MenuModule.defaultOrder());
    public List<String> hiddenModules = new ArrayList<>();
    public String homeModule = MenuModule.PROFILE.id();
    public boolean blockUiEnabled = true;
    public boolean replaceAllContainers = false;
    public float parallaxStrength = 1f;
    public boolean armorSlotsVisible = true;
    public boolean craftingVisible = true;
    public boolean enchantmentDetailsVisible = true;
    public boolean enchantmentDescriptions = true;
    public boolean syncedEnchantmentEffects = true;
    public boolean serverEnchantmentLore = true;
    public boolean ipnIntegration = true;
    public boolean containerCraftingVisible = true;
    public ContainerUiRules containers = new ContainerUiRules();

    public SaoConfig validated() {
        if(parallaxStrength<=0)parallaxEnabled=false;
        if(animationSpeed<=0)animationsEnabled=false;
        if(blurStrength<=0)blurEnabled=false;
        if(healthSmoothing<=0)smoothHealth=false;
        scale = UiEffects.value(scale, 1);
        uiScale = UiEffects.value(uiScale, 1);
        animationSpeed = UiEffects.value(animationSpeed, 1);
        healthSmoothing = UiEffects.value(healthSmoothing, 1);
        blurStrength = UiEffects.value(blurStrength, 1);
        uiOpacity = UiEffects.value(uiOpacity, 1.9f);
        x = Math.clamp(x, 0, 8192);
        y = Math.clamp(y, 0, 8192);
        parallaxStrength = UiEffects.value(parallaxStrength, 1);
        hud = hud == null ? new HudOptions() : hud.validated();
        theme = theme == null ? new UiTheme() : theme.validated();
        containers = containers == null ? new ContainerUiRules() : containers.validated();
        var order = new LinkedHashSet<String>();
        if (moduleOrder != null) for (String id : moduleOrder) if (MenuModule.fromId(id) != null) order.add(id);
        order.addAll(MenuModule.defaultOrder());
        moduleOrder = new ArrayList<>(order);
        var hidden = new LinkedHashSet<String>();
        if (hiddenModules != null) for (String id : hiddenModules) {
            var module = MenuModule.fromId(id);
            if (module != null && module.canHide()) hidden.add(id);
        }
        hiddenModules = new ArrayList<>(hidden);
        var home = MenuModule.fromId(homeModule);
        if (home == null || !moduleEnabled(home)) homeModule = enabledModules().getFirst().id();
        return this;
    }

    public float animationRate(){return animationsEnabled?animationSpeed:0;}
    public float parallaxAmount(){return parallaxEnabled?parallaxStrength:0;}
    public float blurAmount(){return blurEnabled?blurStrength:0;}

    public boolean moduleEnabled(MenuModule module) {
        return !module.canHide() || hiddenModules == null || !hiddenModules.contains(module.id());
    }

    public List<MenuModule> enabledModules() {
        return (moduleOrder == null ? MenuModule.defaultOrder() : moduleOrder).stream()
                .map(MenuModule::fromId).filter(Objects::nonNull).filter(this::moduleEnabled).toList();
    }

    public MenuModule home() { return MenuModule.fromId(homeModule); }

    public void resetHud() {
        hudEnabled = smoothHealth = parallaxEnabled = animationsEnabled = blurEnabled = true;
        hud = new HudOptions();
        scale = uiScale = animationSpeed = healthSmoothing = blurStrength = 1f;
        uiOpacity = 1.9f;
        x = y = 12;
        blockUiEnabled = true;
        replaceAllContainers = false;
        parallaxStrength = 1f;
        armorSlotsVisible = true;
        craftingVisible = true;
        enchantmentDetailsVisible = ipnIntegration = containerCraftingVisible = true;
        enchantmentDescriptions = syncedEnchantmentEffects = serverEnchantmentLore = true;
    }

    public void resetModules() {
        moduleOrder = new ArrayList<>(MenuModule.defaultOrder());
        hiddenModules = new ArrayList<>();
        homeModule = MenuModule.PROFILE.id();
    }

    public SaoConfig copy() {
        SaoConfig copy = new SaoConfig();
        copy.hudEnabled = hudEnabled;
        copy.hud = hud == null ? new HudOptions() : hud.copy();
        copy.theme = theme == null ? new UiTheme() : theme.copy();
        copy.smoothHealth = smoothHealth;
        copy.parallaxEnabled=parallaxEnabled;copy.animationsEnabled=animationsEnabled;copy.blurEnabled=blurEnabled;
        copy.scale = scale;
        copy.uiScale = uiScale;
        copy.animationSpeed = animationSpeed;
        copy.healthSmoothing = healthSmoothing;
        copy.blurStrength = blurStrength;
        copy.uiOpacity = uiOpacity;
        copy.x = x;
        copy.y = y;
        copy.moduleOrder = moduleOrder == null ? null : new ArrayList<>(moduleOrder);
        copy.hiddenModules = hiddenModules == null ? null : new ArrayList<>(hiddenModules);
        copy.homeModule = homeModule;
        copy.blockUiEnabled = blockUiEnabled;
        copy.replaceAllContainers = replaceAllContainers;
        copy.parallaxStrength = parallaxStrength;
        copy.armorSlotsVisible = armorSlotsVisible;
        copy.craftingVisible = craftingVisible;
        copy.enchantmentDetailsVisible = enchantmentDetailsVisible;
        copy.enchantmentDescriptions = enchantmentDescriptions;
        copy.syncedEnchantmentEffects = syncedEnchantmentEffects;
        copy.serverEnchantmentLore = serverEnchantmentLore;
        copy.ipnIntegration = ipnIntegration;
        copy.containerCraftingVisible = containerCraftingVisible;
        copy.containers = containers == null ? new ContainerUiRules() : containers.copy();
        return copy;
    }
}
