package io.github.saoui;

/** Vanilla attribute operation order, without temporarily equipping or mutating the player. */
public final class CombatMath {
    private CombatMath() {}

    public static double attribute(double base, double add, double multipliedBase, double multipliedTotal) {
        double value = (base + add) * (1 + multipliedBase) * multipliedTotal;
        return Double.isFinite(value) ? Math.max(0, value) : 0;
    }
}
