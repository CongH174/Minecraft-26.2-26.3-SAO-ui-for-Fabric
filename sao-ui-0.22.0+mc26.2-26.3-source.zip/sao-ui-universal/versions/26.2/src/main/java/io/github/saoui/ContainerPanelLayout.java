package io.github.saoui;

/** Module placement in GUI units. Workstation hit regions keep their native local origin. */
public final class ContainerPanelLayout {
    public record Rect(int x, int y, int width, int height) {
        public double centerX() { return x + width / 2.0; }
        public double centerY() { return y + height / 2.0; }
        public Rect union(Rect b) {
            int left = Math.min(x, b.x), top = Math.min(y, b.y);
            return new Rect(left, top, Math.max(x + width, b.x + b.width) - left, Math.max(y + height, b.y + b.height) - top);
        }
    }
    public record Placement(int backpackX, int backpackY, Rect baseline, Rect bounds) {}
    private ContainerPanelLayout() {}
    public static Placement place(int workWidth, ContainerUiProfile p) {
        int bx = 0, by = 0;
        switch (p.backpackSide) {
            case RIGHT -> bx = workWidth + p.gap;
            case LEFT -> bx = -222 - p.gap;
            case BELOW -> by = FlatContainerLayout.height() + p.gap;
            case ABOVE -> by = -FlatContainerLayout.height() - p.gap;
        }
        var work = new Rect(0, -36, workWidth, FlatContainerLayout.height());
        var baseline = work.union(new Rect(bx, by - 36, 222, FlatContainerLayout.height()));
        bx += p.backpackX - p.containerX; by += p.backpackY - p.containerY;
        return new Placement(bx, by, baseline, work.union(new Rect(bx, by - 36, 222, FlatContainerLayout.height())));
    }
}
