package io.github.saoui;

/** Native InventoryMenu slot IDs: result 0, four crafting inputs 1..4. */
public final class PlayerCraftingLayout {
    public static final int X=322,Y=-124,WIDTH=118,HEIGHT=206;
    public record Point(int x,int y){}
    public static Point slot(int id){
        if(id==0)return new Point(X+49,-4);
        if(id<1||id>4)throw new IllegalArgumentException("Not a player crafting slot: "+id);
        return new Point(X+37+((id-1)%2)*24,-78+((id-1)/2)*24);
    }
    public static int menuWidth(boolean crafting){return crafting?X+WIDTH+8+204:522;}
    private PlayerCraftingLayout(){}
}
