package io.github.saoui;

/** A complete, portable presentation preset. Rendering and menu behavior are independent. */
public final class ContainerUiProfile {
    public enum Side { RIGHT, BELOW, LEFT, ABOVE }
    public boolean enabled = true;
    public Side backpackSide = Side.RIGHT;
    public int gap = 18;
    public int containerX, containerY, backpackX, backpackY;

    public ContainerUiProfile validated() {
        if (backpackSide == null) backpackSide = Side.RIGHT;
        gap = Math.clamp(gap, 0, 96);
        containerX = Math.clamp(containerX, -200, 200);
        containerY = Math.clamp(containerY, -200, 200);
        backpackX = Math.clamp(backpackX, -200, 200);
        backpackY = Math.clamp(backpackY, -200, 200);
        return this;
    }

    public ContainerUiProfile copy() {
        var p = new ContainerUiProfile();
        p.enabled = enabled; p.backpackSide = backpackSide; p.gap = gap;
        p.containerX = containerX; p.containerY = containerY;
        p.backpackX = backpackX; p.backpackY = backpackY;
        return p;
    }
}
