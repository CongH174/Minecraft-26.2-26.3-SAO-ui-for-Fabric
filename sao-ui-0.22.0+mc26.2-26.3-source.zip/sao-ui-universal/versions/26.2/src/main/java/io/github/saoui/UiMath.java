package io.github.saoui;

/** Pure layout/animation calculations; no Minecraft classes or render state. */
public final class UiMath {
    private UiMath() {}

    public static float ratio(float value, float maximum) {
        if (!Float.isFinite(value) || !Float.isFinite(maximum) || maximum <= 0) return 0;
        return Math.clamp(value / maximum, 0, 1);
    }

    public static double approach(double current, double target, double seconds) {
        if (!Double.isFinite(target)) target = 0;
        if (!Double.isFinite(current)) return target;
        if (!Double.isFinite(seconds) || seconds <= 0) return current;
        return target + (current - target) * Math.exp(-10 * Math.min(seconds, 1));
    }

    public static float fitScale(int width, int height, float scale, int contentWidth, int contentHeight) {
        if (!Float.isFinite(scale)) scale = 1;
        return Math.max(0.05f, Math.min(Math.clamp(scale, 0.5f, 2f),
                Math.min(Math.max(1, width - 8) / (float) contentWidth,
                         Math.max(1, height - 8) / (float) contentHeight)));
    }

    public static int fitPosition(int requested, int viewport, int extent) {
        return Math.clamp(requested, 0, Math.max(0, viewport - extent));
    }
}
