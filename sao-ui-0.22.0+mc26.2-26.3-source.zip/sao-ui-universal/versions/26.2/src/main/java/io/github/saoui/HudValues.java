package io.github.saoui;

/** Bounded native display values and effect presentation, independent of rendering. */
public record HudValues(float health, float maximum, float absorption, int food, float saturation,
                        float experience, int level, int armor, Condition condition) {
    public enum Condition { NORMAL, POISONED, WITHERED }
    public HudValues(float health, float maximum, float absorption, int food, float saturation,
                     float experience, int level, int armor) {
        this(health, maximum, absorption, food, saturation, experience, level, armor, Condition.NORMAL);
    }
    public static Condition condition(boolean poisoned, boolean withered) {
        return withered ? Condition.WITHERED : poisoned ? Condition.POISONED : Condition.NORMAL;
    }
    public float foodRatio() { return UiMath.ratio(food, 20); }
    public float saturationRatio() { return Float.isFinite(saturation) ? UiMath.ratio(Math.min(saturation, Math.max(0, food)), 20) : 0; }
    public float absorptionRatio() { return UiMath.ratio(absorption, maximum); }
    public float experienceRatio() { return Float.isFinite(experience) ? Math.clamp(experience, 0, 1) : 0; }
    public float armorRatio() { return UiMath.ratio(armor, 20); }
    public boolean hasSaturation() { return Float.isFinite(saturation); }
    public int healthTint() {
        if (condition == Condition.WITHERED) return 0xFF29272D;
        if (condition == Condition.POISONED) return 0xFF4E9B28;
        float ratio = UiMath.ratio(health, maximum);
        return ratio > .5f ? 0xFF78CD36 : ratio > .2f ? 0xFFE3BC35 : 0xFFDB5145;
    }
    public String healthText(boolean experienceVisible) {
        return (int)Math.ceil(health) + " / " + (int)Math.ceil(maximum)
                + (absorption > 0 ? " +" + (int)Math.ceil(absorption) : "")
                + (experienceVisible ? "" : "  Lv. " + level);
    }
}
