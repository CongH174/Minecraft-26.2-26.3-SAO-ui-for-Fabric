package io.github.saoui;

import io.github.saoui.mixin.common.CraftingMenuAccess;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Five extra native slots, attached only after both peers negotiate support.
 * Existing slot IDs and the current menu stay intact. Recipes/remainders use vanilla machinery. */
public final class ContainerCraftingState extends AbstractContainerMenu {
    public final AbstractContainerMenu target;
    public final Player player;
    public final int base;
    public final CraftingContainer input=new TransientCraftingContainer(this,2,2);
    public final ResultContainer output=new ResultContainer();
    private boolean closed;
    public ContainerInput currentInput;

    private ContainerCraftingState(AbstractContainerMenu target,Player player){
        super(null,-1);this.target=target;this.player=player;this.base=target.slots.size();
    }
    public static ContainerCraftingState get(AbstractContainerMenu menu){return ((CraftingExtension)menu).saoui$crafting();}
    public static ContainerCraftingState attach(AbstractContainerMenu menu,Player player){
        var old=get(menu);if(old!=null)return old;
        var state=new ContainerCraftingState(menu,player);((CraftingExtension)menu).saoui$crafting(state);
        var access=(CraftingMenuAccess)menu;
        access.saoui$addSlot(new ResultSlot(player,state.input,state.output,0,-10000,-10000){
            @Override public boolean mayPickup(Player p){return !state.closed&&state.currentInput!=ContainerInput.PICKUP_ALL&&super.mayPickup(p);}
        });
        for(int i=0;i<4;i++)access.saoui$addSlot(new Slot(state.input,i,-10000,-10000));
        return state;
    }
    public boolean contains(int slot){return slot>=base&&slot<base+5;}
    @Override public void slotsChanged(Container ignored){
        if(closed)return;
        if(player.level() instanceof ServerLevel level){
            var craft=input.asCraftInput();ItemStack result=ItemStack.EMPTY;
            var recipe=level.getServer().getRecipeManager().getRecipeFor(RecipeType.CRAFTING,craft,level);
            if(recipe.isPresent()&&output.setRecipeUsed((ServerPlayer)player,recipe.get())){
                var assembled=recipe.get().value().assemble(craft);
                if(assembled.isItemEnabled(level.enabledFeatures()))result=assembled;
            }
            output.setItem(0,result);
        }
        // Match vanilla: client input updates must not overwrite a preceding server result packet.
    }
    /** Shift crafting is handled here; original menu subclasses only know their original slots. */
    public void shift(int id){
        if(!contains(id)||closed)return;
        var slot=target.getSlot(id);var first=slot.getItem().copy();
        for(int batch=0;batch<4096&&slot.hasItem()&&ItemStack.isSameItemSameComponents(first,slot.getItem());batch++){
            if(!slot.mayPickup(player))break;
            var remaining=slot.getItem();var before=remaining.copy();
            var access=(CraftingMenuAccess)target;
            // Merge existing stacks first, then empty player slots. Never insert into a workstation.
            for(int pass=0;pass<2;pass++)for(int i=0;i<base&&!remaining.isEmpty();i++){
                var dest=target.getSlot(i);int index=dest.getContainerSlot();
                if(dest.container!=player.getInventory()||index<0||index>=36||!dest.isActive())continue;
                if((pass==0)!=dest.hasItem())continue;
                access.saoui$move(remaining,i,i+1,false);
            }
            if(remaining.getCount()==before.getCount())break;
            if(id==base)slot.onQuickCraft(remaining,before);
            if(remaining.isEmpty())slot.setByPlayer(ItemStack.EMPTY,before);else slot.setChanged();
            slot.onTake(player,remaining);
            if(id!=base)break;
        }
    }
    public void close(){
        if(closed)return;closed=true;
        output.clearContent();
        if(!player.level().isClientSide())((CraftingMenuAccess)target).saoui$clear(player,input);
        else input.clearContent();
    }
    @Override public ItemStack quickMoveStack(Player player,int slot){return ItemStack.EMPTY;}
    @Override public boolean stillValid(Player player){return target.stillValid(player);}
}
