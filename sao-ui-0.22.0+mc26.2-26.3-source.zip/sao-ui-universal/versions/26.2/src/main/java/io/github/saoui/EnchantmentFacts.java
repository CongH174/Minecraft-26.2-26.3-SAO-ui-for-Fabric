package io.github.saoui;

import java.util.Locale;
import java.util.Set;

/** Vanilla Java rules, checked against both shipped data packs and Minecraft Wiki. */
public final class EnchantmentFacts {
    public record Fact(String id, Object[] values) {}
    public static final Set<String> IDS = Set.of("aqua_affinity","bane_of_arthropods","binding_curse","blast_protection","breach","channeling","density","depth_strider","efficiency","feather_falling","fire_aspect","fire_protection","flame","fortune","frost_walker","impaling","infinity","knockback","looting","loyalty","luck_of_the_sea","lunge","lure","mending","multishot","piercing","power","projectile_protection","protection","punch","quick_charge","respiration","riptide","sharpness","silk_touch","smite","soul_speed","sweeping_edge","swift_sneak","thorns","unbreaking","vanishing_curse","wind_burst");
    private EnchantmentFacts() {}
    public static String number(double n) { return String.format(Locale.ROOT,"%.2f",n).replaceAll("0+$", "").replaceAll("\\.$", ""); }
    public static Fact describe(String id,int level,boolean armor) {
        double n=Math.max(1,level); Object[] values=switch(id) {
            case "unbreaking" -> new Object[]{number(100*n/(n+1)*(armor?.4:1)),number(100*n/(n+1)),number(40*n/(n+1))};
            case "sharpness", "power" -> new Object[]{number(.5*(n+1)),number(25*(n+1))};
            case "smite", "impaling" -> new Object[]{number(2.5*n)};
            case "bane_of_arthropods" -> new Object[]{number(2.5*n),number(1+.5*n)};
            case "protection" -> new Object[]{number(Math.min(80,4*n))};
            case "blast_protection", "fire_protection" -> new Object[]{number(Math.min(80,8*n)),number(Math.min(100,15*n))};
            case "projectile_protection" -> new Object[]{number(Math.min(80,8*n))};
            case "feather_falling" -> new Object[]{number(Math.min(80,12*n))};
            case "breach" -> new Object[]{number(15*n)};
            case "density" -> new Object[]{number(.5*n)};
            case "efficiency" -> new Object[]{number(n*n+1)};
            case "sweeping_edge" -> new Object[]{number(100*n/(n+1))};
            case "fire_aspect" -> new Object[]{number(4*n)};
            case "knockback", "punch", "loyalty" -> new Object[]{number(n)};
            case "fortune" -> new Object[]{number((n+1)/2+1/(n+2)),number(n+1)};
            case "looting" -> new Object[]{number(n),number(n)};
            case "quick_charge" -> new Object[]{number(Math.max(0,1.25-.25*n)),number(.25*n)};
            case "respiration" -> new Object[]{number(n),number(100*n/(n+1))};
            case "aqua_affinity" -> new Object[]{number(400*n)};
            case "depth_strider" -> new Object[]{number(100*Math.min(3,n)/3)};
            case "swift_sneak" -> new Object[]{number(Math.min(100,30+15*n))};
            case "soul_speed" -> new Object[]{number(30+10.5*n)};
            case "thorns" -> new Object[]{number(Math.min(100,15*n)),"1","5"};
            case "frost_walker" -> new Object[]{number(Math.min(28,n+2))};
            case "riptide" -> new Object[]{number(.75*(n+1))};
            case "piercing" -> new Object[]{number(n),number(n+1)};
            case "lure" -> new Object[]{number(5*n)};
            case "luck_of_the_sea" -> new Object[]{number(n)};
            case "lunge" -> new Object[]{String.format(Locale.ROOT,"%.3f",.458*n),number(4*n)};
            case "wind_burst" -> new Object[]{number(n==1?1.2:n==2?1.75:n==3?2.2:1.5+.35*(n-1))};
            default -> new Object[0];
        };
        return new Fact(IDS.contains(id)?id:"unknown",values);
    }
}
