package io.github.saoui;

import java.util.LinkedHashMap;
import java.util.Map;

/** Resolution order: world/dimension/position + block type, block type, global preset. */
public final class ContainerUiRules {
    public ContainerUiProfile defaults = new ContainerUiProfile();
    public Map<String, ContainerUiProfile> blocks = new LinkedHashMap<>();
    public Map<String, ContainerUiProfile> locations = new LinkedHashMap<>();

    public ContainerUiRules validated() {
        defaults = defaults == null ? new ContainerUiProfile() : defaults.validated();
        blocks = grouped(clean(blocks)); locations = clean(locations);
        return this;
    }
    private static Map<String, ContainerUiProfile> clean(Map<String, ContainerUiProfile> source) {
        var out = new LinkedHashMap<String, ContainerUiProfile>();
        if (source != null) source.forEach((key, value) -> {
            if (key != null && !key.isBlank() && value != null) out.put(key, value.validated());
        });
        return out;
    }
    private static Map<String, ContainerUiProfile> grouped(Map<String, ContainerUiProfile> source) {
        var out = new LinkedHashMap<String, ContainerUiProfile>();
        new java.util.TreeMap<>(source).forEach((id, value) -> {
            String group = ContainerTypeGroups.key(id);
            if (id.equals(group) || !out.containsKey(group)) out.put(group, value);
        });
        return out;
    }
    public ContainerUiProfile resolve(String block, String location) {
        if (location != null && locations.containsKey(location)) return locations.get(location);
        return forBlock(block);
    }
    public ContainerUiProfile forBlock(String block) { return blocks.getOrDefault(ContainerTypeGroups.key(block), defaults); }
    public ContainerUiRules copy() {
        var r = new ContainerUiRules();
        r.defaults = defaults == null ? new ContainerUiProfile() : defaults.copy();
        if (blocks != null) blocks.forEach((k, v) -> { if (v != null) r.blocks.put(k, v.copy()); });
        if (locations != null) locations.forEach((k, v) -> { if (v != null) r.locations.put(k, v.copy()); });
        return r;
    }
}
