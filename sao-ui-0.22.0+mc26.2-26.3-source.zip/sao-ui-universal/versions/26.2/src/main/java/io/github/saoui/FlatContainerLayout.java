package io.github.saoui;

/** Vanilla menu families share behavior, while each workflow has its own flat presentation. */
public final class FlatContainerLayout {
    public enum Kind { STORAGE, SMELTING, CRAFTING, ANVIL, GRINDSTONE, SMITHING, STONECUTTER, ENCHANTING, BREWING, BEACON, LOOM, CARTOGRAPHY, CRAFTER }
    public record Point(int x, int y) {}
    private FlatContainerLayout() {}

    public static Kind kind(String id) {
        if (id.startsWith("generic_9x") || id.equals("generic_3x3") || id.equals("hopper") || id.equals("shulker_box")) return Kind.STORAGE;
        return switch (id) {
            case "furnace", "blast_furnace", "smoker" -> Kind.SMELTING;
            case "crafting" -> Kind.CRAFTING;
            case "anvil" -> Kind.ANVIL;
            case "grindstone" -> Kind.GRINDSTONE;
            case "smithing" -> Kind.SMITHING;
            case "stonecutter" -> Kind.STONECUTTER;
            case "enchantment" -> Kind.ENCHANTING;
            case "brewing_stand" -> Kind.BREWING;
            case "beacon" -> Kind.BEACON;
            case "loom" -> Kind.LOOM;
            case "cartography_table" -> Kind.CARTOGRAPHY;
            case "crafter_3x3" -> Kind.CRAFTER;
            default -> null;
        };
    }

    public static int columns(String id) { return id.equals("hopper") ? 5 : id.equals("generic_3x3") ? 3 : 9; }
    public static int workWidth(int nativeWidth) { return Math.max(222, nativeWidth + 16); }
    public static int playerX(int workWidth) { return workWidth + 18; }
    public static int width(int workWidth) { return playerX(workWidth) + 222; }
    public static int height() { return 212; }

    public static Point playerSlot(int inventoryIndex, int workWidth) {
        int column = inventoryIndex < 9 ? inventoryIndex : (inventoryIndex - 9) % 9;
        int y = inventoryIndex < 9 ? 114 : 22 + (inventoryIndex - 9) / 9 * 22;
        return new Point(playerX(workWidth) + 14 + column * 22, y);
    }

    public static Point storageSlot(int index, int columns, int workWidth) {
        return new Point((workWidth - columns * 22) / 2 + 3 + index % columns * 22, 22 + index / columns * 22);
    }

    public static Point workSlot(Kind kind, int index) {
        return switch (kind) {
            case SMELTING -> switch (index) {
                case 0 -> new Point(46, 34); case 1 -> new Point(46, 86); case 2 -> new Point(156, 58); default -> null;
            };
            case CRAFTING -> index == 0 ? new Point(164, 58) : index <= 9 ? new Point(28 + (index - 1) % 3 * 22, 30 + (index - 1) / 3 * 22) : null;
            case CRAFTER -> index < 9 ? new Point(28 + index % 3 * 22, 30 + index / 3 * 22) : new Point(164, 58);
            case ANVIL -> switch (index) {
                case 0 -> new Point(28, 72); case 1 -> new Point(88, 72); case 2 -> new Point(164, 72); default -> null;
            };
            case GRINDSTONE -> switch (index) {
                case 0 -> new Point(46, 32); case 1 -> new Point(46, 86); case 2 -> new Point(156, 58); default -> null;
            };
            case SMITHING -> switch (index) {
                case 0 -> new Point(18, 36); case 1 -> new Point(62, 36); case 2 -> new Point(106, 36); case 3 -> new Point(174, 36); default -> null;
            };
            case BREWING -> switch (index) {
                case 0 -> new Point(40, 84); case 1 -> new Point(90, 84); case 2 -> new Point(140, 84);
                case 3 -> new Point(90, 26); case 4 -> new Point(24, 26); default -> null;
            };
            default -> null;
        };
    }
}
