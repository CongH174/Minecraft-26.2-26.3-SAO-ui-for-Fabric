package io.github.saoui;

/** Stable config values. New visual styles extend this list and the shared HUD renderer. */
public enum HudBarStyle {
    SAO("sao"), RECTANGLE("rectangle");
    private final String id;
    HudBarStyle(String id){this.id=id;}
    public String titleKey(){return "saoui.hud_style."+id;}
}
