package io.github.saoui;

/** Front-facing affine surface; the same transform drives rendering and pointer hits. */
public final class BlockSurfaceMotion {
    public static final long OPEN_MILLIS = 420;
    public record Frame(double scale, double x, double y) {
        public double screenX(double local) { return x + local * scale; }
        public double screenY(double local) { return y + local * scale; }
        public double localX(double screen) { return (screen - x) / scale; }
        public double localY(double screen) { return (screen - y) / scale; }
    }

    private BlockSurfaceMotion() {}

    public static double clampDrift(double drift, double start, double size, double viewport, double padding) {
        double min = padding - start, max = viewport - padding - start - size;
        return min <= max ? Math.clamp(drift, min, max) : (viewport - size) / 2 - start;
    }

    public static Frame frame(long elapsed, double sourceX, double sourceY, double centerX, double centerY,
                              double driftX, double driftY) {
        return frameTo(elapsed, sourceX, sourceY, centerX, centerY, centerX, centerY, 1, driftX, driftY);
    }

    public static Frame frameTo(long elapsed, double sourceX, double sourceY, double centerX, double centerY,
                                double targetX, double targetY, double targetScale, double driftX, double driftY) {
        double t = Math.clamp((double) elapsed / OPEN_MILLIS, 0, 1);
        double p = MenuMotion.out(t), scale = 0.06 + (targetScale - 0.06) * p;
        double x = sourceX + (targetX + driftX - sourceX) * p;
        double y = sourceY + (targetY + driftY - sourceY) * p - Math.sin(t * Math.PI) * 14;
        return new Frame(scale, x - centerX * scale, y - centerY * scale);
    }
}
