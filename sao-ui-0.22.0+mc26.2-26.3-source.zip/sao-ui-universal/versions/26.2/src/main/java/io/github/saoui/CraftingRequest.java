package io.github.saoui;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
public record CraftingRequest(int menuId,int baseSlots) implements CustomPacketPayload {
    public static final Type<CraftingRequest> TYPE=new Type<>(Identifier.fromNamespaceAndPath("saoui","crafting_request_v1"));
    public static final StreamCodec<RegistryFriendlyByteBuf,CraftingRequest> CODEC=CustomPacketPayload.codec(CraftingRequest::write,CraftingRequest::new);
    private CraftingRequest(RegistryFriendlyByteBuf b){this(b.readVarInt(),b.readVarInt());}
    private void write(RegistryFriendlyByteBuf b){b.writeVarInt(menuId);b.writeVarInt(baseSlots);}
    @Override public Type<CraftingRequest> type(){return TYPE;}
}
