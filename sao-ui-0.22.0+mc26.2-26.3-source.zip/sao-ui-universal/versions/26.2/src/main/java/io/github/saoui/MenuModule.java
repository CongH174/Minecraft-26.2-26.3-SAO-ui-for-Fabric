package io.github.saoui;

import java.util.Arrays;
import java.util.List;

/** Stable module IDs used by settings, saved layouts and the menu renderer. */
public enum MenuModule {
    PROFILE("profile", "profile"),
    INVENTORY("inventory", "items"),
    EQUIPMENT("equipment", "equipment"),
    SETTINGS("settings", "settings");

    private final String id, icon;

    MenuModule(String id, String icon) { this.id = id; this.icon = icon; }
    public String id() { return id; }
    public String icon() { return icon; }
    public String titleKey() { return "root.saoui." + id; }
    public boolean canHide() { return this != SETTINGS; }

    public static MenuModule fromId(String id) {
        return Arrays.stream(values()).filter(module -> module.id.equals(id)).findFirst().orElse(null);
    }

    public static List<String> defaultOrder() {
        return Arrays.stream(values()).map(MenuModule::id).toList();
    }
}
