package io.github.saoui;

import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UiEffectsTest {
    @Test void physicalSizeDoesNotFollowVanillaScale() {
        for(int nativeScale:new int[]{1,2,3,4}) {
            double scale=UiEffects.scale(1440,nativeScale,1.37f);
            assertEquals(1440/480.0*1.37*200,scale*200*nativeScale,.001);
        }
        assertTrue(UiEffects.fit(3,400,200,500,300,10)*300<=180.001);
        assertTrue(UiEffects.scale(480,2,0)>0);
    }
    @Test void valuesRoundToHundredthsAndEndpointsHaveDefinedBehavior() {
        assertEquals(1.24f,UiEffects.value(1.236f,1));assertEquals(.2f,UiEffects.value(-1,1));
        assertEquals(2,UiEffects.value(3,1));assertEquals(1,UiEffects.value(Float.NaN,1));
        assertEquals(1000,UiEffects.elapsed(500,2));assertTrue(UiEffects.elapsed(0,0)>MenuMotion.OPEN_MILLIS);
        assertTrue((UiEffects.alpha(0xFF123456,0)>>>24)>0);assertEquals(255,UiEffects.alpha(0xFF123456,2)>>>24);
        assertEquals(0,UiEffects.blurRadius(0));assertEquals(10,UiEffects.blurRadius(2));
    }
    @Test void zeroSettingsMigrateToVisibleValuesWithExplicitEffectSwitches() {
        var config=new SaoConfig();config.uiScale=config.scale=config.uiOpacity=0;
        config.parallaxStrength=config.animationSpeed=config.blurStrength=config.healthSmoothing=0;config.validated();
        assertEquals(.2f,config.uiScale);assertEquals(.2f,config.scale);assertEquals(.2f,config.uiOpacity);
        assertFalse(config.parallaxEnabled);assertFalse(config.animationsEnabled);assertFalse(config.blurEnabled);assertFalse(config.smoothHealth);
        assertEquals(0,config.animationRate());assertEquals(0,config.parallaxAmount());assertEquals(0,config.blurAmount());
        assertFalse(config.copy().blurEnabled);assertEquals(.2f,config.copy().uiOpacity);
    }
    @Test void oldConfigUpgradesAndDraftEffectsAndFontStayIsolated() {
        var gson=new Gson();var original=gson.fromJson("{\"scale\":1.5}",SaoConfig.class).validated();
        assertEquals(1,original.uiScale);assertEquals(1,original.blurStrength);assertEquals(1.5f,original.scale);
        var draft=original.copy();draft.uiScale=1.23f;draft.blurStrength=2;draft.uiOpacity=.61f;draft.theme.customFont=true;draft.theme.font=0xABCDEF;
        assertEquals(1,original.uiScale);assertFalse(original.theme.customFont);
        var loaded=gson.fromJson(gson.toJson(draft),SaoConfig.class).validated();assertEquals(1.23f,loaded.uiScale);
        assertEquals(.61f,loaded.uiOpacity);assertEquals(0xABCDEF,loaded.theme.font);assertTrue(loaded.theme.customFont);
        loaded.resetHud();assertEquals(1,loaded.uiScale);assertEquals(1.9f,loaded.uiOpacity);
    }
}
