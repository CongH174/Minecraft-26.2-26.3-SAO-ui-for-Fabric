package io.github.saoui;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class PlayerCraftingLayoutTest {
    @Test void nativeSlotsFormTwoRowsAndSeparateResultBelow(){
        var a=PlayerCraftingLayout.slot(1);var b=PlayerCraftingLayout.slot(2);var c=PlayerCraftingLayout.slot(3);var d=PlayerCraftingLayout.slot(4);var out=PlayerCraftingLayout.slot(0);
        assertEquals(a.y(),b.y());assertEquals(c.y(),d.y());assertEquals(a.x(),c.x());assertEquals(b.x(),d.x());
        assertTrue(b.x()>=a.x()+20);assertTrue(c.y()>=a.y()+20);assertTrue(out.y()>=d.y()+20);
        assertThrows(IllegalArgumentException.class,()->PlayerCraftingLayout.slot(5));
    }
    @Test void extraPanelAndAllSlotsStayInsideExpandedSurface(){
        assertTrue(PlayerCraftingLayout.X>=44+266+12);
        assertTrue(PlayerCraftingLayout.menuWidth(true)>PlayerCraftingLayout.menuWidth(false));
        for(int id=0;id<5;id++){var p=PlayerCraftingLayout.slot(id);assertTrue(p.x()>=PlayerCraftingLayout.X && p.x()+20<=PlayerCraftingLayout.X+PlayerCraftingLayout.WIDTH);assertTrue(p.y()>=PlayerCraftingLayout.Y && p.y()+20<=PlayerCraftingLayout.Y+PlayerCraftingLayout.HEIGHT);}
        assertTrue(-204+PlayerCraftingLayout.menuWidth(true)>=PlayerCraftingLayout.X+PlayerCraftingLayout.WIDTH+4);
    }
    @Test void oldConfigEnablesCraftingAndDraftCanHideItIndependently(){
        var g=new Gson();var c=g.fromJson("{}",SaoConfig.class).validated();assertTrue(c.craftingVisible);
        var draft=c.copy();draft.craftingVisible=false;assertTrue(c.craftingVisible);
        var saved=g.fromJson(g.toJson(draft),SaoConfig.class).validated();assertFalse(saved.craftingVisible);
        saved.resetModules();assertFalse(saved.craftingVisible);saved.resetHud();assertTrue(saved.craftingVisible);
    }
}
