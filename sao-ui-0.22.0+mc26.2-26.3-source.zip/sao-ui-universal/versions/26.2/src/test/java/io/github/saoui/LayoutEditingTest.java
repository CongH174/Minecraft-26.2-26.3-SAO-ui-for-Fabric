package io.github.saoui;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class LayoutEditingTest {
    @Test void dragUsesPhysicalReferenceUnitsAcrossGuiScales(){
        int reference=LayoutEditing.referenceOffset(180,20,1,854,300);
        assertEquals(reference,LayoutEditing.referenceOffset(90,10,.5,427,150));
    }
    @Test void draggingCannotPushHudOutsideViewport(){
        assertEquals(0,LayoutEditing.referenceOffset(-100,20,1,854,300));
        assertEquals(554,LayoutEditing.referenceOffset(2000,20,1,854,300));
        assertEquals(0,LayoutEditing.referenceOffset(100,0,1,100,300));
    }
    @Test void edgeAndCenterSnapsDoNotCaptureDistantPositions(){
        assertEquals(0,LayoutEditing.snap(3,0,500,6));assertEquals(250,LayoutEditing.snap(247,0,500,6));assertEquals(500,LayoutEditing.snap(496,0,500,6));assertEquals(220,LayoutEditing.snap(220,0,500,6));
    }
}
