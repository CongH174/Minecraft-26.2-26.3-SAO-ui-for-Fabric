package io.github.saoui;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MenuProjectionTest {
    @Test void pointerRoundTripsThroughTiltedPerspectiveDuringAnimation() {
        for (double yaw : new double[]{-38, -13, 8}) {
            for (double depth : new double[]{0, 80, 240}) {
                var p = new MenuProjection(180, 120, 0.85, depth, yaw, 5);
                for (double x : new double[]{-22, 0, 70, 242}) {
                    for (double y : new double[]{-110, 0, 110}) {
                        var at = p.project(x, y);
                        var inverse = p.unproject(at.x(), at.y());
                        assertEquals(x, inverse.x(), 1e-9);
                        assertEquals(y, inverse.y(), 1e-9);
                    }
                }
            }
        }
    }

    @Test void nativeFontTangentMatchesProjectedGeometry() {
        var p = new MenuProjection(160, 100, 1, 40, -18, 6);
        var t = p.tangent(80, -40);
        var x = p.project(80.0001, -40);
        var y = p.project(80, -39.9999);
        assertEquals(t.xx(), (x.x() - t.x()) / 0.0001, 1e-6);
        assertEquals(t.xy(), (x.y() - t.y()) / 0.0001, 1e-6);
        assertEquals(t.yx(), (y.x() - t.x()) / 0.0001, 1e-6);
        assertEquals(t.yy(), (y.y() - t.y()) / 0.0001, 1e-6);
    }

    @Test void animationIsStaggeredBoundedAndCompletes() {
        assertEquals(0, MenuMotion.orb(60, 4));
        assertTrue(MenuMotion.orb(60, 0) > 0);
        for (int i = 0; i < 5; i++) assertEquals(1, MenuMotion.orb(MenuMotion.OPEN_MILLIS, i));
        assertEquals(0, MenuMotion.pop(0), 1e-12);
        assertEquals(1, MenuMotion.pop(1));
        assertEquals(0, 1 - MenuMotion.in(MenuMotion.progress(240, 0, MenuMotion.CLOSE_MILLIS)));
    }
}
