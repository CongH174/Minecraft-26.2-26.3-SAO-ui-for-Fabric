package io.github.saoui;

import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HudOptionsTest {
    @Test void oldConfigsGetNewBarsWithoutChangingExistingPreferences() {
        var config = new Gson().fromJson("{\"hudEnabled\":false,\"scale\":1.5}", SaoConfig.class).validated();
        assertFalse(config.hudEnabled); assertEquals(1.5f, config.scale);
        assertTrue(config.hud.health && config.hud.hunger && config.hud.experience && config.hud.armor);
        assertFalse(config.hud.hideVanillaHealth);
        config.hud = null; assertNotNull(config.validated().hud);
    }
    @Test void oldGlobalHideMigratesOnlyToTheFiveSupportedControls() {
        var gson = new Gson();
        var config = gson.fromJson("{\"hud\":{\"hideVanilla\":true}}", SaoConfig.class).validated();
        var h = config.hud;
        assertTrue(h.hideVanillaHealth && h.hideVanillaHunger && h.hideVanillaExperience && h.hideVanillaArmor && h.hideVanillaCrosshair);
        assertNull(h.hideVanilla);
        assertFalse(gson.toJson(config).contains("\"hideVanilla\":"));
    }
    @Test void draftsAndResetsPreserveModuleIsolationAndRoundTrip() {
        var config = new SaoConfig(); var draft = config.copy();
        draft.hud.health = draft.hud.saturation = false; draft.hud.hideVanillaHealth = true;
        draft.hud.hideVanillaCrosshair = true;
        assertTrue(config.hud.health && config.hud.saturation); assertFalse(config.hud.hideVanillaHealth);
        var gson = new Gson(); var saved = gson.fromJson(gson.toJson(draft), SaoConfig.class).validated();
        assertFalse(saved.hud.health); assertFalse(saved.hud.saturation); assertTrue(saved.hud.hideVanillaHealth);
        assertTrue(saved.hud.hideVanillaCrosshair); assertFalse(saved.hud.hideVanillaExperience);
        saved.resetModules(); assertTrue(saved.hud.hideVanillaHealth);
        saved.homeModule = "inventory"; saved.resetHud();
        assertTrue(saved.hud.health && saved.hud.saturation); assertFalse(saved.hud.hideVanillaHealth);
        assertEquals("inventory", saved.homeModule);
    }
    @Test void hiddenHealthLeavesOnlyIdentityAndAllOffLeavesNoPanel() {
        var bars = new HudOptions(); assertEquals(75, bars.height());
        bars.health = false; assertEquals(75, bars.height());
        bars.experience = bars.armor = false; assertEquals(35, bars.height());
        bars.hunger = false; assertFalse(bars.anyBar()); assertEquals(0, bars.height());
    }
    @Test void saturationIsBoundedByFoodAndUnavailableDataDoesNotInventGold() {
        var values = new HudValues(20, 20, 0, 10, 18, 2, 5, 30);
        assertEquals(.5f, values.foodRatio()); assertEquals(.5f, values.saturationRatio());
        assertEquals(1, values.experienceRatio()); assertEquals(1, values.armorRatio());
        var absent = new HudValues(20, 20, 0, 20, Float.NaN, Float.NaN, 0, -1);
        assertFalse(absent.hasSaturation()); assertEquals(0, absent.saturationRatio());
        assertEquals(0, absent.experienceRatio()); assertEquals(0, absent.armorRatio());
    }
    @Test void absorptionAndConditionsOverrideHealthColorAndLevelIsNotDuplicated() {
        var v = new HudValues(14, 20, 8, 18, 12, .3f, 12, 8, HudValues.Condition.POISONED);
        assertEquals(.4f, v.absorptionRatio()); assertEquals(0xFF4E9B28, v.healthTint());
        assertFalse(v.healthText(true).contains("Lv.")); assertTrue(v.healthText(false).contains("Lv. 12"));
        assertTrue(v.healthText(true).contains("+8"));
        assertEquals(HudValues.Condition.WITHERED, HudValues.condition(true, true));
        assertEquals(0xFF29272D, new HudValues(14,20,0,18,0,0,0,0,HudValues.Condition.WITHERED).healthTint());
        assertEquals(0xFFDB5145, new HudValues(2,20,0,18,0,0,0,0).healthTint());
    }
}
