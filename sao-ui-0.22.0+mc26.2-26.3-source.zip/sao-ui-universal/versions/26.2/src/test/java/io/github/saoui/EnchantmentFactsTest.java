package io.github.saoui;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class EnchantmentFactsTest {
    @Test void concreteExamplesUseJavaRulesAndArmorBranch(){
        assertEquals("75",EnchantmentFacts.describe("unbreaking",3,false).values()[0]);
        assertEquals("30",EnchantmentFacts.describe("unbreaking",3,true).values()[0]);
        assertEquals("3",EnchantmentFacts.describe("sharpness",5,false).values()[0]);
        assertEquals("26",EnchantmentFacts.describe("efficiency",5,false).values()[0]);
        assertEquals("2.2",EnchantmentFacts.describe("fortune",3,false).values()[0]);
        assertEquals("0.5",EnchantmentFacts.describe("quick_charge",3,false).values()[0]);
        assertEquals("48",EnchantmentFacts.describe("feather_falling",4,true).values()[0]);
        assertEquals("60",EnchantmentFacts.describe("breach",4,false).values()[0]);
        assertEquals("75",EnchantmentFacts.describe("swift_sneak",3,true).values()[0]);
        assertEquals("61.5",EnchantmentFacts.describe("soul_speed",3,true).values()[0]);
    }
    @Test void allFortyThreeEnchantmentsHaveLocalizedDescriptions() throws Exception {
        assertEquals(43,EnchantmentFacts.IDS.size());
        for(var lang:new String[]{"zh_cn","en_us"})try(var stream=getClass().getResourceAsStream("/assets/saoui/lang/"+lang+".json")){
            var json=com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            for(var id:EnchantmentFacts.IDS)assertTrue(json.has("saoui.enchant."+id),lang+":"+id);
        }
        assertEquals("unknown",EnchantmentFacts.describe("modded_spell",3,false).id());
    }
    @Test void featureDraftIsIsolatedAndResettable(){
        var original=new SaoConfig();var draft=original.copy();draft.containerCraftingVisible=false;draft.enchantmentDetailsVisible=false;draft.ipnIntegration=false;
        assertTrue(original.containerCraftingVisible&&original.enchantmentDetailsVisible&&original.ipnIntegration);
        draft.resetHud();assertTrue(draft.containerCraftingVisible&&draft.enchantmentDetailsVisible&&draft.ipnIntegration);
    }
}
