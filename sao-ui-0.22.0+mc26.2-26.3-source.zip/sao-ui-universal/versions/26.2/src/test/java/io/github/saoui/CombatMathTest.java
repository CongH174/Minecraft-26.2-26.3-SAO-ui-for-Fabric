package io.github.saoui;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CombatMathTest {
    @Test void appliesVanillaOperationOrderWithoutDoubleCountingHeldWeapon() {
        assertEquals(7, CombatMath.attribute(1, 6, 0, 1));
        assertEquals(1.6, CombatMath.attribute(4, -2.4, 0, 1), 1e-12);
        assertEquals(15.75, CombatMath.attribute(1, 6, 0.5, 1.5), 1e-12);
    }

    @Test void invalidOrNegativeValuesDoNotBecomeMisleadingStats() {
        assertEquals(0, CombatMath.attribute(1, -5, 0, 1));
        assertEquals(0, CombatMath.attribute(1, Double.NaN, 0, 1));
    }
}
