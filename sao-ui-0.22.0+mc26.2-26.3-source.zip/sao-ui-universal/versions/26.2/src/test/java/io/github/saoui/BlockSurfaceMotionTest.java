package io.github.saoui;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BlockSurfaceMotionTest {
    @Test void largePanelsStayInsideTheViewportAtMaximumParallax() {
        assertEquals(-3, BlockSurfaceMotion.clampDrift(-14, 9, 222, 240, 6));
        assertEquals(3, BlockSurfaceMotion.clampDrift(14, 9, 222, 240, 6));
        assertEquals(5, BlockSurfaceMotion.clampDrift(5, 80, 160, 320, 6));
        assertEquals(-10, BlockSurfaceMotion.clampDrift(40, 0, 260, 240, 6));
    }
    @Test void startsAtTheWorldSourceAndFinishesAtTheNativeMenuCenter() {
        var start = BlockSurfaceMotion.frame(0, 70, 190, 210, 120, 0, 0);
        assertEquals(70, start.screenX(210), 1e-9);
        assertEquals(190, start.screenY(120), 1e-9);
        assertEquals(0.06, start.scale(), 1e-9);
        var end = BlockSurfaceMotion.frame(420, 70, 190, 210, 120, 8, -4);
        assertEquals(1, end.scale(), 1e-9);
        assertEquals(218, end.screenX(210), 1e-9);
        assertEquals(116, end.screenY(120), 1e-9);
    }

    @Test void pointerInverseMatchesEveryAnimationStageAndResize() {
        for (int t = 0; t < 600; t += 17) {
            var frame = BlockSurfaceMotion.frame(t, 350, 280, 310, 180, 9, 7);
            assertEquals(145, frame.localX(frame.screenX(145)), 1e-9);
            assertEquals(210, frame.localY(frame.screenY(210)), 1e-9);
            assertTrue(frame.scale() > 0 && frame.scale() <= 1);
        }
    }

    @Test void clampsTimeAndStopsAfterTheEntrance() {
        assertEquals(BlockSurfaceMotion.frame(0, 80, 200, 210, 120, 0, 0),
                BlockSurfaceMotion.frame(-50, 80, 200, 210, 120, 0, 0));
        assertEquals(BlockSurfaceMotion.frame(420, 80, 200, 210, 120, 0, 0),
                BlockSurfaceMotion.frame(5000, 80, 200, 210, 120, 0, 0));
    }
}
