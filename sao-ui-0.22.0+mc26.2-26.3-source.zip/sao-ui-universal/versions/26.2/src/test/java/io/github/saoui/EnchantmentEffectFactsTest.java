package io.github.saoui;

import com.google.gson.JsonParser;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EnchantmentEffectFactsTest {
    private static List<EnchantmentEffectFacts.Detail> read(String json){return EnchantmentEffectFacts.describe(JsonParser.parseString(json).getAsJsonObject(),e->e.getAsDouble());}
    @Test void conditionalTargetIsRetainedInsideComposite(){
        var facts=read("""
            {"minecraft:post_attack":[{"affected":"victim","requirements":{"type":"minecraft:random_chance","chance":0.2},"effect":{"type":"minecraft:all_of","effects":[{"type":"minecraft:ignite","duration":4},{"type":"minecraft:run_function","function":"test:hidden"}]}}]}
            """);
        assertEquals(2,facts.size());assertTrue(facts.stream().allMatch(f->f.conditional()&&f.target().equals("victim")));
        assertEquals(List.of("4"),facts.getFirst().values());assertEquals("unsupported",facts.getLast().operation());
        assertEquals(List.of("minecraft:run_function"),facts.getLast().values());
    }
    @Test void pointProbabilityIsNotPresentedAsAnOverallBonus(){
        var fact=read(""" 
            {"minecraft:item_damage":[{"effect":{"type":"minecraft:remove_binomial","chance":0.75}}]}
            """).getFirst();
        assertEquals("remove_binomial",fact.operation());assertEquals(List.of("75"),fact.values());assertFalse(fact.conditional());
    }
    @Test void invalidValuesRemainUnknownRatherThanInventingNumbers(){
        var facts=read("""
            {"minecraft:damage":[{"effect":{"type":"minecraft:add"}},{"effect":{"type":"minecraft:remove_binomial","chance":2}},{"effect":{"type":"other:custom","value":9}}]}
            """);
        assertEquals(3,facts.size());assertTrue(facts.stream().allMatch(f->f.operation().equals("unsupported")));
        for(double invalid:new double[]{Double.NaN,Double.POSITIVE_INFINITY}){
            var nonFinite=EnchantmentEffectFacts.describe(JsonParser.parseString("{\"minecraft:damage\":[{\"effect\":{\"type\":\"minecraft:add\",\"value\":1}}]}").getAsJsonObject(),e->invalid);
            assertEquals("unsupported",nonFinite.getFirst().operation());
        }
    }
    @Test void effectsAreNotAggregatedAcrossDifferentConditions(){
        var facts=read("""
            {"minecraft:damage":[{"effect":{"type":"minecraft:add","value":3}},{"requirements":{},"effect":{"type":"minecraft:multiply","value":2}}]}
            """);
        assertEquals(2,facts.size());assertEquals("add",facts.getFirst().operation());assertFalse(facts.getFirst().conditional());
        assertEquals("multiply",facts.getLast().operation());assertTrue(facts.getLast().conditional());
    }
    @Test void largeDescriptionsHaveAnExplicitLimit(){
        String repeated=String.join(",",java.util.Collections.nCopies(100,"{\"effect\":{\"type\":\"minecraft:add\",\"value\":1}}"));
        var facts=read("{\"minecraft:damage\":["+repeated+"]}");
        assertEquals(65,facts.size());assertEquals("omitted",facts.getLast().operation());
        var exact=read("{\"minecraft:damage\":["+String.join(",",java.util.Collections.nCopies(64,"{\"effect\":{\"type\":\"minecraft:add\",\"value\":1}}"))+"]}");
        assertEquals(64,exact.size());assertTrue(exact.stream().noneMatch(f->f.operation().equals("omitted")));
    }
    @Test void compatibilitySwitchesRemainIsolatedAndResettable(){
        var live=new SaoConfig();var draft=live.copy();draft.enchantmentDescriptions=false;draft.syncedEnchantmentEffects=false;draft.serverEnchantmentLore=false;
        assertTrue(live.enchantmentDescriptions&&live.syncedEnchantmentEffects&&live.serverEnchantmentLore);
        var copy=draft.copy();assertFalse(copy.enchantmentDescriptions||copy.syncedEnchantmentEffects||copy.serverEnchantmentLore);
        copy.resetHud();assertTrue(copy.enchantmentDescriptions&&copy.syncedEnchantmentEffects&&copy.serverEnchantmentLore);
    }
}
