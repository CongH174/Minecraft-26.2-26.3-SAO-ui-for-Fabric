package io.github.saoui;

import static org.junit.jupiter.api.Assertions.*;
import java.util.HashSet;
import org.junit.jupiter.api.Test;

class FlatContainerLayoutTest {
    @Test void allSupportedMenuFamiliesResolveAndUnknownMenusStayNative() {
        for (String id : new String[]{"generic_9x1", "generic_9x6", "generic_3x3", "hopper", "shulker_box",
                "furnace", "blast_furnace", "smoker", "crafting", "anvil", "grindstone", "smithing",
                "stonecutter", "enchantment", "brewing_stand", "beacon", "loom", "cartography_table", "crafter_3x3"})
            assertNotNull(FlatContainerLayout.kind(id), id);
        assertNull(FlatContainerLayout.kind("merchant"));
        assertNull(FlatContainerLayout.kind("custom_machine"));
    }

    @Test void backpackHas36SeparateSlotsInsideRightPanel() {
        for (int work : new int[]{222, 246}) {
            var points = new HashSet<FlatContainerLayout.Point>();
            for (int index = 0; index < 36; index++) {
                var p = FlatContainerLayout.playerSlot(index, work);
                assertTrue(points.add(p));
                assertTrue(p.x() >= FlatContainerLayout.playerX(work));
                assertTrue(p.x() + 18 < FlatContainerLayout.width(work));
                assertTrue(p.y() + 18 < 142);
            }
        }
    }

    @Test void fullDoubleChestFitsBetweenHeadingAndCapacityLine() {
        var points = new HashSet<FlatContainerLayout.Point>();
        for (int index = 0; index < 54; index++) {
            var p = FlatContainerLayout.storageSlot(index, 9, 222);
            assertTrue(points.add(p));
            assertTrue(p.x() - 2 >= 10 && p.x() + 18 <= 212);
            assertTrue(p.y() >= 22 && p.y() + 18 < 156);
        }
    }

    @Test void scaledSurfaceCentersCorrectlyAndKeepsPointerReversible() {
        var frame = BlockSurfaceMotion.frameTo(420, 30, 40, 500, 150, 160, 120, 0.62, 4, -3);
        assertEquals(164, frame.screenX(500), 1e-8);
        assertEquals(117, frame.screenY(150), 1e-8);
        assertEquals(0.62, frame.scale(), 1e-8);
        assertEquals(735, frame.localX(frame.screenX(735)), 1e-8);
        assertEquals(210, frame.localY(frame.screenY(210)), 1e-8);
    }
}
