package io.github.saoui;

import static org.junit.jupiter.api.Assertions.*;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;

class ContainerUiRulesTest {
    @Test void upgradesOldConfigAndRepairsMalformedProfiles() {
        var gson = new Gson();
        var old = gson.fromJson("{\"scale\":1.5}", SaoConfig.class).validated();
        assertTrue(old.armorSlotsVisible); assertTrue(old.containers.defaults.enabled); assertEquals(1.5f, old.scale);
        var bad = gson.fromJson("{\"containers\":{\"defaults\":null,\"blocks\":{\"bad\":null,\"minecraft:chest\":{\"backpackSide\":\"removed\",\"gap\":300,\"containerX\":-999,\"backpackY\":999}}}}", SaoConfig.class).validated();
        assertFalse(bad.containers.blocks.containsKey("bad"));
        var p = bad.containers.forBlock("minecraft:chest");
        assertEquals(ContainerUiProfile.Side.RIGHT, p.backpackSide); assertEquals(96, p.gap);
        assertEquals(-200, p.containerX); assertEquals(200, p.backpackY);
    }
    @Test void resolvesLocationThenBlockThenDefaultAndRestoresInheritance() {
        var rules = new ContainerUiRules();
        rules.defaults.backpackSide = ContainerUiProfile.Side.BELOW;
        var chest = rules.defaults.copy(); chest.enabled = false;
        rules.blocks.put("minecraft:chest", chest);
        var local = chest.copy(); local.enabled = true; local.backpackSide = ContainerUiProfile.Side.LEFT;
        rules.locations.put("world|dim|0,64,0|minecraft:chest", local);
        assertTrue(rules.resolve("minecraft:barrel", null).enabled);
        assertFalse(rules.resolve("minecraft:chest", null).enabled);
        assertTrue(rules.resolve("minecraft:chest", "world|dim|0,64,0|minecraft:chest").enabled);
        assertFalse(rules.resolve("minecraft:chest", "other-world|dim|0,64,0|minecraft:chest").enabled);
        rules.locations.clear(); assertFalse(rules.resolve("minecraft:chest", "world|dim|0,64,0|minecraft:chest").enabled);
        rules.blocks.clear(); assertEquals(ContainerUiProfile.Side.BELOW, rules.forBlock("minecraft:chest").backpackSide);
    }
    @Test void draftAndRoundTripKeepAllRuleLevelsIndependent() {
        var config = new SaoConfig();
        config.containers.blocks.put("minecraft:barrel", new ContainerUiProfile());
        config.containers.locations.put("world|dim|1,2,3|minecraft:barrel", new ContainerUiProfile());
        var draft = config.copy(); draft.containers.defaults.gap = 36;
        draft.containers.blocks.get("minecraft:barrel").enabled = false;
        draft.containers.locations.get("world|dim|1,2,3|minecraft:barrel").backpackX = -75;
        assertEquals(18, config.containers.defaults.gap);
        assertTrue(config.containers.blocks.get("minecraft:barrel").enabled);
        assertEquals(0, config.containers.locations.get("world|dim|1,2,3|minecraft:barrel").backpackX);
        var gson = new Gson(); var loaded = gson.fromJson(gson.toJson(draft), SaoConfig.class).validated();
        assertEquals(36, loaded.containers.defaults.gap);
        assertFalse(loaded.containers.forBlock("minecraft:barrel").enabled);
        assertEquals(-75, loaded.containers.resolve("minecraft:barrel", "world|dim|1,2,3|minecraft:barrel").backpackX);
        loaded.resetHud(); assertFalse(loaded.containers.forBlock("minecraft:barrel").enabled);
        loaded.resetModules(); assertEquals(36, loaded.containers.defaults.gap);
    }
    @Test void familiesShareOneTypeRuleWhileExactLocationsRemainIndependent() {
        var rules = new ContainerUiRules(); var anvil = new ContainerUiProfile(); anvil.enabled = false;
        var shulker = new ContainerUiProfile(); shulker.backpackSide = ContainerUiProfile.Side.LEFT;
        rules.blocks.put("minecraft:anvil", anvil); rules.blocks.put("minecraft:shulker_box", shulker);
        assertFalse(rules.forBlock("minecraft:damaged_anvil").enabled);
        assertFalse(rules.forBlock("minecraft:chipped_anvil").enabled);
        for (var color : new String[]{"white", "light_gray", "red", "black"})
            assertEquals(ContainerUiProfile.Side.LEFT, rules.forBlock("minecraft:"+color+"_shulker_box").backpackSide);
        var placed = new ContainerUiProfile(); placed.gap = 57;
        rules.locations.put("world|dim|1,2,3|minecraft:red_shulker_box", placed);
        assertEquals(57, rules.resolve("minecraft:red_shulker_box", "world|dim|1,2,3|minecraft:red_shulker_box").gap);
        assertEquals(18, rules.forBlock("minecraft:red_shulker_box").gap);
        assertEquals("mod:red_shulker_box", ContainerTypeGroups.key("mod:red_shulker_box"));
    }
    @Test void legacyVariantsMigrateWithBasePriorityAndKeepCoordinateRules() {
        var rules = new ContainerUiRules(); var damaged = new ContainerUiProfile(); damaged.gap = 60;
        var base = new ContainerUiProfile(); base.gap = 30;
        rules.blocks.put("minecraft:damaged_anvil", damaged); rules.blocks.put("minecraft:anvil", base);
        rules.blocks.put("minecraft:red_shulker_box", damaged.copy());
        rules.locations.put("exact|minecraft:red_shulker_box", damaged.copy()); rules.validated();
        assertEquals(2, rules.blocks.size()); assertEquals(30, rules.forBlock("minecraft:damaged_anvil").gap);
        assertEquals(60, rules.forBlock("minecraft:blue_shulker_box").gap);
        assertTrue(rules.locations.containsKey("exact|minecraft:red_shulker_box"));
        assertFalse(rules.blocks.containsKey("minecraft:red_shulker_box"));
    }
    @Test void allFourSidesPlaceSeparateModulesAndOffsetsStayIndependent() {
        for (var side : ContainerUiProfile.Side.values()) {
            var p = new ContainerUiProfile(); p.backpackSide = side; p.gap = 30;
            var b = ContainerPanelLayout.place(246, p);
            switch (side) {
                case RIGHT -> assertEquals(276, b.backpackX());
                case LEFT -> assertEquals(-252, b.backpackX());
                case BELOW -> assertEquals(242, b.backpackY());
                case ABOVE -> assertEquals(-242, b.backpackY());
            }
            p.containerX = 14; p.containerY = -8; p.backpackX = -10; p.backpackY = 12;
            var shifted = ContainerPanelLayout.place(246, p);
            assertEquals(b.baseline(), shifted.baseline());
            assertEquals(b.backpackX() - 24, shifted.backpackX());
            assertEquals(b.backpackY() + 20, shifted.backpackY());
            assertTrue(shifted.bounds().x() <= 0 && shifted.bounds().x() + shifted.bounds().width() >= 246);
            assertTrue(shifted.bounds().x() <= shifted.backpackX() && shifted.bounds().x() + shifted.bounds().width() >= shifted.backpackX() + 222);
            assertTrue(shifted.bounds().y() <= shifted.backpackY() - 36 && shifted.bounds().y() + shifted.bounds().height() >= shifted.backpackY() + 176);
        }
    }
}
