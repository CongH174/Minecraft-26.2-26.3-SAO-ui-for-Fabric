package io.github.saoui;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class UiThemeTest {
    @Test void parsesSixDigitHexAndRejectsPartialInvalidOrAlphaValues(){
        assertEquals(0x123ABC,UiTheme.parse(" #123aBc "));assertEquals(0,UiTheme.parse("000000"));
        for(var s:new String[]{"#fff","12345","#11223344","#GG2233","","0x123456"})assertNull(UiTheme.parse(s));
        assertNull(UiTheme.parse(null));assertEquals("#123ABC",UiTheme.hex(0x123abc));
    }
    @Test void legacyAndMalformedColorsHaveStableDefaults(){
        var g=new Gson();var c=g.fromJson("{}",SaoConfig.class).validated();assertEquals(UiTheme.DEFAULT_BACKGROUND,c.theme.background);
        c=g.fromJson("{\"theme\":null}",SaoConfig.class).validated();assertNotNull(c.theme);
        c.theme.background=-1;c.theme.accent=0x1000000;c.validated();assertEquals(UiTheme.DEFAULT_BACKGROUND,c.theme.background);assertEquals(UiTheme.DEFAULT_ACCENT,c.theme.accent);
    }
    @Test void nestedDraftAndPersistenceAreIsolatedFromOtherModules(){
        var c=new SaoConfig();var d=c.copy();d.theme.background=0x183044;d.theme.accent=0x38D9E8;
        assertEquals(UiTheme.DEFAULT_BACKGROUND,c.theme.background);
        var g=new Gson();var loaded=g.fromJson(g.toJson(d),SaoConfig.class).validated();
        assertEquals(d.theme.background,loaded.theme.background);assertEquals(d.theme.accent,loaded.theme.accent);
        loaded.resetHud();loaded.resetModules();assertEquals(d.theme.background,loaded.theme.background);
        loaded.theme=new UiTheme();assertEquals(UiTheme.DEFAULT_ACCENT,loaded.theme.accent);
    }
    @Test void textContrastRemainsReadableAcrossRgbSpace(){
        for(int r=0;r<=255;r+=17)for(int g=0;g<=255;g+=17)for(int b=0;b<=255;b+=17){
            int bg=r<<16|g<<8|b;double a=UiTheme.luminance(bg),t=UiTheme.luminance(UiTheme.text(bg));
            assertTrue((Math.max(a,t)+.05)/(Math.min(a,t)+.05)>=4.5,UiTheme.hex(bg));
        }
    }
}
