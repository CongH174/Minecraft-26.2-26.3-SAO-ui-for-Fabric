package io.github.saoui;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SaoConfigTest {
    @Test void universalContainersAreOptInCopiedAndPersistedIndependently() {
        var gson = new Gson();
        var config = gson.fromJson("{}", SaoConfig.class).validated();
        assertFalse(config.replaceAllContainers);
        var draft = config.copy();
        draft.replaceAllContainers = true;
        draft.blockUiEnabled = false;
        draft.containers.defaults.enabled = false;
        assertFalse(config.replaceAllContainers);
        var loaded = gson.fromJson(gson.toJson(draft), SaoConfig.class).validated();
        assertTrue(loaded.copy().replaceAllContainers);
        assertFalse(loaded.blockUiEnabled);
        assertFalse(loaded.containers.defaults.enabled);
        loaded.resetModules();
        assertTrue(loaded.replaceAllContainers);
        loaded.resetHud();
        assertFalse(loaded.replaceAllContainers);
    }

    @Test void validatesAndCopiesVisualPreferences() {
        var config = new SaoConfig();
        config.blockUiEnabled = false;
        config.parallaxStrength = Float.NaN;
        config.validated();
        assertEquals(1f, config.parallaxStrength);
        assertFalse(config.copy().blockUiEnabled);
        config.parallaxStrength = -1;
        assertEquals(.2f, config.validated().parallaxStrength);
        assertFalse(config.parallaxEnabled);
        config.parallaxStrength = 5;
        assertEquals(2, config.validated().parallaxStrength);
    }
    @Test void upgradesExistingHudConfigWithoutChangingHudValues() {
        var config = new Gson().fromJson("{\"hudEnabled\":false,\"scale\":1.5,\"x\":24,\"y\":30}", SaoConfig.class).validated();
        assertFalse(config.hudEnabled);
        assertEquals(1.5f, config.scale);
        assertEquals(24, config.x);
        assertEquals(MenuModule.defaultOrder(), config.moduleOrder);
        assertEquals(MenuModule.PROFILE, config.home());
        assertTrue(config.hiddenModules.isEmpty());
    }

    @Test void repairsMissingDuplicateUnknownAndNullModuleValues() {
        var config = new SaoConfig();
        config.moduleOrder = Arrays.asList("equipment", null, "removed-mod", "equipment");
        config.hiddenModules = Arrays.asList(null, "settings", "removed-mod", "profile", "profile");
        config.homeModule = null;
        config.validated();
        assertEquals(List.of("equipment", "profile", "inventory", "settings"), config.moduleOrder);
        assertEquals(List.of("profile"), config.hiddenModules);
        assertEquals(MenuModule.EQUIPMENT, config.home());
        config.moduleOrder = config.hiddenModules = null;
        config.validated();
        assertEquals(MenuModule.defaultOrder(), config.moduleOrder);
        assertTrue(config.hiddenModules.isEmpty());
    }

    @Test void homeUsesStableModuleIdAndFallsBackToFirstVisibleModule() {
        var config = new SaoConfig();
        config.moduleOrder = new ArrayList<>(List.of("inventory", "settings", "equipment", "profile"));
        config.homeModule = "equipment";
        config.validated();
        assertEquals(MenuModule.EQUIPMENT, config.home());
        config.hiddenModules.add("equipment");
        config.validated();
        assertEquals(MenuModule.INVENTORY, config.home());
        config.hiddenModules = new ArrayList<>(MenuModule.defaultOrder());
        config.validated();
        assertEquals(List.of(MenuModule.SETTINGS), config.enabledModules());
        assertEquals(MenuModule.SETTINGS, config.home());
    }

    @Test void draftChangesAndResetsDoNotLeakIntoActiveConfig() {
        var config = new SaoConfig();
        var draft = config.copy();
        draft.moduleOrder.remove("profile");
        draft.moduleOrder.add("profile");
        draft.hiddenModules.add("equipment");
        draft.homeModule = "inventory";
        assertEquals(MenuModule.defaultOrder(), config.moduleOrder);
        assertTrue(config.hiddenModules.isEmpty());
        assertEquals(MenuModule.PROFILE, config.home());
        draft.scale = 1.75f;
        draft.resetModules();
        assertEquals(1.75f, draft.scale);
        draft.homeModule = "inventory";
        draft.resetHud();
        assertEquals(MenuModule.INVENTORY, draft.home());
    }

    @Test void savedLayoutRoundTripsOrderVisibilityAndHome() {
        var config = new SaoConfig();
        config.moduleOrder = new ArrayList<>(List.of("settings", "inventory", "profile", "equipment"));
        config.hiddenModules.add("profile");
        config.homeModule = "inventory";
        var gson = new Gson();
        var loaded = gson.fromJson(gson.toJson(config), SaoConfig.class).validated();
        assertEquals(config.moduleOrder, loaded.moduleOrder);
        assertEquals(config.hiddenModules, loaded.hiddenModules);
        assertEquals(config.homeModule, loaded.homeModule);
        assertEquals(List.of(MenuModule.SETTINGS, MenuModule.INVENTORY, MenuModule.EQUIPMENT), loaded.enabledModules());
    }
}
