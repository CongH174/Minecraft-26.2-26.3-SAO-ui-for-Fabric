package io.github.saoui;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UiMathTest {
    @Test void handlesDeadOverhealedAndInvalidHealth() {
        assertEquals(0, UiMath.ratio(-1, 20));
        assertEquals(1, UiMath.ratio(40, 20));
        assertEquals(0, UiMath.ratio(10, 0));
        assertEquals(0, UiMath.ratio(Float.NaN, 20));
        assertEquals(0, UiMath.ratio(10, Float.POSITIVE_INFINITY));
        assertEquals(0.5, UiMath.ratio(10, 20));
    }

    @Test void animationHasSameSpeedAtDifferentFrameRates() {
        double at30 = 1, at144 = 1;
        for (int i = 0; i < 30; i++) at30 = UiMath.approach(at30, 0.25, 1.0 / 30);
        for (int i = 0; i < 144; i++) at144 = UiMath.approach(at144, 0.25, 1.0 / 144);
        assertEquals(at30, at144, 1e-10);
        assertTrue(at30 >= 0.25 && at30 < 0.251);
        assertEquals(0.25, UiMath.approach(Double.NaN, 0.25, 0.1));
    }

    @Test void panelFitsSmallViewportAndClampsPosition() {
        float scale = UiMath.fitScale(320, 180, 2, 340, 36);
        assertTrue(scale * 340 <= 312.001);
        assertEquals(0, UiMath.fitPosition(300, 320, 340));
        assertEquals(220, UiMath.fitPosition(999, 320, 100));
        assertEquals(0, UiMath.fitPosition(-9, 320, 100));
        assertTrue(Float.isFinite(UiMath.fitScale(320, 180, Float.NaN, 340, 36)));
    }
}
