package io.github.saoui;

import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import net.fabricmc.loader.api.Version;
import net.fabricmc.loader.api.metadata.version.VersionPredicate;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ModMetadataTest {
    @Test void packagedMetadataAcceptsTheVersionsUsedToBuildIt() throws Exception {
        try (var stream = getClass().getResourceAsStream("/fabric.mod.json")) {
            assertNotNull(stream, "Processed mod metadata must be on the test classpath");
            var depends = JsonParser.parseReader(new InputStreamReader(stream, StandardCharsets.UTF_8))
                    .getAsJsonObject().getAsJsonObject("depends");
            String[][] versions = {
                    {"minecraft", "saoui.minecraftVersion"},
                    {"fabricloader", "saoui.loaderVersion"},
                    {"fabric-api", "saoui.fabricApiVersion"}
            };
            for (var entry : versions) {
                String constraint = depends.get(entry[0]).getAsString();
                String version = System.getProperty(entry[1]);
                assertNotNull(version, "Missing build version: " + entry[1]);
                assertTrue(VersionPredicate.parse(constraint).test(Version.parse(version)),
                        entry[0] + " " + version + " rejected by " + constraint);
            }
            var minecraft = VersionPredicate.parse(depends.get("minecraft").getAsString());
            assertFalse(minecraft.test(Version.parse("26.3")), "26.3 requires its separate build");
            assertFalse(minecraft.test(Version.parse("26.4")), "Do not advertise untested future releases");
        }
    }
}
