# SAO UI visual system — 0.8

Silver #E3E8E3, chalk #F3F5EE, graphite #404443, muted #748077, border #B6C2B8, selected amber #F1B438. Use Minecraft's font and existing item/entity/SAO textures. No extra image assets or fonts.

The K menu keeps the live player portrait on the left, circular navigation in the center and content on the right. Icons enter in a 32 ms stagger; opening takes 520 ms, closing 240 ms and page reveal 260 ms. The plane faces the screen throughout, with configurable pointer displacement.

Block containers use two flat panels with matching typography and amber accents. Container contents or a family-specific workflow occupy the left panel; all 36 native player inventory slots occupy a separate right panel. Storage cells use a 22-unit grid, 20-unit backgrounds and real 16-unit item renders. Large chests retain six rows. A third drawer exposes the real recipe book when requested.

Smelting has vertically separated input/fuel and a progress arrow to the output. Crafting has a spaced material grid and result. Anvil has a wide name field and two-item combination. Grinding has two inputs and repair output. Smithing has template/base/material/result plus a model preview. Brewing has a reagent/fuel row and a branch to three potion slots. Stonecutting, enchanting, beacon and loom retain their functional choice regions but replace their chrome and backgrounds. Cartography retains the actual map renderer. Empty space keeps the floating panels readable against the world.

A 420 ms entrance scales/rises from the world block projection. The finished group is centered and fits the GUI viewport, including the optional recipe drawer. Clamp pointer drift against scaled bounds. The same affine transform handles display and inverse pointer coordinates. Native PIP model/banner previews ignore the GUI pose in 26.3, so their bounds are transformed explicitly.

Vanilla Screen/Menu identities, slot indices and callback behavior are retained. Only current client Slot instances receive new positions. Scoped details extraction keeps map, banner, model, native widgets and tooltip logic, while suppressing vanilla container textures. One native slot extraction and one cursor pass render contents and quick-craft previews. Unknown menu types retain their existing rendering.

0.8 adds a narrow armor rail to the left of the portrait. It uses the same flat slot styling and native empty-slot icons; four real equipment slots stay independent from content pages.

Container/backpack panels are independent modules. Four arrangements place the backpack right, below, left or above the workstation. Each panel has independent X/Y offsets and a shared configurable gap. Fit the actual union, retaining a stable baseline anchor so independent shifts do not cancel during centering. Recipe drawers extend beyond the leftmost module; PIP previews stay anchored to the workstation.

The settings editor exposes scope first (defaults, block type, placed block), then behavior and position controls. Show actual target coordinates for position-specific overrides. Retain drafts, preserve inherited values until edited and provide a single action to remove an override. Avoid global, inseparable additions in future features.

- Hold the block affine frame steady while mouse buttons are held; resume parallax after release. K-menu inventory/armor gestures likewise hold translation. This prevents small, fitted slots sliding away before placement completes.
