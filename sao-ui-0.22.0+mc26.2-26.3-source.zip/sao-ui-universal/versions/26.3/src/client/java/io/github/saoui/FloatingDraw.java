package io.github.saoui;

import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.saoui.mixin.GuiGraphicsAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2f;
import net.minecraft.world.item.ItemStack;

/** Projected meshes use the game's backend-neutral GUI pipeline. */
public final class FloatingDraw {
    private static final float[] QUAD = {0, 0, 0, 1, 1, 1, 1, 0};
    private static final float[] DISC = discMesh();
    private FloatingDraw() {}

    private static float[] discMesh() {
        int segments = 48;
        float[] mesh = new float[segments * 8];
        for (int i = 0; i < segments; i++) {
            // Match the clockwise GUI quad winding (the pipeline culls the reverse face).
            double a = -Math.PI * 2 * i / segments, b = -Math.PI * 2 * (i + 1) / segments;
            int at = i * 8;
            mesh[at + 2] = (float) Math.cos(a);
            mesh[at + 3] = (float) Math.sin(a);
            mesh[at + 4] = (float) Math.cos(b);
            mesh[at + 5] = (float) Math.sin(b);
        }
        return mesh;
    }

    public static int alpha(int color, double opacity) {
        int alpha = (int) Math.round((color >>> 24) * Math.clamp(opacity, 0, 1));
        return (color & 0xFFFFFF) | (alpha << 24);
    }

    public static ScreenRectangle bounds(MenuProjection p, double x, double y, double w, double h) {
        var a = p.project(x, y); var b = p.project(x + w, y);
        var c = p.project(x, y + h); var d = p.project(x + w, y + h);
        int left = (int) Math.floor(Math.min(Math.min(a.x(), b.x()), Math.min(c.x(), d.x())));
        int top = (int) Math.floor(Math.min(Math.min(a.y(), b.y()), Math.min(c.y(), d.y())));
        int right = (int) Math.ceil(Math.max(Math.max(a.x(), b.x()), Math.max(c.x(), d.x())));
        int bottom = (int) Math.ceil(Math.max(Math.max(a.y(), b.y()), Math.max(c.y(), d.y())));
        return new ScreenRectangle(left, top, Math.max(1, right - left), Math.max(1, bottom - top));
    }

    public static void rect(GuiGraphicsExtractor g, MenuProjection p, double x, double y,
                            double w, double h, int color) {
        submit(g, new MeshState(p, QUAD, x, y, w, h, UiAppearance.surface(color), bounds(p, x, y, w, h)));
    }

    public static void disc(GuiGraphicsExtractor g, MenuProjection p, double x, double y, double radius, int color) {
        if (radius <= 0.05 || (color >>> 24) == 0) return;
        submit(g, new MeshState(p, DISC, x, y, radius, radius, UiAppearance.surface(color),
                bounds(p, x - radius, y - radius, radius * 2, radius * 2)));
    }

    private static void submit(GuiGraphicsExtractor g, MeshState state) {
        if ((state.color >>> 24) != 0) ((GuiGraphicsAccessor) g).saoui$renderState().addGuiElement(state);
    }

    static void tangent(GuiGraphicsExtractor g, MenuProjection p, double x, double y) {
        var t = p.tangent(x, y);
        g.pose().mul(new Matrix3x2f((float) t.xx(), (float) t.xy(), (float) t.yx(), (float) t.yy(),
                (float) t.x(), (float) t.y()));
    }

    public static void text(GuiGraphicsExtractor g, MenuProjection p, String text,
                            double x, double y, int color) {
        if ((color >>> 24) < 4) return;
        g.pose().pushMatrix();
        tangent(g, p, x, y);
        g.text(Minecraft.getInstance().font, text, 0, 0, color, false);
        g.pose().popMatrix();
    }

    public static void icon(GuiGraphicsExtractor g, MenuProjection p, Identifier icon,
                            double centerX, double centerY, float size, double opacity) {
        g.pose().pushMatrix();
        tangent(g, p, centerX, centerY);
        g.pose().scale(size / 64, size / 64);
        g.blit(RenderPipelines.GUI_TEXTURED, icon, -32, -32, 0, 0, 64, 64, 64, 64,
                alpha(0xFFFFFFFF, opacity));
        g.pose().popMatrix();
    }

    public static void item(GuiGraphicsExtractor g, MenuProjection p, ItemStack stack, double x, double y) {
        g.pose().pushMatrix();
        tangent(g, p, x, y);
        g.item(stack, 0, 0);
        g.itemDecorations(Minecraft.getInstance().font, stack, 0, 0);
        g.pose().popMatrix();
    }

    private record MeshState(MenuProjection projection, float[] mesh, double x, double y,
                             double scaleX, double scaleY, int color, ScreenRectangle bounds)
            implements GuiElementRenderState {
        @Override public RenderPipeline pipeline() { return RenderPipelines.GUI; }
        @Override public TextureSetup textureSetup() { return TextureSetup.noTexture(); }
        @Override public ScreenRectangle scissorArea() { return null; }
        @Override public void buildVertices(VertexConsumer vertices) {
            for (int i = 0; i < mesh.length; i += 2) {
                var at = projection.project(x + mesh[i] * scaleX, y + mesh[i + 1] * scaleY);
                vertices.addVertex((float) at.x(), (float) at.y(), 0).setColor(color);
            }
        }
    }
}
