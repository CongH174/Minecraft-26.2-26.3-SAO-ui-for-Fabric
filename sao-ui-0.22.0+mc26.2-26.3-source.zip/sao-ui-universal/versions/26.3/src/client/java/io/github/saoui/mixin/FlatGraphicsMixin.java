package io.github.saoui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import io.github.saoui.FlatContainerUi;
import io.github.saoui.UniversalContainerUi;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.client.model.object.banner.BannerFlagModel;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.entity.BannerPatternLayers;
import org.joml.Vector3fc;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiGraphicsExtractor.class)
public abstract class FlatGraphicsMixin {
    @ModifyVariable(method="innerFill",at=@At("HEAD"),argsOnly=true,ordinal=4)
    private int saoui$surfaceOpacity(int color){return io.github.saoui.UiAppearance.surface(color);}

    // PIP previews ignore the pose stack in 26.3; transform their screen bounds explicitly.
    @WrapMethod(method = "entity")
    private void saoui$entity(EntityRenderState state, float size, Vector3fc offset, Quaternionfc rotation, Quaternionfc camera,
                              int x1, int y1, int x2, int y2, Operation<Void> original) {
        if (FlatContainerUi.nativePass()) {
            var area = FlatContainerUi.entityPreview();
            if (area != null) { x1 = area.x(); y1 = area.y(); x2 = x1 + area.width(); y2 = y1 + area.height(); }
            var pose = ((GuiGraphicsExtractor)(Object)this).pose();
            original.call(state, size * Math.abs(pose.m00()), offset, rotation, camera,
                    (int)(x1 * pose.m00() + pose.m20()), (int)(y1 * pose.m11() + pose.m21()),
                    (int)(x2 * pose.m00() + pose.m20()), (int)(y2 * pose.m11() + pose.m21()));
        } else original.call(state, size, offset, rotation, camera, x1, y1, x2, y2);
    }
    @WrapMethod(method = "bannerPattern")
    private void saoui$banner(BannerFlagModel model, DyeColor color, BannerPatternLayers patterns,
                              int x1, int y1, int x2, int y2, Operation<Void> original) {
        if (FlatContainerUi.nativePass()) {
            var pose = ((GuiGraphicsExtractor)(Object)this).pose();
            original.call(model, color, patterns, (int)(x1 * pose.m00() + pose.m20()), (int)(y1 * pose.m11() + pose.m21()),
                    (int)(x2 * pose.m00() + pose.m20()), (int)(y2 * pose.m11() + pose.m21()));
        } else original.call(model, color, patterns, x1, y1, x2, y2);
    }
    @Inject(method = "blit(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIFFIIIIIII)V", at = @At("HEAD"), cancellable = true)
    private void saoui$removeContainerTexture(RenderPipeline p, Identifier id, int x, int y, float u, float v,
                                              int w, int h, int rw, int rh, int tw, int th, int color, CallbackInfo ci) {
        if (FlatContainerUi.nativePass() && (!UniversalContainerUi.managed(net.minecraft.client.Minecraft.getInstance().gui.screen())
                || w >= 96 && h >= 48 || id.getPath().contains("background"))) ci.cancel();
    }
    @WrapMethod(method = "blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V")
    private void saoui$flatSprite(RenderPipeline p, Identifier id, int x, int y, int w, int h, Operation<Void> original) {
        if (!FlatContainerUi.sprite((GuiGraphicsExtractor)(Object)this, id, x, y, w, h)) original.call(p, id, x, y, w, h);
    }
    @WrapMethod(method = "blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIII)V")
    private void saoui$flatTintedSprite(RenderPipeline p, Identifier id, int x, int y, int w, int h, int color, Operation<Void> original) {
        if (!FlatContainerUi.sprite((GuiGraphicsExtractor)(Object)this, id, x, y, w, h)) original.call(p, id, x, y, w, h, color);
    }
    @WrapMethod(method = "blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIIIIII)V")
    private void saoui$flatClippedSprite(RenderPipeline p, Identifier id, int tw, int th, int u, int v, int x, int y, int w, int h, Operation<Void> original) {
        if (!FlatContainerUi.sprite((GuiGraphicsExtractor)(Object)this, id, x, y, w, h)) original.call(p, id, tw, th, u, v, x, y, w, h);
    }
    @ModifyVariable(method = {
            "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
            "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V",
            "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V"
    }, at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private int saoui$readableText(int color) { return UniversalContainerUi.textColor(color); }
    @WrapMethod(method = "blitSprite(Lcom/mojang/renderpearl/api/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIIIIIIII)V")
    private void saoui$universalTintedClip(RenderPipeline p, Identifier id, int tw, int th, int u, int v,
                                         int x, int y, int w, int h, int color, Operation<Void> original) {
        if (!FlatContainerUi.sprite((GuiGraphicsExtractor)(Object)this, id, x, y, w, h)) original.call(p, id, tw, th, u, v, x, y, w, h, color);
    }

}
