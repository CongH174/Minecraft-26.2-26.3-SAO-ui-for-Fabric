# Third-party assets

Source: https://github.com/Bluexin/mcui

Pinned commit: `bc6afc947202c46674fa0466dcfbde589c0bc8d6`

Upstream base path: `common/src/main/resources/assets/saoui/textures/`

Authors credited by upstream: Bluexin, Tencao. Upstream repository license: GNU GPL version 3, retained verbatim in LICENSE. No per-image license files were found alongside these PNGs. Preserve this notice and the upstream license when redistributing.

Local base path: `src/main/resources/assets/saoui/textures/`. Files are copied byte-for-byte; no texture edits. Font and audio assets are not included. New Java implementation does not copy the old Kotlin/Lua rendering engine.

| Relative PNG path | SHA-256 |
|---|---|
| `sao/gui.png` | `95f5d2f34e1bb9612608dba780c77b0d3894cab5c27b641f244ab556c6718a6c` |
| `sao/menu/icons/profile.png` | `404aa3eed408f48b1cc911073fee5aae61d71bb84eaf7e8931b86ee111548a67` |
| `sao/menu/icons/items.png` | `8743f8a83182169f85b6f86ee4d425c39c9b1691d4386658dda967cba80200ba` |
| `sao/menu/icons/settings.png` | `fb25ea779ba163659042aa3fd6e2a05fa21b2685c8c6661b9150b5251cf11228` |
| `sao/menu/icons/logout.png` | `d5c25ada39f01cb899408bd1137296a16d663881f5ac7154107832910a4f9d33` |
| `sao/menu/icons/equipment.png` | `8acaa82f35cdc995ddc1bcfc4d2e5c9867904986e2ffb22c317e465878e7a59b` |

UV reference: upstream `common/src/main/resources/assets/saoui/themes/sao/fragments/health_box.xml`. Atlas is 1024x1024; legacy theme coordinates use a 256-unit grid. Menu icons are 64x64.

Gradle wrapper files originate from FabricMC/fabric-example-mod (26.2 branch, CC0 template). Gradle distribution checksum is pinned in gradle-wrapper.properties.
