package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Uses the real player InventoryMenu and MouseHandler, including server recipes and cleanup. */
public final class PlayerCraftingGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        try(var world=c.worldBuilder().create()){
            world.getConnection().waitForChunksRender();c.waitForScreen(null);
            c.runOnClient(client->{client.options.pauseOnLostFocus=false;SaoUiClient.config().uiScale=2;SaoUiClient.config().homeModule="inventory";SaoUiClient.config().parallaxStrength=0;SaoUiClient.config().craftingVisible=true;});
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();p.getInventory().setItem(9,new ItemStack(Items.OAK_PLANKS,16));p.getInventory().setItem(10,new ItemStack(Items.STONE,3));p.inventoryMenu.broadcastChanges();});
            c.waitFor(client->client.player.getInventory().getItem(9).getCount()==16);
            open(c);assertBounds(c);
            int wideSlot=c.computeOnClient(client->slot(client.gui.screen(),9).getWidth());
            click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);
            for(int id=1;id<=4;id++)click(c,id,InputConstants.MOUSE_BUTTON_RIGHT,0);
            click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);
            c.waitFor(client->client.player.inventoryMenu.getSlot(0).getItem().is(Items.CRAFTING_TABLE));world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.containerMenu==p.inventoryMenu,"Crafting opened a substitute server menu");for(int id=1;id<=4;id++)require(p.inventoryMenu.getSlot(id).getItem().getCount()==1,"Crafting input not synchronized");});
            capture(c,"sao-player-crafting-table");
            click(c,0,InputConstants.MOUSE_BUTTON_LEFT,0);click(c,11,InputConstants.MOUSE_BUTTON_LEFT,0);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.CRAFTING_TABLE)==1 && p.getInventory().countItem(Items.OAK_PLANKS)==12,"2x2 result did not consume exactly four planks");});
            // Two vertical inputs with three planks each: Shift result must craft all three batches.
            click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);
            for(int id:new int[]{1,3})for(int n=0;n<3;n++)click(c,id,InputConstants.MOUSE_BUTTON_RIGHT,0);
            click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);c.waitFor(client->client.player.inventoryMenu.getSlot(0).getItem().is(Items.STICK));
            click(c,0,InputConstants.MOUSE_BUTTON_LEFT,InputConstants.MOD_SHIFT);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.STICK)==12 && p.getInventory().countItem(Items.OAK_PLANKS)==6,"Native Shift crafting output or ingredient count incorrect");for(int id=1;id<=4;id++)require(!p.inventoryMenu.getSlot(id).hasItem(),"Shift craft left ingredients");});
            click(c,10,InputConstants.MOUSE_BUTTON_LEFT,0);click(c,0,InputConstants.MOUSE_BUTTON_LEFT,0);
            require(c.computeOnClient(client->client.player.inventoryMenu.getCarried().getCount())==3,"Result slot accepted an invalid deposit");click(c,10,InputConstants.MOUSE_BUTTON_LEFT,0);
            click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);click(c,1,InputConstants.MOUSE_BUTTON_RIGHT,0);click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);
            c.waitFor(client->client.player.inventoryMenu.getSlot(0).getItem().is(Items.OAK_BUTTON));
            control(c,"root.saoui.equipment");settle(c);
            require(c.computeOnClient(client->client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(s->s.menuSlot()>=0 && s.menuSlot()<=4).noneMatch(s->s.visible||s.active)),"Crafting slots remained active on another page");
            control(c,"root.saoui.inventory");settle(c);
            c.runOnClient(client->{var s=client.gui.screen();s.resize(s.width,s.height);});settle(c);
            require(c.computeOnClient(client->client.player.inventoryMenu.getSlot(1).getItem().getCount())==1,"Page switch/resize lost crafting ingredients");
            c.runOnClient(client->SaoUiClient.config().parallaxStrength=2);
            c.getInput().setCursorPos(854,480);c.waitTicks(8);assertBounds(c);capture(c,"sao-player-crafting-parallax");
            click(c,10,InputConstants.MOUSE_BUTTON_LEFT,0);close(c);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.inventoryMenu.getCarried().isEmpty(),"Closing did not return cursor stack");for(int id=0;id<=4;id++)require(!p.inventoryMenu.getSlot(id).hasItem(),"Closing did not clear native crafting grid");require(p.getInventory().countItem(Items.OAK_PLANKS)==6 && p.getInventory().countItem(Items.STONE)==3 && p.getInventory().countItem(Items.STICK)==12 && p.getInventory().countItem(Items.CRAFTING_TABLE)==1 && p.getInventory().countItem(Items.OAK_BUTTON)==0,"Closing duplicated or lost crafting materials/results");});
            c.getInput().pressKey(InputConstants.KEY_E);c.waitForScreen(InventoryScreen.class);
            require(c.computeOnClient(client->client.player.inventoryMenu.getCarried().isEmpty() && !client.player.inventoryMenu.getSlot(1).hasItem()),"Native E inventory disagreed with SAO grid cleanup");
            c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.waitForScreen(null);
            c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));control(c,"settings.saoui.crafting");control(c,"gui.cancel");
            require(c.computeOnClient(client->SaoUiClient.config().craftingVisible),"Canceled crafting preference leaked");
            c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));control(c,"settings.saoui.crafting");control(c,"gui.done");
            c.runOnClient(client->require(!new ConfigStore(FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load().craftingVisible,"Crafting preference not saved"));
            open(c);require(c.computeOnClient(client->slot(client.gui.screen(),9).getWidth())>wideSlot,"Hidden module still shrank inventory layout");
            require(c.computeOnClient(client->client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(s->s.menuSlot()>=0 && s.menuSlot()<=4).noneMatch(s->s.visible||s.active)),"Disabled crafting module remained interactive");
            close(c);world.getConnection().waitForServerboundPackets();
            SaoUiClient.LOGGER.info("SAO player crafting passed: real 2x2 table, split placement, Shift batches, result restrictions, page/resize retention, parallax bounds, native close/cursor conservation and settings save/cancel");
        }finally{c.runOnClient(client->{try{SaoUiClient.saveConfig(original);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
    }
    private static FloatingItemSlot slot(Screen s,int id){return s.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(w->w.menuSlot()==id && w.visible).findFirst().orElseThrow();}
    static void click(ClientGameTestContext c,int id,int button,int modifiers){
        double[] raw=c.computeOnClient(client->{var s=client.gui.screen();var w=slot(s,id);var win=client.getWindow();return new double[]{(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width,(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};});
        c.getInput().setCursorPos(raw[0],raw[1]);c.waitTick();
        c.runOnClient(client->client.mouseHandler.onButton(client.getWindow().handle(),new MouseButtonInfo(button,modifiers),1));c.waitTick();
        c.runOnClient(client->client.mouseHandler.onButton(client.getWindow().handle(),new MouseButtonInfo(button,modifiers),0));c.waitTick();
    }
    private static void control(ClientGameTestContext c,String key){
        SettingsNavigation.expose(c,key);
        double[] raw=c.computeOnClient(client->{var s=client.gui.screen();var w=SettingsNavigation.widgets(s).stream().filter(AbstractWidget.class::isInstance).map(AbstractWidget.class::cast).filter(b->b.getMessage().getContents() instanceof TranslatableContents t && t.getKey().equals(key)).findFirst().orElseThrow();var win=client.getWindow();return new double[]{(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width,(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};});
        c.getInput().setCursorPos(raw[0],raw[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTick();
    }
    private static void assertBounds(ClientGameTestContext c){c.runOnClient(client->{var s=client.gui.screen();for(var child:s.children())if(child instanceof FloatingItemSlot w && w.visible)require(w.getX()>=0 && w.getY()>=0 && w.getRight()<=s.width && w.getBottom()<=s.height,"Inventory/crafting slot clipped viewport");});}
    private static void settle(ClientGameTestContext c){c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());c.waitTicks(2);}
    private static void open(ClientGameTestContext c){c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);settle(c);}
    private static void close(ClientGameTestContext c){c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);}
    private static void capture(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.waitTick();c.takeScreenshot(name);}
    private static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
}
