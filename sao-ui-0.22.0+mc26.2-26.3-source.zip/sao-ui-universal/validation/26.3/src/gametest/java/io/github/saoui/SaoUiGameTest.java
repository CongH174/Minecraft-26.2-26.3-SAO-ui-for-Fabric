package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.world.entity.player.Player;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

/** Runs in an isolated development world, never included in the release jar. */
public final class SaoUiGameTest implements FabricClientGameTest {
    @Override
    public void runTest(ClientGameTestContext context) {
        context.runOnClient(client -> client.options.pauseOnLostFocus = false);
        try (TestSingleplayerContext world = context.worldBuilder().create()) {
            world.getConnection().waitForChunksRender();
            context.waitForScreen(null);
            seedInventory(context, world);
            context.waitTicks(20);
            context.runOnClient(client -> {
                client.gui.toastManager().clear();
                client.gui.hud.getChat().clearMessages(true);
            });
            context.waitTicks(10);
            context.takeScreenshot("sao-hud");

            context.getInput().pressKey(InputConstants.KEY_K);
            context.waitForScreen(SaoMenuScreen.class);
            settle(context);
            context.takeScreenshot("sao-menu");
            float heading = context.computeOnClient(client -> client.player.getYRot());
            context.getInput().setCursorPos(10, 10);
            context.waitTicks(4);
            context.takeScreenshot("sao-portrait-left");
            context.getInput().setCursorPos(800, 420);
            context.waitTicks(4);
            context.takeScreenshot("sao-portrait-right");
            require(context.computeOnClient(client -> client.player.getYRot()) == heading,
                    "Paper doll changed the actual player heading");
            context.getInput().pressKey(InputConstants.KEY_K);
            context.waitForScreen(null);
            context.waitTicks(2);
            require(context.computeOnClient(client -> client.gui.screen() == null), "Menu reopened after K");

            context.getInput().pressKey(InputConstants.KEY_K);
            context.waitForScreen(SaoMenuScreen.class);
            settle(context);
            clickProjected(context, "menu.saoui.inventory");
            settle(context);
            verifyInventoryView(context);
            context.takeScreenshot("sao-inventory");
            verifyInventoryTransfers(context, world);
            seedInventory(context, world);
            context.waitTicks(3);
            clickProjected(context, "root.saoui.equipment");
            settle(context);
            verifyCombatView(context);
            context.takeScreenshot("sao-equipment");
            context.clickScreenButton("menu.saoui.organize");
            context.waitForScreen(InventoryScreen.class);
            context.getInput().pressKey(InputConstants.KEY_ESCAPE);
            context.waitForScreen(null);

            context.getInput().pressKey(InputConstants.KEY_K);
            context.waitForScreen(SaoMenuScreen.class);
            settle(context);
            clickProjected(context, "root.saoui.settings");
            settle(context);
            context.clickScreenButton("menu.saoui.hud_settings");
            context.waitForScreen(SaoSettingsScreen.class);
            boolean original = context.computeOnClient(client -> SaoUiClient.config().smoothHealth);
            boolean blockOriginal = context.computeOnClient(client -> SaoUiClient.config().blockUiEnabled);
            float parallaxOriginal = context.computeOnClient(client -> SaoUiClient.config().parallaxStrength);
            boolean armorOriginal = context.computeOnClient(client -> SaoUiClient.config().armorSlotsVisible);
            pressSetting(context, "settings.saoui.smooth");
            pressSetting(context, "settings.saoui.block_ui");
            adjustSetting(context, "settings.saoui.parallax");
            pressSetting(context, "settings.saoui.armor_slots");
            context.clickScreenButton("gui.cancel");
            context.waitForScreen(SaoMenuScreen.class);
            settle(context);
            require(context.computeOnClient(client -> SaoUiClient.config().smoothHealth) == original,
                    "Cancel changed the active configuration");
            require(context.computeOnClient(client -> SaoUiClient.config().blockUiEnabled) == blockOriginal
                    && context.computeOnClient(client -> SaoUiClient.config().parallaxStrength) == parallaxOriginal,
                    "Cancel changed block animation/parallax preferences");
            require(context.computeOnClient(client -> SaoUiClient.config().armorSlotsVisible) == armorOriginal, "Cancel changed armor visibility");
            context.clickScreenButton("menu.saoui.hud_settings");
            context.waitForScreen(SaoSettingsScreen.class);
            pressSetting(context, "settings.saoui.smooth");
            pressSetting(context, "settings.saoui.armor_slots");
            context.clickScreenButton("gui.done");
            context.waitForScreen(SaoMenuScreen.class);
            settle(context);
            require(context.computeOnClient(client -> SaoUiClient.config().smoothHealth) != original,
                    "Save did not update the active configuration");
            require(context.computeOnClient(client -> client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance)
                    .map(FloatingItemSlot.class::cast).noneMatch(slot -> slot.menuSlot() >= 5 && slot.menuSlot() <= 8 && slot.visible)), "Armor module visibility switch was ignored");
            context.clickScreenButton("menu.saoui.hud_settings");
            context.waitForScreen(SaoSettingsScreen.class);
            context.takeScreenshot("sao-settings");
            SettingsNavigation.click(context,"settings.saoui.reset");
            context.clickScreenButton("gui.done");
            settle(context);
            context.clickScreenButton("menu.saoui.options");
            context.waitForScreen(OptionsScreen.class);
            context.getInput().pressKey(InputConstants.KEY_ESCAPE);
            context.waitForScreen(SaoMenuScreen.class);
            settle(context);
            context.clickScreenButton("menu.saoui.close");
            context.waitForScreen(null);
            verifyModuleSettings(context);
            captureAnimation(context);
            SaoUiClient.LOGGER.info("SAO UI game acceptance passed: menu, inventory, settings, save/cancel");
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void seedInventory(ClientGameTestContext context, TestSingleplayerContext world) {
        world.getServer().runOnServer(server -> {
            var player = server.getPlayerList().getPlayers().getFirst();
            var inventory = player.getInventory();
            for (int i = 0; i < 36; i++) inventory.setItem(i, new ItemStack(Items.COBBLESTONE, i + 1));
            var sword = new ItemStack(Items.DIAMOND_SWORD);
            sword.setDamageValue(123);
            sword.enchant(server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT)
                    .getOrThrow(Enchantments.SHARPNESS), 3);
            inventory.setItem(0, sword);
            inventory.setItem(1, new ItemStack(Items.BOW));
            inventory.setItem(2, new ItemStack(Items.CROSSBOW));
            inventory.setItem(8, new ItemStack(Items.IRON_PICKAXE));
            inventory.setItem(9, new ItemStack(Items.IRON_AXE));
            inventory.setItem(35, new ItemStack(Items.MACE));
            var custom = new ItemStack(Items.STICK);
            custom.set(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.builder()
                    .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(SaoUiClient.id("test_attack"),
                            3, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND).build());
            inventory.setItem(15, custom);
            inventory.setSelectedSlot(0);
            player.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.TRIDENT));
            player.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
            player.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
            player.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.DIAMOND_LEGGINGS));
            player.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.DIAMOND_BOOTS));
            player.inventoryMenu.broadcastChanges();
        });
        context.waitFor(client -> client.player != null
                && client.player.getInventory().getItem(35).is(Items.MACE)
                && client.player.getOffhandItem().is(Items.TRIDENT)
                && client.player.getMainHandItem().getEnchantments().size() == 1);
        context.runOnClient(client -> {
            var player = client.player;
            var entries = CombatItems.scan(player);
            require(entries.size() == 11, "Enchantable filter missed/duplicated an item: " + entries.size());
            require(!CombatItems.isEnchantable(player,new ItemStack(Items.COBBLESTONE)), "Building block treated as weapon");
            require(CombatItems.isEnchantable(player,new ItemStack(Items.DIAMOND_CHESTPLATE)), "Enchantable armor missing");
            var stats = CombatItems.stats(player, player.getMainHandItem());
            require(Math.abs(stats.damage() - 7) < 1e-6, "Sword damage was double counted: " + stats.damage());
            require(Math.abs(stats.speed() - 1.6) < 1e-6, "Incorrect sword attack speed: " + stats.speed());
        });
    }

    private static void verifyInventoryView(ClientGameTestContext context) {
        context.runOnClient(client -> {
            var screen = client.gui.screen();
            var slots = screen.children().stream().filter(FloatingItemSlot.class::isInstance)
                    .map(FloatingItemSlot.class::cast).filter(slot -> slot.menuSlot() < 0 || slot.menuSlot() > 8).toList();
            require(slots.size() == 37, "Inventory does not expose 27+9+offhand slots");
            for (int i = 0; i < 37; i++) {
                ItemStack expected = i == 36 ? client.player.getOffhandItem()
                        : client.player.getInventory().getItem(i < 27 ? i + 9 : i - 27);
                require(ItemStack.matches(expected, slots.get(i).displayedStack()), "Inventory slot mismatch: " + i);
            }
        });
        context.waitTicks(2);
    }

    private static void verifyInventoryTransfers(ClientGameTestContext context, TestSingleplayerContext world) {
        Map<String, Integer> before = context.computeOnClient(client -> contents(client.player));
        Map<String, Integer> serverBefore = world.getServer().computeOnServer(server -> contents(server.getPlayerList().getPlayers().getFirst()));
        int left = InputConstants.MOUSE_BUTTON_LEFT, right = InputConstants.MOUSE_BUTTON_RIGHT;
        clickSlot(context, 27, left, 0); // Main hand sword -> cursor.
        context.runOnClient(client -> {
            require(client.player.getInventory().getItem(0).isEmpty(), "Pickup left a duplicate sword");
            require(client.player.inventoryMenu.getCarried().is(Items.DIAMOND_SWORD), "Pickup did not carry the sword");
        });
        context.getInput().setCursorPos(600, 300);
        context.takeScreenshot("sao-carrying");
        clickSlot(context, 26, left, 0); // Swap with mace.
        clickSlot(context, 27, left, 0);
        world.getConnection().waitForServerboundPackets();
        world.getServer().runOnServer(server -> {
            var player = server.getPlayerList().getPlayers().getFirst();
            require(player.getInventory().getItem(0).is(Items.MACE), "Server did not receive the mace swap");
            var sword = player.getInventory().getItem(35);
            require(sword.is(Items.DIAMOND_SWORD) && sword.getDamageValue() == 123
                    && sword.getEnchantments().size() == 1, "Swap lost sword components on the server");
        });
        clickSlot(context, 27, left, 0);
        clickSlot(context, 26, left, 0);
        clickSlot(context, 27, left, 0); // Restore both weapons.

        clickSlot(context, 1, right, 0); // 11 -> 5 in slot, 6 carried.
        context.runOnClient(client -> require(client.player.inventoryMenu.getCarried().getCount() == 6,
                "Right click did not split the stack"));
        clickSlot(context, 2, right, 0); // Place one onto the 12-stack.
        clickSlot(context, 1, left, 0); // Return remaining 5; slot now 10.
        context.runOnClient(client -> require(client.player.getInventory().getItem(10).getCount() == 10
                && client.player.getInventory().getItem(11).getCount() == 13, "Single-item placement failed"));
        clickSlot(context, 1, left, 0);
        clickSlot(context, 2, left, 0); // Merge 10+13.
        context.runOnClient(client -> require(client.player.getInventory().getItem(11).getCount() == 23,
                "Stack merge failed"));
        clickSlot(context, 2, left, InputConstants.MOD_SHIFT);
        context.runOnClient(client -> require(client.player.getInventory().getItem(11).isEmpty(),
                "Shift-click did not move the stack to the hotbar"));

        clickSlot(context, 3, left, 0); // Pick 13 from backpack slot 12.
        dragSlots(context, left, 1, 2); // Even distribution, 6+6, cursor 1.
        context.runOnClient(client -> require(client.player.getInventory().getItem(10).getCount() == 6
                && client.player.getInventory().getItem(11).getCount() == 6
                && client.player.inventoryMenu.getCarried().getCount() == 1, "Even drag distribution failed"));
        clickSlot(context, 3, right, 0);
        clickSlot(context, 1, left, 0);
        dragSlots(context, right, 2, 3); // One each, cursor 4.
        clickSlot(context, 1, left, 0);
        context.runOnClient(client -> require(client.player.getInventory().getItem(10).getCount() == 4
                && client.player.getInventory().getItem(11).getCount() == 7
                && client.player.getInventory().getItem(12).getCount() == 2, "Right drag distribution failed"));

        slotKey(context, 1, InputConstants.KEY_2, '2');
        context.runOnClient(client -> require(client.player.getInventory().getItem(10).is(Items.BOW),
                "Number-key hotbar swap failed"));
        slotKey(context, 1, InputConstants.KEY_2, '2');
        slotKey(context, 1, InputConstants.KEY_F, 'f');
        context.runOnClient(client -> require(client.player.getInventory().getItem(10).is(Items.TRIDENT),
                "Offhand key swap failed"));
        slotKey(context, 1, InputConstants.KEY_F, 'f');

        clickSlot(context, 36, left, 0);
        context.runOnClient(client -> require(client.player.inventoryMenu.getCarried().is(Items.TRIDENT),
                "Offhand slot pickup failed"));
        clickSlot(context, 36, left, 0);
        clickSlot(context, 27, left, 0);
        clickProjected(context, "root.saoui.equipment");
        settle(context);
        context.runOnClient(client -> require(client.player.inventoryMenu.getCarried().is(Items.DIAMOND_SWORD),
                "Changing pages lost the carried item"));
        clickProjected(context, "root.saoui.inventory");
        settle(context);
        clickSlot(context, 27, left, 0);
        context.runOnClient(client -> require(contents(client.player).equals(before)
                && client.player.getInventory().getSelectedSlot() == 0, "Transfers lost/duplicated items or changed held slot"));
        world.getConnection().waitForServerboundPackets();
        world.getServer().runOnServer(server -> require(contents(server.getPlayerList().getPlayers().getFirst()).equals(serverBefore),
                "Server inventory totals/components changed after transfers"));

        clickSlot(context, 27, left, 0); // Close while holding an enchanted item.
        context.runOnClient(client -> client.gui.screen().onClose());
        context.waitForScreen(null);
        world.getConnection().waitForServerboundPackets();
        world.getServer().runOnServer(server -> {
            var player = server.getPlayerList().getPlayers().getFirst();
            require(player.inventoryMenu.getCarried().isEmpty(), "Close did not return the server cursor stack");
            require(contents(player).equals(serverBefore), "Close lost or duplicated carried items");
        });
        context.waitFor(client -> client.player.inventoryMenu.getCarried().isEmpty() && contents(client.player).equals(before));
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        clickProjected(context, "menu.saoui.inventory");
        settle(context);
        SaoUiClient.LOGGER.info("SAO inventory transfers passed: pickup/swap, split/merge, shift, drag, hotbar/offhand, server totals and close");
    }

    private static Map<String, Integer> contents(Player player) {
        var totals = new TreeMap<String, Integer>();
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) addStack(totals, player.getInventory().getItem(i));
        addStack(totals, player.inventoryMenu.getCarried());
        return totals;
    }

    private static void addStack(Map<String, Integer> totals, ItemStack stack) {
        if (!stack.isEmpty()) totals.merge(stack.getItem() + ":" + stack.getComponents(), stack.getCount(), Integer::sum);
    }

    private static MouseButtonEvent slotEvent(SaoMenuScreen screen, int index, int button, int modifiers) {
        var slots = screen.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(slot -> slot.menuSlot() < 0 || slot.menuSlot() > 8).toList();
        var slot = slots.get(index);
        return new MouseButtonEvent(slot.getX() + slot.getWidth() / 2.0, slot.getY() + slot.getHeight() / 2.0,
                new MouseButtonInfo(button, modifiers));
    }

    private static void clickSlot(ClientGameTestContext context, int index, int button, int modifiers) {
        context.runOnClient(client -> {
            var screen = (SaoMenuScreen) client.gui.screen();
            var event = slotEvent(screen, index, button, modifiers);
            require(screen.mouseClicked(event, false), "Inventory rejected slot " + index);
            screen.mouseReleased(event);
        });
        context.waitTick();
    }

    private static void dragSlots(ClientGameTestContext context, int button, int... indices) {
        context.runOnClient(client -> {
            var screen = (SaoMenuScreen) client.gui.screen();
            screen.mouseClicked(slotEvent(screen, indices[0], button, 0), false);
            for (int index : indices) screen.mouseDragged(slotEvent(screen, index, button, 0), 1, 0);
        });
        context.waitTick();
        context.takeScreenshot(button == InputConstants.MOUSE_BUTTON_LEFT ? "sao-drag-even" : "sao-drag-single");
        context.runOnClient(client -> {
            var screen = (SaoMenuScreen) client.gui.screen();
            screen.mouseReleased(slotEvent(screen, indices[indices.length - 1], button, 0));
        });
        context.waitTick();
    }

    private static void slotKey(ClientGameTestContext context, int index, int key, int keycode) {
        context.runOnClient(client -> {
            var screen = (SaoMenuScreen) client.gui.screen();
            var event = slotEvent(screen, index, InputConstants.MOUSE_BUTTON_LEFT, 0);
            screen.mouseMoved(event.x(), event.y());
            screen.keyPressed(new KeyEvent(key, keycode, 0));
        });
        context.waitTick();
    }

    private static void verifyCombatView(ClientGameTestContext context) {
        context.runOnClient(client -> {
            long visible = client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance)
                    .map(FloatingItemSlot.class::cast).filter(slot -> slot.menuSlot() < 0 || slot.menuSlot() > 8).filter(slot -> slot.visible).count();
            require(visible == CombatItems.scan(client.player).size(), "Equipment grid must show every enchantable item exactly once");
        });
    }

    private static void settle(ClientGameTestContext context) {
        context.waitFor(client -> client.gui.screen() instanceof SaoMenuScreen menu && menu.isAnimationSettled());
        context.waitTicks(2);
    }

    private static void clickProjected(ClientGameTestContext context, String translationKey) {
        context.runOnClient(client -> {
            var screen = client.gui.screen();
            for (var child : SettingsNavigation.widgets(screen)) {
                if (child instanceof FloatingButton button
                        && button.getMessage().getContents() instanceof TranslatableContents contents
                        && contents.getKey().equals(translationKey)) {
                    var click = new MouseButtonEvent(button.getX() + button.getWidth() / 2.0,
                            button.getY() + button.getHeight() / 2.0, new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT, 0));
                    require(screen.mouseClicked(click, false), "Projected button rejected pointer: " + translationKey);
                    return;
                }
            }
            throw new AssertionError("Missing projected button: " + translationKey);
        });
    }

    private static void captureAnimation(ClientGameTestContext context) {
        AtomicLong clock = new AtomicLong();
        context.setScreen(() -> new SaoMenuScreen(clock::get));
        for (int i = 0; i <= 16; i++) {
            clock.set(i * 40L);
            context.waitTick();
            context.takeScreenshot(String.format("sao-opening-%02d", i));
        }
        clock.set(1000);
        context.runOnClient(client -> client.gui.screen().onClose());
        for (int i = 1; i <= 6; i++) {
            clock.set(1000 + i * 40L);
            context.waitTick();
            context.takeScreenshot(String.format("sao-closing-%02d", i));
        }
        context.waitForScreen(null);
    }

    private static void adjustSetting(ClientGameTestContext context,String key) {
        SettingsNavigation.expose(context,key);
        context.runOnClient(client->{
            var slider=SettingsNavigation.widgets(client.gui.screen()).stream().filter(SaoSlider.class::isInstance).map(SaoSlider.class::cast).filter(w->w.settingKey().equals(key)).findFirst().orElseThrow();
            int steps=Math.round((slider.amount()>0?-slider.amount():1)*100);
            for(int i=0;i<Math.abs(steps);i++)slider.keyPressed(new net.minecraft.client.input.KeyEvent(steps>0?InputConstants.KEY_RIGHT:InputConstants.KEY_LEFT,0,0));
        });
    }

    private static void pressSetting(ClientGameTestContext context,String translationKey) { SettingsNavigation.click(context,translationKey); }

    private static void verifyModuleSettings(ClientGameTestContext context) {
        SaoConfig original = context.computeOnClient(client -> SaoUiClient.config().copy());
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        clickProjected(context, "root.saoui.settings");
        settle(context);
        context.clickScreenButton("menu.saoui.menu_layout");
        context.waitForScreen(SaoModuleSettingsScreen.class);
        moduleControl(context, "settings.saoui.module_up", "inventory");
        moduleControl(context, "settings.saoui.module_toggle", "equipment");
        moduleControl(context, "settings.saoui.module_home", "inventory");
        context.clickScreenButton("gui.cancel");
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        context.runOnClient(client -> {
            require(SaoUiClient.config().moduleOrder.equals(original.moduleOrder)
                    && SaoUiClient.config().hiddenModules.equals(original.hiddenModules)
                    && SaoUiClient.config().homeModule.equals(original.homeModule), "Cancel leaked layout changes");
            var disk = new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();
            require(disk.moduleOrder.equals(original.moduleOrder) && disk.homeModule.equals(original.homeModule),
                    "Cancel changed the saved menu layout");
        });
        context.clickScreenButton("menu.saoui.menu_layout");
        context.waitForScreen(SaoModuleSettingsScreen.class);
        moduleControl(context, "settings.saoui.module_up", "inventory");
        moduleControl(context, "settings.saoui.module_up", "settings");
        moduleControl(context, "settings.saoui.module_up", "settings");
        moduleControl(context, "settings.saoui.module_home", "inventory");
        moduleControl(context, "settings.saoui.module_toggle", "profile");
        moduleControl(context, "settings.saoui.module_toggle", "equipment");
        context.takeScreenshot("sao-module-settings");
        context.clickScreenButton("gui.done");
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        verifyRootOrder(context, "root.saoui.inventory", "root.saoui.settings", "menu.saoui.close");
        context.runOnClient(client -> {
            var disk = new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();
            require(disk.moduleOrder.equals(java.util.List.of("inventory", "settings", "profile", "equipment"))
                    && disk.hiddenModules.equals(java.util.List.of("profile", "equipment"))
                    && disk.homeModule.equals("inventory"), "Saved module layout did not persist");
        });
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(null);
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        verifyInventoryView(context);
        context.takeScreenshot("sao-home-inventory");
        clickSlot(context, 27, InputConstants.MOUSE_BUTTON_LEFT, 0);
        context.runOnClient(client -> require(!client.player.inventoryMenu.getCarried().isEmpty(),
                "Reordered inventory home could not pick up an item"));
        clickSlot(context, 27, InputConstants.MOUSE_BUTTON_LEFT, 0);
        clickProjected(context, "root.saoui.settings");
        settle(context);
        context.clickScreenButton("menu.saoui.menu_layout");
        context.waitForScreen(SaoModuleSettingsScreen.class);
        moduleControl(context, "settings.saoui.module_toggle", "inventory");
        context.clickScreenButton("gui.done");
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        verifyRootOrder(context, "root.saoui.settings", "menu.saoui.close");
        require(context.computeOnClient(client -> SaoUiClient.config().home()) == MenuModule.SETTINGS,
                "Hidden home page was not replaced by an enabled page");
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(null);
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        context.takeScreenshot("sao-home-settings-only");
        context.clickScreenButton("menu.saoui.menu_layout");
        context.waitForScreen(SaoModuleSettingsScreen.class);
        SettingsNavigation.click(context,"settings.saoui.modules_reset");
        context.clickScreenButton("gui.done");
        context.waitForScreen(SaoMenuScreen.class);
        settle(context);
        verifyRootOrder(context, "root.saoui.profile", "root.saoui.inventory", "root.saoui.equipment",
                "root.saoui.settings", "menu.saoui.close");
        context.runOnClient(client -> {
            require(SaoUiClient.config().home() == MenuModule.PROFILE && SaoUiClient.config().hiddenModules.isEmpty(),
                    "Reset did not restore the default modules");
            try { SaoUiClient.saveConfig(original); }
            catch (java.io.IOException error) { throw new java.io.UncheckedIOException(error); }
        });
        context.getInput().pressKey(InputConstants.KEY_K);
        context.waitForScreen(null);
        SaoUiClient.LOGGER.info("SAO module settings passed: reorder, visibility, home, save/cancel, persistence, fallback and reset");
    }

    private static void verifyRootOrder(ClientGameTestContext context, String... expected) {
        context.runOnClient(client -> {
            var keys = client.gui.screen().children().stream().filter(FloatingButton.class::isInstance)
                    .map(FloatingButton.class::cast).map(button -> (TranslatableContents) button.getMessage().getContents())
                    .map(TranslatableContents::getKey).filter(key -> key.startsWith("root.saoui.") || key.equals("menu.saoui.close")).toList();
            require(keys.equals(java.util.List.of(expected)), "Root order does not match configured modules: " + keys);
        });
    }

    private static void moduleControl(ClientGameTestContext context, String key, String module) {
        context.runOnClient(client -> {
            var screen = client.gui.screen();
            for (var child : screen.children()) {
                if (child instanceof SaoButton button && button.active
                        && button.getMessage().getContents() instanceof TranslatableContents text && text.getKey().equals(key)
                        && text.getArgs()[0] instanceof net.minecraft.network.chat.Component name
                        && name.getContents() instanceof TranslatableContents moduleName && moduleName.getKey().equals("root.saoui." + module)) {
                    var event = new MouseButtonEvent(button.getX() + button.getWidth() / 2.0, button.getY() + button.getHeight() / 2.0,
                            new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT, 0));
                    require(screen.mouseClicked(event, false), "Module control rejected pointer");
                    screen.mouseReleased(event);
                    return;
                }
            }
            throw new AssertionError("Missing active module control: " + key + " / " + module);
        });
        context.waitTick();
    }
}
