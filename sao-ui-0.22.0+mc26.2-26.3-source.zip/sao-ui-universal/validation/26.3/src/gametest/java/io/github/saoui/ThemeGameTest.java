package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.*;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.*;

public final class ThemeGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        try(var world=c.worldBuilder().create()){
            world.getConnection().waitForChunksRender();c.waitForScreen(null);
            open(c);hex(c,"#183044");c.clickScreenButton("gui.cancel");
            require(c.computeOnClient(client->SaoUiClient.config().theme.background)==original.theme.background,"Canceled theme leaked into config");
            open(c);hex(c,"#183044");SettingsNavigation.click(c,"settings.saoui.theme.accent");hex(c,"#38D9E8");c.clickScreenButton("gui.done");
            c.runOnClient(client->{var disk=new ConfigStore(FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();require(disk.theme.background==0x183044 && disk.theme.accent==0x38D9E8,"Theme did not survive disk reload");});
            open(c);hex(c,"#GGGGGG");
            require(!c.computeOnClient(client->SettingsNavigation.widget(client.gui.screen(),"gui.done").active),"Invalid hex was saveable");
            c.runOnClient(client->{var screen=client.gui.screen();screen.resize(screen.width,screen.height);});
            require(c.computeOnClient(client->edit(client.gui.screen()).getValue()).equals("#GGGGGG"),"Resize lost editing text");c.clickScreenButton("gui.cancel");
            open(c);c.runOnClient(client->{var screen=(SaoSettingsScreen)client.gui.screen();var slider=SettingsNavigation.widgets(screen).stream().filter(AbstractSliderButton.class::isInstance).filter(w->!(w instanceof SaoSlider)).map(AbstractSliderButton.class::cast).findFirst().orElseThrow();screen.reveal(slider);});c.waitTick();
            var point=c.computeOnClient(client->{var screen=client.gui.screen();var slider=SettingsNavigation.widgets(screen).stream().filter(AbstractSliderButton.class::isInstance).filter(w->!(w instanceof SaoSlider)).map(AbstractSliderButton.class::cast).findFirst().orElseThrow();var win=client.getWindow();return new double[]{(slider.getX()+slider.getWidth()*.8)*win.getScreenWidth()/screen.width,(slider.getY()+10.0)*win.getScreenHeight()/screen.height};});
            c.getInput().setCursorPos(point[0],point[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTick();
            int sliderColor=c.computeOnClient(client->UiTheme.parse(edit(client.gui.screen()).getValue()));require((sliderColor>>16&255)>150 && (sliderColor&0xFFFF)==0x3044,"RGB slider did not update HEX independently");c.clickScreenButton("gui.cancel");
            open(c);capture(c,"sao-theme-editor");SettingsNavigation.click(c,"settings.saoui.theme.reset");require(c.computeOnClient(client->edit(client.gui.screen()).getValue()).equals("#E3E8E3"),"Reset did not restore defaults");c.clickScreenButton("gui.cancel");
            c.runOnClient(client->{SaoUiClient.config().homeModule="inventory";SaoUiClient.config().parallaxStrength=0;});
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());
            capture(c,"sao-theme-menu-dark-cyan");c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
            world.getConnection().waitForServerboundPackets(); // Let the K inventory close reach the server before a server task opens another menu.
            c.runOnClient(client->SaoUiClient.config().replaceAllContainers=true);
            world.getServer().runOnServer(server->server.getPlayerList().getPlayers().getFirst().openMenu(new SimpleMenuProvider((id,inv,p)->{
                var storage=new SimpleContainer(27);storage.setItem(0,new ItemStack(Items.DIAMOND,12));return ChestMenu.threeRows(id,inv,storage);
            },Component.literal("Custom colors"))));
            c.waitForScreen(ContainerScreen.class);c.waitFor(client->BlockFloatingUi.ready(client.gui.screen()));c.waitTicks(2);
            c.waitFor(client->client.player.containerMenu.getSlot(0).getItem().getCount()==12);
            BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);BlockUiGameTest.clickSlot(c,27,InputConstants.MOUSE_BUTTON_LEFT);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->require(server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.DIAMOND)==12,"Themed container item transfer failed: menu="+server.getPlayerList().getPlayers().getFirst().containerMenu.getClass().getSimpleName()+", inventory="+server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.DIAMOND)+", cursor="+server.getPlayerList().getPlayers().getFirst().containerMenu.getCarried()));
            capture(c,"sao-theme-container-dark-cyan");close(c);
            c.getInput().pressKey(InputConstants.KEY_E);c.waitForScreen(InventoryScreen.class);c.waitFor(client->BlockFloatingUi.ready(client.gui.screen()));
            capture(c,"sao-theme-universal-dark-cyan");close(c);
            c.runOnClient(client->{SaoUiClient.config().theme.background=0xF9E8F4;SaoUiClient.config().theme.accent=0xA5356B;});
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());
            capture(c,"sao-theme-menu-light-rose");c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
            SaoUiClient.LOGGER.info("SAO theme passed: direct category save/cancel, HEX validation/resize, RGB mouse input, reset, persistence, dark/light menu and container rendering, native item synchronization");
        }finally{c.runOnClient(client->{try{SaoUiClient.saveConfig(original);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
    }
    private static EditBox edit(net.minecraft.client.gui.screens.Screen s){return SettingsNavigation.widgets(s).stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).findFirst().orElseThrow();}
    private static void hex(ClientGameTestContext c,String value){SettingsNavigation.expose(c,"settings.saoui.theme.hex");c.runOnClient(client->edit(client.gui.screen()).setValue(value));c.waitTick();}
    private static void open(ClientGameTestContext c){c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));SettingsNavigation.click(c,"settings.saoui.category.interface");SettingsNavigation.expose(c,"settings.saoui.theme.hex");}
    private static void close(ClientGameTestContext c){c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.waitForScreen(null);}
    private static void capture(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.waitTicks(2);c.takeScreenshot(name);}
    private static void require(boolean value,String message){if(!value)throw new AssertionError(message);}
}
