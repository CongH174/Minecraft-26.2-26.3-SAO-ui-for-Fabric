package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;

/** End-to-end container crafting and optional third-party hotkeys, with server conservation assertions. */
public final class EnhancementsGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        try(var world=c.worldBuilder().create()){
            world.getConnection().waitForChunksRender();c.waitForScreen(null);
            c.runOnClient(client->{client.options.pauseOnLostFocus=false;SaoUiClient.config().containerCraftingVisible=true;SaoUiClient.config().parallaxStrength=0;SaoUiClient.config().homeModule="inventory";});
            BlockPos pos=c.computeOnClient(client->client.player.blockPosition().offset(0,0,2));
            BlockUiGameTest.place(c,world,pos,Blocks.CHEST);
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();var chest=(Container)p.level().getBlockEntity(pos);chest.setItem(0,new ItemStack(Items.OAK_PLANKS,16));chest.setItem(1,new ItemStack(Items.STONE,3));});
            BlockUiGameTest.open(c,pos);
            c.waitFor(client->ContainerCraftingState.get(client.player.containerMenu)!=null&&BlockFloatingUi.ready(client.gui.screen()));
            int base=c.computeOnClient(client->ContainerCraftingState.get(client.player.containerMenu).base);
            require(base==63,"Original chest slot IDs changed");
            world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(ContainerCraftingState.get(p.containerMenu).base==63&&p.containerMenu.slots.size()==68,"Server did not negotiate exactly five real slots");});
            BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);
            for(int id=1;id<=4;id++)BlockUiGameTest.clickSlot(c,base+id,InputConstants.MOUSE_BUTTON_RIGHT);
            BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);
            c.waitFor(client->client.player.containerMenu.getSlot(base).getItem().is(Items.CRAFTING_TABLE));
            capture(c,"sao-container-crafting-table");
            BlockUiGameTest.clickSlot(c,base,InputConstants.MOUSE_BUTTON_LEFT);BlockUiGameTest.clickSlot(c,2,InputConstants.MOUSE_BUTTON_LEFT);
            world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();var chest=(Container)p.level().getBlockEntity(pos);require(chest.getItem(0).getCount()==12&&chest.getItem(2).is(Items.CRAFTING_TABLE)&&chest.getItem(2).getCount()==1,"Container to grid to container craft lost/duplicated items");});
            BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);
            for(int id:new int[]{1,3})for(int n=0;n<3;n++)BlockUiGameTest.clickSlot(c,base+id,InputConstants.MOUSE_BUTTON_RIGHT);
            BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);
            c.waitFor(client->client.player.containerMenu.getSlot(base).getItem().is(Items.STICK));
            BlockUiGameTest.clickSlot(c,base,InputConstants.MOUSE_BUTTON_LEFT,InputConstants.MOD_SHIFT);
            world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.STICK)==12,"Shift crafting did not consume three batches");for(int id=1;id<=4;id++)require(!p.containerMenu.getSlot(base+id).hasItem(),"Shift crafting left inputs");});
            // Existing chest Shift behavior must not put items in appended crafting slots.
            BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT,InputConstants.MOD_SHIFT);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.OAK_PLANKS)==6,"Native chest Shift transfer changed");for(int id=1;id<=4;id++)require(!p.containerMenu.getSlot(base+id).hasItem(),"Native Shift transferred into crafting grid");});
            // Reject result deposits; then leave one material and a cursor stack across close.
            BlockUiGameTest.clickSlot(c,1,InputConstants.MOUSE_BUTTON_LEFT);BlockUiGameTest.clickSlot(c,base,InputConstants.MOUSE_BUTTON_LEFT);
            require(c.computeOnClient(client->client.player.containerMenu.getCarried().getCount())==3,"Result accepted a material deposit");BlockUiGameTest.clickSlot(c,1,InputConstants.MOUSE_BUTTON_LEFT);
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();var state=ContainerCraftingState.get(p.containerMenu);var stack=p.getInventory().removeItem(p.getInventory().findSlotMatchingItem(new ItemStack(Items.OAK_PLANKS)),1);state.input.setItem(0,stack);p.containerMenu.broadcastChanges();});
            c.waitFor(client->client.player.containerMenu.getSlot(base+1).hasItem());
            c.runOnClient(client->{var s=client.gui.screen();s.resize(s.width,s.height);});c.waitTicks(3);
            require(c.computeOnClient(client->client.player.containerMenu.getSlot(base+1).getItem().getCount())==1,"Resize lost container grid");
            c.runOnClient(client->SaoUiClient.config().parallaxStrength=2);c.getInput().setCursorPos(854,480);c.waitTicks(8);
            c.runOnClient(client->{var screen=client.gui.screen();var b=FlatContainerUi.bounds(screen);var f=BlockFloatingUi.frame(screen);require(f.screenX(b.x())>=0&&f.screenX(b.x()+b.width())<=screen.width&&f.screenY(b.y())>=0&&f.screenY(b.y()+b.height())<=screen.height,"Craft panel clipped viewport");});
            capture(c,"sao-container-crafting-parallax");
            c.runOnClient(client->SaoUiClient.config().parallaxStrength=0);c.waitTicks(15);
            BlockUiGameTest.clickSlot(c,1,InputConstants.MOUSE_BUTTON_LEFT);require(c.computeOnClient(client->client.player.containerMenu.getCarried().getCount())==3,"Close test did not pick up stone cursor");c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.OAK_PLANKS)==6&&p.getInventory().countItem(Items.STONE)==3&&p.getInventory().countItem(Items.STICK)==12,"Closing lost materials or cursor");require(p.getInventory().countItem(Items.OAK_BUTTON)==0,"Closing incorrectly granted preview result");});
            c.runOnClient(client->SaoUiClient.config().containerCraftingVisible=false);BlockUiGameTest.open(c,pos);c.waitFor(client->BlockFloatingUi.ready(client.gui.screen()));c.waitTicks(3);
            require(c.computeOnClient(client->client.player.containerMenu.slots.size())==63,"Disabled module still appended slots");BlockUiGameTest.close(c);
            // Remainders use vanilla ResultSlot (four honey bottles -> honey block + four bottles).
            c.runOnClient(client->SaoUiClient.config().containerCraftingVisible=true);BlockUiGameTest.open(c,pos);c.waitFor(client->ContainerCraftingState.get(client.player.containerMenu)!=null&&BlockFloatingUi.ready(client.gui.screen()));
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();var state=ContainerCraftingState.get(p.containerMenu);for(int i=0;i<4;i++)state.input.setItem(i,new ItemStack(Items.HONEY_BOTTLE));p.containerMenu.broadcastChanges();require(state.output.getItem(0).is(Items.HONEY_BLOCK),"Server recipe manager did not produce honey block");});
            c.waitFor(client->client.player.containerMenu.getSlot(base).getItem().is(Items.HONEY_BLOCK));BlockUiGameTest.clickSlot(c,base,InputConstants.MOUSE_BUTTON_LEFT);BlockUiGameTest.clickSlot(c,3,InputConstants.MOUSE_BUTTON_LEFT);
            c.waitFor(client->client.player.containerMenu.getSlot(base+1).getItem().is(Items.GLASS_BOTTLE));
            for(int id=1;id<=4;id++)BlockUiGameTest.clickSlot(c,base+id,InputConstants.MOUSE_BUTTON_LEFT,InputConstants.MOD_SHIFT);
            BlockUiGameTest.close(c);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.GLASS_BOTTLE)==4&&((Container)p.level().getBlockEntity(pos)).getItem(3).is(Items.HONEY_BLOCK),"Vanilla crafting remainder handling lost bottles or output");});
            // Catalog includes armor, utility items, books and previously enchanted tools.
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();p.getInventory().setItem(0,new ItemStack(Items.DIAMOND_HELMET));p.getInventory().setItem(1,new ItemStack(Items.FISHING_ROD));p.getInventory().setItem(2,new ItemStack(Items.FLINT_AND_STEEL));p.getInventory().setItem(3,new ItemStack(Items.SHEARS));p.getInventory().setItem(4,new ItemStack(Items.BOOK));var sword=new ItemStack(Items.DIAMOND_SWORD);var registry=server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);sword.enchant(registry.getOrThrow(Enchantments.SHARPNESS),5);sword.enchant(registry.getOrThrow(Enchantments.UNBREAKING),3);p.getInventory().setItem(5,sword);p.getInventory().setItem(6,new ItemStack(Items.COBBLESTONE));p.inventoryMenu.broadcastChanges();});
            c.waitFor(client->client.player.getInventory().getItem(5).isEnchanted());
            c.runOnClient(client->{require(CombatItems.scan(client.player).size()==6,"Enchantable catalog included blocks or excluded utility/armor/books");SaoUiClient.config().homeModule="equipment";SaoUiClient.config().parallaxStrength=0;});
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());
            c.waitTick();capture(c,"sao-enchantment-armor-preview");
            c.runOnClient(client->{var w=client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(s->s.visible).toList().get(4);var e=new net.minecraft.client.input.MouseButtonEvent(w.getX()+w.getWidth()/2.0,w.getY()+w.getHeight()/2.0,new net.minecraft.client.input.MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0));client.gui.screen().mouseClicked(e,false);client.gui.screen().mouseReleased(e);});c.waitTicks(2);
            c.runOnClient(client->{var s=client.gui.screen();require(s.mouseScrolled(s.width-40,s.height/2.0,0,-3),"Enchantment book panel did not accept scroll");});c.waitTick();capture(c,"sao-enchantment-book-scroll");
            c.runOnClient(client->{var w=client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(s->s.visible).toList().get(5);var e=new net.minecraft.client.input.MouseButtonEvent(w.getX()+w.getWidth()/2.0,w.getY()+w.getHeight()/2.0,new net.minecraft.client.input.MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0));client.gui.screen().mouseClicked(e,false);client.gui.screen().mouseReleased(e);});c.waitTick();capture(c,"sao-enchantment-sharpness-v");
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
            if(FabricLoader.getInstance().isModLoaded("inventoryprofilesnext")){
                world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();p.getInventory().setItem(9,new ItemStack(Items.STONE,3));p.getInventory().setItem(11,new ItemStack(Items.OAK_PLANKS,7));p.getInventory().setItem(15,new ItemStack(Items.STONE,5));p.inventoryMenu.broadcastChanges();});
                c.waitFor(client->client.player.getInventory().getItem(15).getCount()==5);c.runOnClient(client->{SaoUiClient.config().homeModule="inventory";SaoUiClient.config().ipnIntegration=true;});
                c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());c.waitTicks(3);
                c.runOnClient(client->{try{var type=Class.forName("org.anti_ad.mc.common.vanilla.Vanilla");var instance=type.getField("INSTANCE").get(null);require(type.getMethod("screen").invoke(instance) instanceof SaoMenuScreen,"IPN bridge leaked beyond hotkey handling");require(((SaoMenuScreen)client.gui.screen()).ipnScreen() instanceof AbstractContainerScreen<?>,"IPN input bridge not available");}catch(ReflectiveOperationException e){throw new AssertionError(e);}});
                c.getInput().pressKey(InputConstants.KEY_R);c.waitFor(client->{int slots=0,total=0;for(int i=9;i<36;i++){var s=client.player.getInventory().getItem(i);if(s.is(Items.STONE)){slots++;total+=s.getCount();}}return slots==1&&total==8;});world.getConnection().waitForServerboundPackets();
                world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(p.getInventory().countItem(Items.STONE)==8&&p.getInventory().countItem(Items.OAK_PLANKS)==7,"IPN sorting lost or duplicated items");});capture(c,"sao-ipn-r-sorted");c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
                // Respect the integration switch, then test a rebound IPN key inside a container with inputs present.
                world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();p.getInventory().setItem(9,new ItemStack(Items.STONE,3));p.getInventory().setItem(15,new ItemStack(Items.STONE,5));p.inventoryMenu.broadcastChanges();});
                c.waitFor(client->client.player.getInventory().getItem(15).getCount()==5);c.runOnClient(client->SaoUiClient.config().ipnIntegration=false);c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());c.getInput().pressKey(InputConstants.KEY_R);c.waitTicks(4);
                require(c.computeOnClient(client->client.player.getInventory().getItem(15).getCount())==5,"Disabled IPN bridge still sorted the SAO menu");c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
                c.runOnClient(client->{SaoUiClient.config().ipnIntegration=true;SaoUiClient.config().containerCraftingVisible=true;});BlockUiGameTest.open(c,pos);c.waitFor(client->ContainerCraftingState.get(client.player.containerMenu)!=null&&BlockFloatingUi.ready(client.gui.screen()));
                world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();ContainerCraftingState.get(p.containerMenu).input.setItem(0,new ItemStack(Items.OAK_PLANKS));p.containerMenu.broadcastChanges();});c.waitFor(client->client.player.containerMenu.getSlot(base+1).hasItem());
                Object binding=c.computeOnClient(client->{try{var type=Class.forName("org.anti_ad.mc.ipnext.config.Hotkeys");var hotkey=type.getMethod("getSORT_INVENTORY").invoke(type.getField("INSTANCE").get(null));return hotkey.getClass().getMethod("getMainKeybind").invoke(hotkey);}catch(ReflectiveOperationException e){throw new AssertionError(e);}});
                Object oldKeys=c.computeOnClient(client->{try{return binding.getClass().getMethod("getKeyCodes").invoke(binding);}catch(ReflectiveOperationException e){throw new AssertionError(e);}});
                try{
                    c.runOnClient(client->{try{var settings=binding.getClass().getMethod("getSettings").invoke(binding);var rebound=binding.getClass().getConstructor(String.class,settings.getClass()).newInstance("P",settings);var keys=binding.getClass().getMethod("getKeyCodes").invoke(rebound);binding.getClass().getMethod("setKeyCodes",java.util.List.class).invoke(binding,keys);}catch(ReflectiveOperationException e){throw new AssertionError(e);}});
                    // Hover the player backpack, so IPN's own sort-at-cursor policy selects it.
                    double[] target=c.computeOnClient(client->{var s=client.gui.screen();var a=(io.github.saoui.mixin.ContainerScreenAccessor)s;var f=BlockFloatingUi.frame(s);var slot=client.player.containerMenu.getSlot(27);var w=client.getWindow();return new double[]{f.screenX(a.saoui$left()+slot.x+8)*w.getScreenWidth()/s.width,f.screenY(a.saoui$top()+slot.y+8)*w.getScreenHeight()/s.height};});c.getInput().setCursorPos(target[0],target[1]);c.waitTicks(3);
                    c.getInput().pressKey(InputConstants.KEY_R);c.waitTicks(4);require(c.computeOnClient(client->client.player.getInventory().getItem(15).getCount())==5,"Hardcoded R bypassed IPN's rebound key");
                    c.getInput().pressKey(InputConstants.KEY_P);c.waitFor(client->{int count=0,total=0;for(int i=9;i<36;i++){var stack=client.player.getInventory().getItem(i);if(stack.is(Items.STONE)){count++;total+=stack.getCount();}}return count==1&&total==8;});world.getConnection().waitForServerboundPackets();
                    world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();require(ContainerCraftingState.get(p.containerMenu).input.getItem(0).getCount()==1&&ContainerCraftingState.get(p.containerMenu).output.getItem(0).is(Items.OAK_BUTTON),"IPN sorting moved ingredients or result preview");});capture(c,"sao-ipn-container-rebound");
                }finally{c.runOnClient(client->{try{binding.getClass().getMethod("setKeyCodes",java.util.List.class).invoke(binding,oldKeys);}catch(ReflectiveOperationException e){throw new AssertionError(e);}});}
                BlockUiGameTest.close(c);
                SaoUiClient.LOGGER.info("SAO IPN compatibility passed: user-provided IPN/libIPN/Kotlin, native R sorting and server conservation");
            }
            SaoUiClient.LOGGER.info("SAO enhancements passed: negotiated container 2x2, chest-to-grid-to-chest, Shift batches, native Shift ranges, result restrictions, resize, parallax, close conservation, feature disable, enchantable catalog and enchantment details");
        }finally{c.runOnClient(client->{try{SaoUiClient.saveConfig(original);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
    }
    private static void capture(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.waitTick();c.takeScreenshot(name);}
    private static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
}
