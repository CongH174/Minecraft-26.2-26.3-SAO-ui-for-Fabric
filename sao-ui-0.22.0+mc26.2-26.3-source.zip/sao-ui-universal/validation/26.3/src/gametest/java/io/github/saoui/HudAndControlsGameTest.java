package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.saoui.mixin.RecipeBookAccessor;
import io.github.saoui.mixin.RecipeScreenAccessor;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.gamerules.GameRules;

public final class HudAndControlsGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c) {
        var original = c.computeOnClient(client -> SaoUiClient.config().copy());
        String oldKey = c.computeOnClient(client -> SaoUiClient.menuKey.saveString());
        save(c, new SaoConfig());
        try (var world = c.worldBuilder().create()) {
            world.getConnection().waitForChunksRender(); c.waitForScreen(null);
            world.getServer().runOnServer(server -> {
                var p = server.getPlayerList().getPlayers().getFirst(); p.setGameMode(GameType.SURVIVAL);
                p.level().getGameRules().set(GameRules.NATURAL_HEALTH_REGENERATION, false, server);
                p.setHealth(14); p.getFoodData().setFoodLevel(18); p.getFoodData().setSaturation(4.5f);
                p.setExperienceLevels(12); p.setExperiencePoints(9);
                p.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
                p.inventoryMenu.broadcastChanges();
            });
            c.waitFor(client -> client.player.getFoodData().getFoodLevel() == 18 && client.player.experienceLevel == 12 && client.player.getArmorValue() == 8);
            c.runOnClient(client -> {
                var data = SaoHud.sample(client);
                check(data.food() == 18 && data.armor() == 8 && data.level() == 12 && data.experience() > 0, "HUD lost native stats");
                check(data.hasSaturation() == AppleSkinBridge.AVAILABLE, "Optional saturation detection failed");
            });
            if (AppleSkinBridge.AVAILABLE) {
                c.waitFor(client -> Math.abs(SaoHud.sample(client).saturation() - 4.5f) < .01f);
                shot(c, "sao-hud-saturation-low");
                world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().getFoodData().setSaturation(12));
                c.waitFor(client -> Math.abs(SaoHud.sample(client).saturationRatio() - .6f) < .001f);
                shot(c, "sao-hud-saturation-high");
                SaoUiClient.LOGGER.info("SAO AppleSkin integration passed: real server saturation 4.5 -> 12 reached client HUD");
            } else {
                check(c.computeOnClient(client -> !SaoHud.sample(client).hasSaturation()), "Missing AppleSkin invented saturation");
                shot(c, "sao-hud-no-appleskin");
            }
            settings(c);
            var cfg = c.computeOnClient(client -> SaoUiClient.config().copy());
            cfg.hud.health = cfg.hud.hunger = cfg.hud.experience = cfg.hud.armor = true;
            cfg.hud.hideVanillaHealth = cfg.hud.hideVanillaHunger = cfg.hud.hideVanillaExperience = cfg.hud.hideVanillaArmor = cfg.hud.hideVanillaCrosshair = true; save(c, cfg);
            c.runOnClient(client -> check(VanillaHudVisibility.visible(VanillaHudElements.HOTBAR)
                    && !VanillaHudVisibility.visible(VanillaHudElements.HEALTH_BAR), "Hotbar protection or individual hide was ignored"));
            shot(c, "sao-hud-only");
            effects(c, world);
            cfg.hud.experience = false; save(c, cfg); shot(c, "sao-hud-level-fallback");
            cfg.hud.experience = true; save(c, cfg);
            cfg.hud.health = false; save(c, cfg); shot(c, "sao-hud-without-health");
            cfg.hud.hunger = cfg.hud.experience = cfg.hud.armor = false; save(c, cfg); shot(c, "sao-hud-all-off");
            cfg.hudEnabled = false; save(c, cfg);
            c.runOnClient(client -> check(VanillaHudVisibility.visible(VanillaHudElements.HOTBAR) && !VanillaHudVisibility.visible(VanillaHudElements.HEALTH_BAR), "Hotbar protection depends on SAO master switch"));
            individualVanilla(c);
            save(c, new SaoConfig());
            closeKeys(c, world);
            recipeLayouts(c, world);
            groupedContainers(c, world);
            SaoUiClient.LOGGER.info("SAO HUD and controls passed: stats, independent bars, nested drafts, native HUD hide, optional AppleSkin, remapped key close, cursor conservation, recipe tabs in four layouts/resize/update; unified gradients, potions, grouped containers and protected hotbar");
        } finally {
            save(c, original);
            c.runOnClient(client -> { SaoUiClient.menuKey.setKey(InputConstants.getKey(oldKey)); KeyMapping.resetMapping(); });
        }
    }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static void save(ClientGameTestContext c, SaoConfig config) {
        c.runOnClient(client -> { try { SaoUiClient.saveConfig(config); } catch (java.io.IOException e) { throw new java.io.UncheckedIOException(e); } });
    }
    private static void control(ClientGameTestContext c,String key) { SettingsNavigation.click(c,key); }
    private static void settings(ClientGameTestContext c) {
        c.runOnClient(client -> client.gui.setScreen(new SaoSettingsScreen(null)));
        for (var key : new String[]{"health", "hunger", "experience", "armor", "saturation", "hide_vanilla_health", "hide_vanilla_hunger", "hide_vanilla_experience", "hide_vanilla_armor", "hide_vanilla_crosshair"}) control(c, "settings.saoui.bar." + key);
        shot(c, "sao-hud-settings"); control(c, "gui.cancel"); c.waitForScreen(null);
        c.runOnClient(client -> check(SaoUiClient.config().hud.anyBar() && !SaoUiClient.config().hud.hideVanillaHealth, "Cancel leaked HUD preferences"));
        c.runOnClient(client -> client.gui.setScreen(new SaoSettingsScreen(null)));
        control(c, "settings.saoui.bar.health"); control(c, "settings.saoui.bar.hide_vanilla_health");control(c,"settings.saoui.ipn");control(c,"gui.cancel");c.waitForScreen(null);
        c.runOnClient(client -> check(SaoUiClient.config().hud.health && !SaoUiClient.config().hud.hideVanillaHealth, "Cross-category Cancel leaked preferences"));
        c.runOnClient(client -> client.gui.setScreen(new SaoSettingsScreen(null)));
        control(c, "settings.saoui.bar.health"); control(c, "settings.saoui.bar.hide_vanilla_health");control(c,"gui.done");c.waitForScreen(null);
        c.runOnClient(client -> {var disk = new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();
            check(!disk.hud.health && disk.hud.hunger && disk.hud.experience && disk.hud.armor && disk.hud.hideVanillaHealth && !disk.hud.hideVanillaExperience,"HUD settings did not persist independently");});
    }
    private static void effects(ClientGameTestContext c, TestSingleplayerContext world) {
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1)));
        c.waitFor(client -> SaoHud.sample(client).absorption() == 8); shot(c, "sao-hud-absorption");
        float hp = c.computeOnClient(client -> SaoHud.sample(client).health());
        world.getServer().runOnServer(server -> {
            var p = server.getPlayerList().getPlayers().getFirst();
            p.hurtServer(p.level(), p.damageSources().generic(), 3);
        });
        c.waitFor(client -> SaoHud.sample(client).absorption() < 8);
        c.runOnClient(client -> check(SaoHud.sample(client).health() == hp && SaoHud.sample(client).absorption() > 0,
                "Damage did not consume absorption before health")); shot(c, "sao-hud-absorption-damaged");
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().addEffect(new MobEffectInstance(MobEffects.POISON, 1200)));
        c.waitFor(client -> SaoHud.sample(client).condition() == HudValues.Condition.POISONED); shot(c, "sao-hud-absorption-poison");
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().addEffect(new MobEffectInstance(MobEffects.WITHER, 1200)));
        c.waitFor(client -> SaoHud.sample(client).condition() == HudValues.Condition.WITHERED);
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().removeEffect(MobEffects.ABSORPTION));
        c.waitFor(client -> SaoHud.sample(client).absorption() == 0); shot(c, "sao-hud-wither");
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().removeEffect(MobEffects.WITHER));
        c.waitFor(client -> SaoHud.sample(client).condition() == HudValues.Condition.POISONED); shot(c, "sao-hud-poison");
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().removeAllEffects());
        c.waitFor(client -> SaoHud.sample(client).condition() == HudValues.Condition.NORMAL);
        SaoUiClient.LOGGER.info("SAO potion HUD passed: absorption priority under real damage, gold depletion, poison green, wither black, precedence and recovery");
    }
    private static void individualVanilla(ClientGameTestContext c) {
        var elements = new net.minecraft.resources.Identifier[]{VanillaHudElements.HEALTH_BAR, VanillaHudElements.FOOD_BAR,
                VanillaHudElements.EXPERIENCE_LEVEL, VanillaHudElements.ARMOR_BAR, VanillaHudElements.CROSSHAIR};
        for (int i = 0; i < elements.length; i++) {
            var config = new SaoConfig(); config.hudEnabled = false;
            switch (i) {
                case 0 -> config.hud.hideVanillaHealth = true;
                case 1 -> config.hud.hideVanillaHunger = true;
                case 2 -> config.hud.hideVanillaExperience = true;
                case 3 -> config.hud.hideVanillaArmor = true;
                case 4 -> config.hud.hideVanillaCrosshair = true;
            }
            save(c, config); int hidden = i;
            c.runOnClient(client -> {
                for (int j = 0; j < elements.length; j++) check(VanillaHudVisibility.visible(elements[j]) == (j != hidden), "Vanilla controls are coupled");
                for (var id : new net.minecraft.resources.Identifier[]{VanillaHudElements.HOTBAR, VanillaHudElements.CHAT,
                        VanillaHudElements.MOB_EFFECTS, VanillaHudElements.AIR_BAR, VanillaHudElements.BOSS_BAR, VanillaHudElements.INFO_BAR})
                    check(VanillaHudVisibility.visible(id), "Unrelated native HUD was hidden: " + id);
            });
            shot(c, "sao-vanilla-hidden-" + i);
        }
        SaoUiClient.LOGGER.info("SAO native HUD controls passed: five independent toggles, hotbar always retained, contextual info unaffected");
    }
    private static void groupedContainers(ClientGameTestContext c, TestSingleplayerContext world) {
        var config = new SaoConfig(); var anvil = new ContainerUiProfile(); anvil.enabled = false;
        var shulker = new ContainerUiProfile(); shulker.backpackSide = ContainerUiProfile.Side.LEFT;
        config.containers.blocks.put("minecraft:anvil", anvil); config.containers.blocks.put("minecraft:shulker_box", shulker); save(c, config);
        BlockPos pos = c.computeOnClient(client -> client.player.blockPosition().offset(0, 0, 2));
        for (var block : new net.minecraft.world.level.block.Block[]{Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL}) {
            BlockUiGameTest.place(c, world, pos, block); c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_RIGHT); c.waitForScreen(AbstractContainerScreen.class);
            check(c.computeOnClient(client -> !BlockFloatingUi.active(client.gui.screen())), "Anvil variant ignored grouped disabled rule"); closed(c, InputConstants.KEY_K);
        }
        for (var block : java.util.stream.Stream.of("shulker_box", "white_shulker_box", "red_shulker_box", "blue_shulker_box", "black_shulker_box").map(id -> net.minecraft.core.registries.BuiltInRegistries.BLOCK.getValue(net.minecraft.resources.Identifier.withDefaultNamespace(id))).toList()) {
            BlockUiGameTest.place(c, world, pos, block); BlockUiGameTest.open(c, pos); c.waitFor(client -> BlockFloatingUi.ready(client.gui.screen()));
            check(c.computeOnClient(client -> BlockFloatingUi.profile(client.gui.screen()).backpackSide == ContainerUiProfile.Side.LEFT), "Shulker color ignored grouped layout"); closed(c, InputConstants.KEY_K);
        }
        c.runOnClient(client -> client.gui.setScreen(new SaoContainerSettingsScreen(null)));
        control(c, "settings.saoui.containers.scope.block");
        c.runOnClient(client -> client.gui.screen().children().stream().filter(net.minecraft.client.gui.components.EditBox.class::isInstance)
                .map(net.minecraft.client.gui.components.EditBox.class::cast).findFirst().orElseThrow().setValue("shulker"));
        shot(c, "sao-container-groups"); control(c, "settings.saoui.containers.enabled"); control(c, "gui.done"); c.waitForScreen(null);
        c.runOnClient(client -> check(!SaoUiClient.config().containers.forBlock("minecraft:white_shulker_box").enabled
                && !SaoUiClient.config().containers.forBlock("minecraft:red_shulker_box").enabled, "Grouped settings did not apply to every color"));
        SaoUiClient.LOGGER.info("SAO grouped containers passed: all anvil damage states, five shulker variants, one grouped settings entry and save across colors");
    }
    private static void closed(ClientGameTestContext c, int key) {
        c.getInput().pressKey(key); c.waitForScreen(null); c.waitTicks(3);
        check(c.computeOnClient(client -> client.gui.screen() == null), "Container close reopened SAO menu");
    }
    private static void closeKeys(ClientGameTestContext c, TestSingleplayerContext world) {
        BlockPos pos = c.computeOnClient(client -> client.player.blockPosition().offset(0, 0, 2));
        BlockUiGameTest.place(c, world, pos, Blocks.CHEST);
        BlockUiGameTest.open(c, pos); closed(c, InputConstants.KEY_K); // Also allowed during entrance.
        world.getServer().runOnServer(server -> ((Container)server.getPlayerList().getPlayers().getFirst().level().getBlockEntity(pos)).setItem(0, new ItemStack(Items.DIAMOND, 12)));
        BlockUiGameTest.open(c, pos); c.waitFor(client -> BlockFloatingUi.ready(client.gui.screen()));
        BlockUiGameTest.clickSlot(c, 0, InputConstants.MOUSE_BUTTON_LEFT); closed(c, InputConstants.KEY_K);
        world.getConnection().waitForServerboundPackets();
        world.getServer().runOnServer(server -> {
            var p = server.getPlayerList().getPlayers().getFirst();
            check(p.containerMenu == p.inventoryMenu && p.inventoryMenu.getCarried().isEmpty()
                    && p.getInventory().countItem(Items.DIAMOND) == 12, "K close lost/duplicated carried items or skipped native cleanup");
        });
        var cfg = new SaoConfig(); cfg.containers.defaults.enabled = false; save(c, cfg);
        c.getInput().lookAt(pos); c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_RIGHT); c.waitForScreen(AbstractContainerScreen.class);
        check(c.computeOnClient(client -> !BlockFloatingUi.active(client.gui.screen())), "Fallback case was still skinned");
        closed(c, InputConstants.KEY_K);
        c.getInput().pressKey(InputConstants.KEY_E); c.waitForScreen(InventoryScreen.class); closed(c, InputConstants.KEY_K);
        c.runOnClient(client -> { SaoUiClient.menuKey.setKey(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_L)); KeyMapping.resetMapping(); });
        c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_RIGHT); c.waitForScreen(AbstractContainerScreen.class); closed(c, InputConstants.KEY_L);
        c.runOnClient(client -> { SaoUiClient.menuKey.setKey(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_K)); KeyMapping.resetMapping(); });
        save(c, new SaoConfig());
    }
    private static void recipeLayouts(ClientGameTestContext c, TestSingleplayerContext world) {
        BlockPos pos = c.computeOnClient(client -> client.player.blockPosition().offset(0, 0, 2));
        BlockUiGameTest.place(c, world, pos, Blocks.CRAFTING_TABLE);
        world.getServer().runOnServer(server -> {
            var p = server.getPlayerList().getPlayers().getFirst(); p.awardRecipes(server.getRecipeManager().getRecipes());
        });
        for (var side : ContainerUiProfile.Side.values()) {
            var cfg = new SaoConfig(); cfg.containers.defaults.backpackSide = side; save(c, cfg);
            BlockUiGameTest.open(c, pos); c.waitFor(client -> BlockFloatingUi.ready(client.gui.screen()));
            c.runOnClient(client -> { var book = ((RecipeScreenAccessor)client.gui.screen()).saoui$book(); if (!book.isVisible()) book.toggleVisibility(); });
            c.waitTicks(2); tabs(c);
            c.runOnClient(client -> ((RecipeScreenAccessor)client.gui.screen()).saoui$book().recipesUpdated()); c.waitTick(); tabs(c);
            c.runOnClient(client -> { var screen = client.gui.screen(); screen.resize(screen.width, screen.height); });
            c.waitFor(client -> BlockFloatingUi.ready(client.gui.screen())); c.waitTicks(2); tabs(c);
            var target = c.computeOnClient(client -> {
                var book = (RecipeBookAccessor)((RecipeScreenAccessor)client.gui.screen()).saoui$book();
                return book.saoui$tabs().stream().filter(tab -> tab.visible && tab != book.saoui$selected()).findFirst().orElseThrow();
            });
            double[] raw = c.computeOnClient(client -> {
                var frame = BlockFloatingUi.frame(client.gui.screen()); var window = client.getWindow();
                return new double[]{frame.screenX(target.getX() + 12) * window.getScreenWidth() / client.gui.screen().width,
                        frame.screenY(target.getY() + 12) * window.getScreenHeight() / client.gui.screen().height};
            });
            c.getInput().setCursorPos(raw[0], raw[1]); c.waitTick(); c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT); c.waitTick();
            c.runOnClient(client -> check(((RecipeBookAccessor)((RecipeScreenAccessor)client.gui.screen()).saoui$book()).saoui$selected() == target,
                    "Relocated recipe category rejected the real pointer click"));
            shot(c, "sao-recipe-" + side.name().toLowerCase(java.util.Locale.ROOT)); closed(c, InputConstants.KEY_K);
        }
    }
    private static void tabs(ClientGameTestContext c) {
        c.runOnClient(client -> {
            var screen = client.gui.screen(); var book = (RecipeBookAccessor)((RecipeScreenAccessor)screen).saoui$book();
            int row = 0;
            for (var tab : book.saoui$tabs()) if (tab.visible) {
                check(tab.getX() == book.saoui$x() - 30 && tab.getY() == book.saoui$y() + 3 + row++ * 27,
                        "Recipe tabs drifted after layout/resize/update");
            }
            check(row >= 4, "Recipe layout checks did not exercise categories");
        });
    }
    private static void shot(ClientGameTestContext c, String name) {
        c.runOnClient(client -> { client.gui.toastManager().clear(); client.gui.hud.getChat().clearMessages(true); });
        c.waitTicks(2); c.takeScreenshot(name);
    }
}
