package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.saoui.mixin.ContainerScreenAccessor;
import io.github.saoui.mixin.RecipeScreenAccessor;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.Container;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;

public final class CustomizationGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c) {
        SaoConfig original = c.computeOnClient(client -> SaoUiClient.config().copy());
        save(c, config -> { config.resetModules(); config.resetHud(); config.containers = new ContainerUiRules(); });
        c.runOnClient(client -> client.options.pauseOnLostFocus = false);
        try (var world = c.worldBuilder().create()) {
            world.getClientLevel().waitForChunksRender(); c.waitForScreen(null);
            armor(c, world);
            rules(c, world);
            SaoUiClient.LOGGER.info("SAO customization passed: armor equip/unequip, invalid items, binding curse, close cleanup; four layouts, independent offsets, per-block and per-location overrides, native fallback, settings save/cancel/inherit/persistence");
        } finally { save(c, config -> copyRules(original, config)); }
    }
    private static void copyRules(SaoConfig source, SaoConfig target) {
        target.containers = source.containers.copy(); target.armorSlotsVisible = source.armorSlotsVisible;
        target.blockUiEnabled = source.blockUiEnabled; target.parallaxStrength = source.parallaxStrength;
        target.moduleOrder = new java.util.ArrayList<>(source.moduleOrder);
        target.hiddenModules = new java.util.ArrayList<>(source.hiddenModules); target.homeModule = source.homeModule;
    }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static void save(ClientGameTestContext c, Consumer<SaoConfig> edit) {
        c.runOnClient(client -> { var next = SaoUiClient.config().copy(); edit.accept(next);
            try { SaoUiClient.saveConfig(next); } catch (java.io.IOException e) { throw new java.io.UncheckedIOException(e); } });
    }
    private static void settled(ClientGameTestContext c) {
        c.waitFor(client -> client.gui.screen() instanceof SaoMenuScreen s && s.isAnimationSettled()); c.waitTicks(2);
    }
    private static void armor(ClientGameTestContext c, TestSingleplayerContext world) {
        world.getServer().runOnServer(server -> {
            var p = server.getPlayerList().getPlayers().getFirst(); p.setGameMode(GameType.SURVIVAL);
            p.getInventory().clearContent();
            p.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
            p.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
            p.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.DIAMOND_LEGGINGS));
            p.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.DIAMOND_BOOTS));
            p.getInventory().setItem(13, new ItemStack(Items.COBBLESTONE, 16)); p.inventoryMenu.broadcastChanges();
        });
        c.waitFor(client -> client.player.inventoryMenu.getSlot(5).hasItem());
        c.getInput().pressKey(InputConstants.KEY_K); c.waitForScreen(SaoMenuScreen.class); settled(c);
        c.runOnClient(client -> check(client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance)
                .map(FloatingItemSlot.class::cast).noneMatch(slot -> slot.menuSlot() >= 5 && slot.menuSlot() <= 8 && slot.visible),
                "Armor column leaked outside the inventory page"));
        control(c, "root.saoui.inventory"); settled(c);
        c.runOnClient(client -> {
            var slots = client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).toList();
            var offhand = slots.stream().filter(slot -> slot.menuSlot() == 45 && slot.visible).findFirst().orElseThrow();
            var armor = slots.stream().filter(slot -> slot.menuSlot() >= 5 && slot.menuSlot() <= 8 && slot.visible).toList();
            check(armor.size() == 4, "Inventory does not expose four armor slots");
            int previousY = Integer.MIN_VALUE;
            for (var slot : armor) {
                check(ItemStack.matches(slot.displayedStack(), client.player.inventoryMenu.getSlot(slot.menuSlot()).getItem()), "Armor view mapping mismatch");
                check(Math.abs(slot.getX() - offhand.getX()) <= 1 && slot.getY() + slot.getHeight() < offhand.getY()
                        && slot.getY() > previousY, "Armor slots are not ordered above the offhand"); previousY = slot.getY();
            }
        });
        menuSlot(c, 5, 0);
        check(c.computeOnClient(client -> client.player.inventoryMenu.getCarried().is(Items.DIAMOND_HELMET)), "Inventory armor pickup failed");
        menuSlot(c, 9, 0); menuSlot(c, 9, 0); menuSlot(c, 5, 0);
        for (int slot = 6; slot <= 8; slot++) {
            menuSlot(c, slot, 0); menuSlot(c, slot + 4, 0); menuSlot(c, slot + 4, 0); menuSlot(c, slot, 0);
        }
        // Inventory index 13 maps to native menu slot 13 in the main backpack.
        menuSlot(c, 13, 0); menuSlot(c, 5, 0);
        check(c.computeOnClient(client -> client.player.inventoryMenu.getCarried().is(Items.COBBLESTONE)
                && client.player.inventoryMenu.getSlot(5).getItem().is(Items.DIAMOND_HELMET)), "Armor accepted an invalid block");
        menuSlot(c, 13, 0);
        menuSlot(c, 6, InputConstants.MOD_SHIFT);
        c.waitFor(client -> !client.player.inventoryMenu.getSlot(6).hasItem());
        int chestSlot = c.computeOnClient(client -> client.player.inventoryMenu.slots.stream().filter(s -> s.index >= 9 && s.index <= 44 && s.getItem().is(Items.DIAMOND_CHESTPLATE)).findFirst().orElseThrow().index);
        menuSlot(c, chestSlot, 0); menuSlot(c, 6, 0);
        ServerPacketBarrier.await(c);
        world.getServer().runOnServer(server -> {
            var p = server.getPlayerList().getPlayers().getFirst();
            var boots = p.getItemBySlot(EquipmentSlot.FEET).copy();
            boots.enchant(server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.BINDING_CURSE), 1);
            p.setItemSlot(EquipmentSlot.FEET, boots); p.inventoryMenu.broadcastChanges();
        });
        c.waitFor(client -> client.player.inventoryMenu.getSlot(8).getItem().isEnchanted());
        menuSlot(c, 8, 0);
        check(c.computeOnClient(client -> client.player.inventoryMenu.getCarried().isEmpty() && client.player.inventoryMenu.getSlot(8).hasItem()), "Binding curse removal was allowed");
        capture(c, "sao-armor-inventory");
        menuSlot(c, 5, 0); c.getInput().pressKey(InputConstants.KEY_ESCAPE); c.waitForScreen(null);
        ServerPacketBarrier.await(c);
        world.getServer().runOnServer(server -> {
            var p = server.getPlayerList().getPlayers().getFirst();
            check(p.inventoryMenu.getCarried().isEmpty(), "Closing left an armor stack on the cursor");
            int count = 0; for (int i = 0; i < p.getInventory().getContainerSize(); i++) if (p.getInventory().getItem(i).is(Items.DIAMOND_HELMET)) count++;
            check(count == 1, "Closing with armor duplicated or lost the helmet");
        });
    }
    private static void menuSlot(ClientGameTestContext c, int id, int modifiers) {
        c.runOnClient(client -> {
            var screen = client.gui.screen();
            var slot = screen.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast)
                    .filter(s -> s.menuSlot() == id && s.visible).findFirst().orElseThrow();
            var event = new MouseButtonEvent(slot.getX() + slot.getWidth() / 2.0, slot.getY() + slot.getHeight() / 2.0,
                    new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT, modifiers));
            screen.mouseClicked(event, false); screen.mouseReleased(event);
        }); c.waitTick();
    }
    private static void control(ClientGameTestContext c, String key) {
        SettingsNavigation.expose(c,key);
        c.runOnClient(client -> {
            var screen = client.gui.screen();
            var button = screen.children().stream().filter(Button.class::isInstance).map(Button.class::cast)
                    .filter(b -> b.active && b.getMessage().getContents() instanceof TranslatableContents t && t.getKey().equals(key)).findFirst().orElseThrow();
            var event = new MouseButtonEvent(button.getX() + button.getWidth() / 2.0, button.getY() + button.getHeight() / 2.0,
                    new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT, 0));
            check(screen.mouseClicked(event, false), "Control rejected click: " + key); screen.mouseReleased(event);
        }); c.waitTick();
    }
    private static void open(ClientGameTestContext c, BlockPos pos, boolean skinned) {
        c.getInput().lookAt(pos); c.waitTicks(2); c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_RIGHT);
        c.waitForScreen(AbstractContainerScreen.class);
        check(c.computeOnClient(client -> FlatContainerUi.skinned(client.gui.screen())) == skinned, "Wrong block override at " + pos);
        if (skinned) {
            c.runOnClient(client -> {
                var source = BlockFloatingUi.source(client.gui.screen());
                check(source.equals(pos), "Ray opened " + source + " while aiming at " + pos + "; profile=" + BlockFloatingUi.profile(client.gui.screen()).backpackSide);
            });
            c.waitFor(client -> BlockFloatingUi.ready(client.gui.screen()));
        }
        c.waitTick();
    }
    private static void rules(ClientGameTestContext c, TestSingleplayerContext world) {
        BlockPos a = c.computeOnClient(client -> client.player.blockPosition().offset(0, 0, 2)), b = a.east(), other = a.offset(2, 0, -1);
        BlockUiGameTest.place(c, world, a, Blocks.CHEST); BlockUiGameTest.place(c, world, b, Blocks.BARREL); BlockUiGameTest.place(c, world, other, Blocks.CHEST);
        var local = c.computeOnClient(client -> ContainerTargets.at(other));
        c.runOnClient(client -> {
            var catalog = ContainerTargets.catalog(SaoUiClient.config().containers);
            check(catalog.contains("minecraft:shulker_box") && catalog.contains("minecraft:anvil")
                    && !catalog.contains("minecraft:white_shulker_box") && !catalog.contains("minecraft:damaged_anvil") && catalog.contains("minecraft:ender_chest"), "Container families were not merged in settings");
            SaoUiClient.LOGGER.info("SAO customizable block types: {}", catalog.size());
        });
        check(local.location() != null && local.location().contains("|minecraft:overworld|"), "Location was not world/dimension scoped");
        save(c, config -> {
            var chest = new ContainerUiProfile(); chest.enabled = false; config.containers.blocks.put("minecraft:chest", chest);
            var placed = new ContainerUiProfile(); placed.backpackSide = ContainerUiProfile.Side.LEFT; config.containers.locations.put(local.location(), placed);
        });
        open(c, a, false); BlockUiGameTest.close(c);
        open(c, other, true);
        c.runOnClient(client -> check(client.player.containerMenu.slots.stream().filter(s -> s.container == client.player.getInventory()).allMatch(s -> s.x < 0), "Placed chest did not override its disabled type"));
        capture(c, "sao-placed-chest-left"); BlockUiGameTest.close(c);
        for (var side : ContainerUiProfile.Side.values()) {
            save(c, config -> {
                var p = new ContainerUiProfile(); p.backpackSide = side; p.gap = 30;
                p.containerX = 14; p.containerY = -8; p.backpackX = -10; p.backpackY = 12;
                config.containers.blocks.put("minecraft:barrel", p);
            });
            world.getServer().runOnServer(server -> ((Container)server.getPlayerList().getPlayers().getFirst().level().getBlockEntity(b)).setItem(0, new ItemStack(Items.DIAMOND, 12)));
            open(c, b, true);
            c.runOnClient(client -> {
                var screen = client.gui.screen(); var bounds = FlatContainerUi.bounds(screen); var frame = BlockFloatingUi.frame(screen);
                check(frame.screenX(bounds.x()) >= 0 && frame.screenX(bounds.x() + bounds.width()) < screen.width
                        && frame.screenY(bounds.y()) >= 0 && frame.screenY(bounds.y() + bounds.height()) < screen.height, "Custom layout escaped viewport: " + side);
                var placement = ContainerPanelLayout.place(222, SaoUiClient.config().containers.forBlock("minecraft:barrel"));
                var slot = client.player.containerMenu.slots.stream().filter(s -> s.container == client.player.getInventory() && s.getContainerSlot() == 9).findFirst().orElseThrow();
                check(slot.x == placement.backpackX() + 14 && slot.y == placement.backpackY() + 22, "Backpack slot did not follow custom layout");
            });
            BlockUiGameTest.clickSlot(c, 0, InputConstants.MOUSE_BUTTON_LEFT);
            c.runOnClient(client -> check(client.player.containerMenu.getCarried().is(Items.DIAMOND), "Custom pickup failed: " + side + " / " + client.player.containerMenu.getCarried()));
            BlockUiGameTest.clickSlot(c, 27, InputConstants.MOUSE_BUTTON_LEFT);
            c.runOnClient(client -> check(client.player.containerMenu.getCarried().isEmpty() && client.player.containerMenu.getSlot(27).getItem().is(Items.DIAMOND),
                    "Relocated inventory interaction failed: " + side + " / carried=" + client.player.containerMenu.getCarried() + " slot=" + client.player.containerMenu.getSlot(27).getItem()));
            BlockUiGameTest.clickSlot(c, 27, InputConstants.MOUSE_BUTTON_LEFT, InputConstants.MOD_SHIFT);
            ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> check(((Container)server.getPlayerList().getPlayers().getFirst().level().getBlockEntity(b)).getItem(0).getCount() == 12, "Custom layout transfer did not synchronize"));
            capture(c, "sao-layout-" + side.name().toLowerCase(java.util.Locale.ROOT)); BlockUiGameTest.close(c);
        }
        // A replacement block must not inherit the old placed chest's rule.
        BlockUiGameTest.place(c, world, other, Blocks.HOPPER); open(c, other, true);
        check(c.computeOnClient(client -> BlockFloatingUi.profile(client.gui.screen()).backpackSide) == ContainerUiProfile.Side.RIGHT, "Location rule leaked to a different block type");
        BlockUiGameTest.close(c);
        // Real setting controls: cancelled edits, saved location override, reset-to-inherit and disk reload.
        c.getInput().lookAt(b); c.waitTicks(2);
        c.getInput().pressKey(InputConstants.KEY_K); c.waitForScreen(SaoMenuScreen.class); settled(c);
        control(c, "root.saoui.settings"); settled(c); control(c, "menu.saoui.containers"); c.waitForScreen(SaoContainerSettingsScreen.class);
        control(c, "settings.saoui.containers.scope.location"); control(c, "settings.saoui.containers.enabled");
        control(c, "gui.cancel"); c.waitForScreen(SaoMenuScreen.class); settled(c);
        check(c.computeOnClient(client -> !SaoUiClient.config().containers.locations.containsKey(ContainerTargets.at(b).location())), "Cancel leaked a location override");
        control(c, "menu.saoui.containers"); c.waitForScreen(SaoContainerSettingsScreen.class);
        control(c, "settings.saoui.containers.scope.location"); control(c, "settings.saoui.containers.enabled");
        control(c, "settings.saoui.containers.side");
        c.runOnClient(client -> {
            var fields = SettingsNavigation.widgets(client.gui.screen()).stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).toList();
            fields.get(1).setValue("32"); fields.get(2).setValue("999");
        });
        control(c, "gui.done");
        check(c.computeOnClient(client -> client.gui.screen() instanceof SaoContainerSettingsScreen), "Invalid coordinates were saved");
        c.runOnClient(client -> {
            var fields = SettingsNavigation.widgets(client.gui.screen()).stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).toList();
            fields.get(2).setValue("-16"); fields.get(3).setValue("24"); fields.get(4).setValue("36"); fields.get(5).setValue("-12");
        });
        capture(c, "sao-container-settings"); control(c, "gui.done"); c.waitForScreen(SaoMenuScreen.class); settled(c);
        c.runOnClient(client -> {
            var disk = new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();
            check(!disk.containers.resolve("minecraft:barrel", ContainerTargets.at(b).location()).enabled, "Placed rule was not persisted");
            check(disk.containers.forBlock("minecraft:barrel").enabled, "Placed rule changed all barrels");
            var saved = disk.containers.resolve("minecraft:barrel", ContainerTargets.at(b).location());
            check(saved.backpackSide == ContainerUiProfile.Side.RIGHT && saved.gap == 32 && saved.containerX == -16
                    && saved.containerY == 24 && saved.backpackX == 36 && saved.backpackY == -12, "UI layout fields were not persisted");
        });
        c.getInput().pressKey(InputConstants.KEY_K); c.waitForScreen(null); open(c, b, false); BlockUiGameTest.close(c);
        c.getInput().pressKey(InputConstants.KEY_K); c.waitForScreen(SaoMenuScreen.class); settled(c);
        control(c, "root.saoui.settings"); settled(c); control(c, "menu.saoui.containers"); c.waitForScreen(SaoContainerSettingsScreen.class);
        control(c, "settings.saoui.containers.scope.location"); control(c, "settings.saoui.containers.inherit");
        control(c, "gui.done"); c.waitForScreen(SaoMenuScreen.class); settled(c);
        c.getInput().pressKey(InputConstants.KEY_K); c.waitForScreen(null); open(c, b, true);
        check(c.computeOnClient(client -> BlockFloatingUi.profile(client.gui.screen()).backpackSide) == ContainerUiProfile.Side.ABOVE, "Reset-to-inherit did not restore the type preset");
        BlockUiGameTest.close(c);
    }
    private static void capture(ClientGameTestContext c, String name) {
        var previous = c.computeOnClient(client -> SaoUiClient.config().copy());
        c.runOnClient(client -> {
            var config = SaoUiClient.config(); config.hudEnabled = false;
            config.hud.hideVanillaHealth = config.hud.hideVanillaHunger = config.hud.hideVanillaExperience = config.hud.hideVanillaArmor = config.hud.hideVanillaCrosshair = true;
            client.gui.toastManager().clear(); client.gui.hud.getChat().clearMessages(true);
        });
        c.waitTicks(2); c.takeScreenshot(name);
        c.runOnClient(client -> { SaoUiClient.config().hudEnabled = previous.hudEnabled; SaoUiClient.config().hud = previous.hud; });
    }

}
