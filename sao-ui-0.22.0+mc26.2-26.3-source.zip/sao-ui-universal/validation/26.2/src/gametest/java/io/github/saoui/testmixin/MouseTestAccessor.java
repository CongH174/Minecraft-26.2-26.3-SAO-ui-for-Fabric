package io.github.saoui.testmixin;

import net.minecraft.client.MouseHandler;
import net.minecraft.client.input.MouseButtonInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Test-only native event dispatch; Fabric's 26.2 fixture does not widen this method. */
@Mixin(MouseHandler.class)
public interface MouseTestAccessor {
    @Invoker("onButton") void saoui$button(long window, MouseButtonInfo button, int action);
}
