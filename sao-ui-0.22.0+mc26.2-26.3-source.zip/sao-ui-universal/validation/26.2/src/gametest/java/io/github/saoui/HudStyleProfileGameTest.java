package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.WidgetTooltipHolder;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.gamerules.GameRules;

/** Delivered-JAR acceptance of the new HUD, live profile and shallow layout entry. */
public final class HudStyleProfileGameTest implements FabricClientGameTest {
 @Override public void runTest(ClientGameTestContext c){
  var original=c.computeOnClient(client->SaoUiClient.config().copy());String old=c.computeOnClient(client->client.getLanguageManager().getSelected());
  language(c,"zh_cn");save(c,new SaoConfig());
  try(var world=c.worldBuilder().create()){
   world.getClientLevel().waitForChunksRender();c.waitForScreen(null);
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.setGameMode(GameType.SURVIVAL);p.level().getGameRules().set(GameRules.NATURAL_HEALTH_REGENERATION,false,server);p.getInventory().clearContent();p.setHealth(14);p.getFoodData().setFoodLevel(16);p.setExperienceLevels(17);p.setExperiencePoints(9);var sword=new ItemStack(Items.DIAMOND_SWORD);sword.setDamageValue(400);p.getInventory().setItem(0,sword);p.getInventory().setItem(10,new ItemStack(Items.APPLE,8));var chest=new ItemStack(Items.DIAMOND_CHESTPLATE);chest.setDamageValue(chest.getMaxDamage()-30);p.setItemSlot(EquipmentSlot.CHEST,chest);p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,12000,1));p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,12000));p.inventoryMenu.broadcastChanges();});
   c.waitFor(client->client.player.experienceLevel==17&&client.player.getArmorValue()==8&&client.player.getAbsorptionAmount()==8);
   settings(c);layout(c);
   for(var style:HudBarStyle.values())for(boolean right:new boolean[]{false,true}){
    var cfg=new SaoConfig();cfg.hud.style=style;cfg.hud.rightAligned=right;cfg.smoothHealth=false;save(c,cfg);
    c.runOnClient(client->{var left=cfg.copy();left.hud.rightAligned=false;var a=SaoHud.frame(client,left,client.getWindow().getGuiScaledWidth(),client.getWindow().getGuiScaledHeight());var b=SaoHud.frame(client,cfg,client.getWindow().getGuiScaledWidth(),client.getWindow().getGuiScaledHeight());if(right){check(Math.abs(a.x()-(client.getWindow().getGuiScaledWidth()-b.x()-b.width()))<=1,"Unequal mirrored margins");check(b.y()>=30,"Default right anchor overlaps native effect icons");var custom=cfg.copy();custom.y=13;var explicit=SaoHud.frame(client,custom,client.getWindow().getGuiScaledWidth(),client.getWindow().getGuiScaledHeight());check(explicit.y()<b.y(),"Custom height was overridden by effect avoidance");}});
    shot(c,"sao-style-"+style.name().toLowerCase(java.util.Locale.ROOT)+(right?"-right":"-left"));
   }
   var cfg=new SaoConfig();cfg.hud.style=HudBarStyle.RECTANGLE;cfg.hud.rightAligned=true;cfg.smoothHealth=false;save(c,cfg);
   world.getServer().runOnServer(server->server.getPlayerList().getPlayers().getFirst().addEffect(new MobEffectInstance(MobEffects.POISON,12000)));c.waitFor(client->SaoHud.sample(client).condition()==HudValues.Condition.POISONED);shot(c,"sao-rectangle-right-poison");
   world.getServer().runOnServer(server->server.getPlayerList().getPlayers().getFirst().addEffect(new MobEffectInstance(MobEffects.WITHER,12000)));c.waitFor(client->SaoHud.sample(client).condition()==HudValues.Condition.WITHERED);shot(c,"sao-rectangle-right-wither");
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.removeEffect(MobEffects.POISON);p.removeEffect(MobEffects.WITHER);});
   c.waitFor(client->SaoHud.sample(client).condition()==HudValues.Condition.NORMAL);
   cfg.homeModule="profile";cfg.parallaxEnabled=false;save(c,cfg);c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());
   c.runOnClient(client->{check(PlayerStatusPanel.occupied(client.player)==2,"Profile backpack occupancy wrong");check(PlayerStatusPanel.weakest(client.player).stack().is(Items.DIAMOND_CHESTPLATE),"Profile minimum equipment durability wrong");});shot(c,"sao-player-status");
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getItemBySlot(EquipmentSlot.CHEST).setDamageValue(0);p.getInventory().setItem(11,new ItemStack(Items.DIAMOND));p.inventoryMenu.broadcastChanges();});
   c.waitFor(client->PlayerStatusPanel.occupied(client.player)==3&&PlayerStatusPanel.weakest(client.player).stack().is(Items.DIAMOND_SWORD));shot(c,"sao-player-status-live-update");
   language(c,"en_us");shot(c,"sao-player-status-english");c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
   SaoUiClient.LOGGER.info("SAO HUD style/profile passed: native dropdown and keyboard, both directions/styles, potion overlays, right-edge drag/resize, save/cancel/disk, shallow global layout draft, live equipment/backpack/profile, bilingual screenshots");
  }finally{c.runOnClient(client->client.gui.setScreen(null));save(c,original);language(c,old);}
 }
 private static void settings(ClientGameTestContext c){
  for(boolean commit:new boolean[]{false,true}){
   c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));c.clickScreenButton("settings.saoui.category.hud");SettingsNavigation.click(c,"settings.saoui.hud_right");SettingsNavigation.click(c,"settings.saoui.hud_style");c.waitTick();
   c.runOnClient(client->{var picker=field(client.gui.screen(),"stylePicker");check((boolean)field(picker,"open"),"Style menu did not open");for(var option:options(picker))check(((WidgetTooltipHolder)fieldAs(option,AbstractWidget.class,"tooltip")).get()!=null,"Style choice lacks explanation");});
   if(commit)shot(c,"sao-style-dropdown");
   c.runOnClient(client->{var s=client.gui.screen();var done=SettingsNavigation.widget(s,"gui.done");s.mouseClicked(event(done.getX()+5,done.getY()+5),false);check(client.gui.screen()==s,"Dismissal clicked the underlying Save button");check(!(boolean)field(field(s,"stylePicker"),"open"),"Outside click did not dismiss style menu");});SettingsNavigation.click(c,"settings.saoui.hud_style");clickOption(c,1);
   c.runOnClient(client->{var draft=(SaoConfig)field(client.gui.screen(),"draft");check(draft.hud.rightAligned&&draft.hud.style==HudBarStyle.RECTANGLE,"Style/direction click did not update draft");check(!SaoUiClient.config().hud.rightAligned&&SaoUiClient.config().hud.style==HudBarStyle.SAO,"Unsaved style leaked into live HUD");});
   c.clickScreenButton(commit?"gui.done":"gui.cancel");check(c.computeOnClient(client->SaoUiClient.config().hud.rightAligned)==commit,"Style save/cancel direction failed");
  }
  c.runOnClient(client->{var disk=new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();check(disk.hud.rightAligned&&disk.hud.style==HudBarStyle.RECTANGLE,"New HUD preferences lost on disk");client.gui.setScreen(new SaoSettingsScreen(null));});c.clickScreenButton("settings.saoui.category.hud");SettingsNavigation.click(c,"settings.saoui.hud_style");
  c.runOnClient(client->{var s=client.gui.screen();s.keyPressed(new KeyEvent(InputConstants.KEY_UP,0,0));s.keyPressed(new KeyEvent(InputConstants.KEY_RETURN,0,0));check(((SaoConfig)field(s,"draft")).hud.style==HudBarStyle.SAO,"Style menu keyboard selection failed");});c.clickScreenButton("gui.cancel");
  c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));c.clickScreenButton("settings.saoui.category.hud");SettingsNavigation.click(c,"settings.saoui.layout.hud_title");
  c.runOnClient(client->{var s=client.gui.screen();var draft=(SaoConfig)field(s,"draft");check(draft.hud.rightAligned&&draft.hud.style==HudBarStyle.RECTANGLE,"HUD preview lost draft style/direction");var f=SaoHud.frame(client,draft,s.width,s.height);double scale=(double)field(s,"canvasScale"),x=(double)field(s,"canvasX"),y=(double)field(s,"canvasY");var a=event(x+(f.x()+f.width()/2.0)*scale,y+(f.y()+f.height()/2.0)*scale);check(s.mouseClicked(a,false),"Right HUD could not be grabbed");var b=event(a.x()-24*scale,a.y()+20*scale);s.mouseDragged(b,-24*scale,20*scale);s.mouseReleased(b);check(draft.x>12,"Dragging left did not increase right margin");int before=draft.x;s.resize(s.width,s.height);check(((SaoConfig)field(s,"draft")).x==before,"Resize lost right margin");});shot(c,"sao-right-hud-editor");c.clickScreenButton("settings.saoui.layout.apply");c.clickScreenButton("gui.cancel");check(c.computeOnClient(client->SaoUiClient.config().x)==12,"Cancelled right drag leaked");
 }
 private static void layout(ClientGameTestContext c){
  for(boolean commit:new boolean[]{false,true}){
   c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));c.clickScreenButton("settings.saoui.category.interface");c.waitTick();
   c.runOnClient(client->{var s=(SaoSettingsScreen)client.gui.screen();var w=SettingsNavigation.widget(s,"settings.saoui.layout.container_shortcut");check(w.getY()>=38&&w.getY()<70,"Visual layout entry not visible in first row");});if(commit)shot(c,"sao-interface-layout-shortcut");SettingsNavigation.click(c,"settings.saoui.layout.container_shortcut");c.waitForScreen(SaoContainerLayoutScreen.class);
   c.runOnClient(client->{var s=client.gui.screen();((ContainerUiProfile)field(s,"draft")).containerX=37;});c.clickScreenButton("settings.saoui.layout.apply");check(c.computeOnClient(client->SaoUiClient.config().containers.defaults.containerX)==0,"Shallow layout Apply wrote live config");c.clickScreenButton(commit?"gui.done":"gui.cancel");check(c.computeOnClient(client->SaoUiClient.config().containers.defaults.containerX)==(commit?37:0),"Shallow layout save/cancel failed");
  }
  c.runOnClient(client->{check(SaoUiClient.config().containers.blocks.isEmpty()&&SaoUiClient.config().containers.locations.isEmpty(),"Global layout manufactured overrides");client.gui.setScreen(new SaoContainerSettingsScreen(null));});shot(c,"sao-container-layout-entry");c.clickScreenButton("gui.cancel");
 }
 @SuppressWarnings("unchecked") private static List<SaoButton> options(Object picker){return (List<SaoButton>)field(picker,"options");}
 private static void clickOption(ClientGameTestContext c,int i){double[] pt=c.computeOnClient(client->{var s=client.gui.screen();var w=options(field(s,"stylePicker")).get(i);var win=client.getWindow();return new double[]{(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width,(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};});c.getInput().setCursorPos(pt[0],pt[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTick();}
 private static Object field(Object object,String key){return fieldAs(object,object.getClass(),key);}
 private static Object fieldAs(Object object,Class<?> type,String key){try{var f=type.getDeclaredField(key);f.setAccessible(true);return f.get(object);}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
 private static MouseButtonEvent event(double x,double y){return new MouseButtonEvent(x,y,new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0));}
 private static void save(ClientGameTestContext c,SaoConfig cfg){c.runOnClient(client->{try{SaoUiClient.saveConfig(cfg);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
 private static void language(ClientGameTestContext c,String code){var r=c.computeOnClient(client->{client.getLanguageManager().setSelected(code);return client.reloadResourcePacks();});c.waitFor(client->r.isDone());r.join();c.waitFor(client->client.gui.overlay()==null);}
 private static void shot(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.waitTicks(2);c.takeScreenshot(name);}
 private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
