package io.github.saoui;
import java.util.List;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.network.chat.Component;
public final class LoreToggleGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        var original=c.computeOnClient(client->SaoUiClient.config().copy());String old=c.computeOnClient(client->client.getLanguageManager().getSelected());
        try{
            for(String language:List.of("zh_cn","en_us")){
                var reload=c.computeOnClient(client->{client.getLanguageManager().setSelected(language);return client.reloadResourcePacks();});c.waitFor(client->reload.isDone());reload.join();c.waitFor(client->client.gui.overlay()==null);
                c.runOnClient(client->{var cfg=original.copy();cfg.serverEnchantmentLore=true;save(cfg);client.gui.setScreen(new SaoSettingsScreen(null));});c.clickScreenButton("settings.saoui.category.compat");
                String before=c.computeOnClient(client->SettingsNavigation.widget(client.gui.screen(),"settings.saoui.server_enchantment_lore").getMessage().getString());
                SettingsNavigation.click(c,"settings.saoui.server_enchantment_lore");
                c.runOnClient(client->{var s=(SaoSettingsScreen)client.gui.screen();try{var f=SaoSettingsScreen.class.getDeclaredField("draft");f.setAccessible(true);check(!((SaoConfig)f.get(s)).serverEnchantmentLore,"Lore switch did not change draft");}catch(ReflectiveOperationException e){throw new AssertionError(e);}var label=SettingsNavigation.widget(s,"settings.saoui.server_enchantment_lore").getMessage().getString();check(!label.equals(before),"Lore switch changes draft but its visible label never changes: "+label);check(label.contains(Component.translatable("options.off").getString()),"Lore switch lacks visible OFF state");check(SaoUiClient.config().serverEnchantmentLore,"Unsaved switch changed live config");});
                if(language.equals("zh_cn"))c.takeScreenshot("sao-lore-switch-off");c.clickScreenButton("gui.done");
                c.runOnClient(client->{check(!SaoUiClient.config().serverEnchantmentLore,"Lore OFF did not save");var disk=new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();check(!disk.serverEnchantmentLore,"Lore OFF did not persist");client.gui.setScreen(new SaoSettingsScreen(null));});c.clickScreenButton("settings.saoui.category.compat");SettingsNavigation.click(c,"settings.saoui.server_enchantment_lore");c.clickScreenButton("gui.cancel");check(!c.computeOnClient(client->SaoUiClient.config().serverEnchantmentLore),"Cancelled Lore ON leaked to config");
            }
            SaoUiClient.LOGGER.info("SAO lore switch passed: native click visibly changes ON/OFF in both languages, draft isolation, save/disk and cancel");
        }finally{c.runOnClient(client->{save(original);client.gui.setScreen(null);});var restore=c.computeOnClient(client->{client.getLanguageManager().setSelected(old);return client.reloadResourcePacks();});c.waitFor(client->restore.isDone());restore.join();c.waitFor(client->client.gui.overlay()==null);}
    }
    private static void save(SaoConfig cfg){try{SaoUiClient.saveConfig(cfg);}catch(java.io.IOException e){throw new RuntimeException(e);}}
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
}
