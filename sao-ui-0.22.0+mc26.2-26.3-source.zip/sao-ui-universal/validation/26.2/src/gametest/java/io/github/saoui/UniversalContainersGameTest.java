package io.github.saoui;

import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;
import io.github.saoui.mixin.ContainerScreenAccessor;
import io.github.saoui.mixin.RecipeScreenAccessor;
import io.github.saoui.testmixin.CreativeTestAccessor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.inventory.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.trading.*;
import net.minecraft.world.level.GameType;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;

/** Regression for nested inventory initialization after a recent block interaction. */
public final class UniversalContainersGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c) {
        SaoConfig original = c.computeOnClient(client -> SaoUiClient.config().copy());
        try (var world = c.worldBuilder().create()) {
            world.getClientLevel().waitForChunksRender(); c.waitForScreen(null);
            c.runOnClient(client -> {
                client.player.setYRot(0); client.player.setXRot(0);
                BlockFloatingUi.remember(client.player.blockPosition().offset(0, 0, 2));
                var outer = new Screen(Component.literal("Nested inventory regression")) {
                    @Override protected void init() {
                        var helper = new InventoryInteraction(new PlayerPanels(slot -> {}, slot -> {}), () -> {});
                        helper.init(width, height);
                        BlockFloatingUi.onScreenInit(minecraft, helper);
                        if (BlockFloatingUi.active(helper)) throw new AssertionError("Internal bridge became a container screen");
                    }
                };
                client.gui.setScreen(outer);
            });
            c.runOnClient(client -> client.gui.setScreen(null));
            SaoUiClient.LOGGER.info("SAO nested menu crash regression passed");
            c.waitTicks(40); // The following server menu deliberately has no recent UseBlock origin.
            c.runOnClient(client -> { SaoUiClient.config().replaceAllContainers = false; SaoUiClient.config().blockUiEnabled = false; });
            openChest(world);
            c.waitForScreen(ContainerScreen.class);
            require(!c.computeOnClient(client -> BlockFloatingUi.active(client.gui.screen())), "Opt-in switch ignored");
            close(c);
            // Verify settings drafts, cancellation and saving through the real widgets.
            c.runOnClient(client -> client.gui.setScreen(new SaoSettingsScreen(null)));
            pressToggle(c);
            require(!c.computeOnClient(client -> SaoUiClient.config().replaceAllContainers), "Draft leaked before saving");
            c.clickScreenButton("gui.cancel");
            require(!c.computeOnClient(client -> SaoUiClient.config().replaceAllContainers), "Cancel enabled global takeover");
            c.runOnClient(client -> client.gui.setScreen(new SaoSettingsScreen(null)));
            pressToggle(c); c.clickScreenButton("gui.done");
            require(c.computeOnClient(client -> SaoUiClient.config().replaceAllContainers), "Global takeover not saved");
            c.runOnClient(client -> { SaoUiClient.config().parallaxStrength=0; SaoUiClient.config().containers.defaults.enabled=false; });
            openChest(world); c.waitForScreen(ContainerScreen.class); settle(c);
            require(c.computeOnClient(client -> BlockFloatingUi.source(client.gui.screen())==null), "Server menu reused a stale block origin");
            c.waitFor(client -> client.player.containerMenu.getSlot(0).getItem().getCount()==12);
            BlockUiGameTest.clickSlot(c,0,0,InputConstants.MOD_SHIFT);
            ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> require(server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.DIAMOND)==12,"Server plugin-style menu quick move failed"));
            capture(c,"sao-universal-server-menu"); close(c);
            // Client E inventory has a null menu type, unlike server-opened menus.
            c.getInput().pressKey(InputConstants.KEY_E); c.waitForScreen(InventoryScreen.class); settle(c);
            c.runOnClient(client -> {
                require(UniversalContainerUi.managed(client.gui.screen()),"Inventory is missing its universal skin");
                ((RecipeScreenAccessor)client.gui.screen()).saoui$book().toggleVisibility();
            });
            c.waitTicks(2); checkFit(c); capture(c,"sao-universal-inventory-recipes");
            c.runOnClient(client -> ((RecipeScreenAccessor)client.gui.screen()).saoui$book().toggleVisibility());
            close(c);
            world.getServer().runOnServer(server -> {
                var p1=server.getPlayerList().getPlayers().getFirst();
                p1.getInventory().setItem(9,new ItemStack(Items.DIAMOND_HELMET)); p1.inventoryMenu.broadcastChanges();
            });
            c.waitFor(client -> client.player.getInventory().getItem(9).is(Items.DIAMOND_HELMET));
            c.getInput().pressKey(InputConstants.KEY_E); c.waitForScreen(InventoryScreen.class); settle(c);
            BlockUiGameTest.clickSlot(c,9,0); BlockUiGameTest.clickSlot(c,5,0); ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> require(server.getPlayerList().getPlayers().getFirst().inventoryMenu.getSlot(5).getItem().is(Items.DIAMOND_HELMET),"Universal inventory armor was not equipped"));
            c.getInput().pressKey(InputConstants.KEY_K); c.waitForScreen(null);
            // Irregular mod menu: no moved coordinates, real custom packet callback and data synchronization.
            world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().openMenu(new SimpleMenuProvider((id,inv,p1)->{
                var m=new UniversalTestMenus.TestMenu(id,inv); m.getSlot(0).set(new ItemStack(Items.EMERALD,7)); return m;
            },Component.literal("Modded Controller"))));
            c.waitForScreen(UniversalTestMenus.TestScreen.class); settle(c);
            c.waitFor(client -> client.player.containerMenu.getSlot(0).getItem().getCount()==7);
            require(c.computeOnClient(client -> client.player.containerMenu.getSlot(1).x)==68,"Universal skin moved irregular slots");
            clickWidget(c,"SERVER ACTION");
            c.waitFor(client -> ((UniversalTestMenus.TestMenu)client.player.containerMenu).clicks.get()==1);
            require(UniversalTestMenus.TestScreen.customFrames>0,"Custom non-widget renderable was discarded");
            require(UniversalTestMenus.TestScreen.labelFrames>0,"Modded labels were discarded");
            BlockUiGameTest.clickSlot(c,0,0); BlockUiGameTest.clickSlot(c,6,0); ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> require(server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.EMERALD)==7,"Mod menu item packet was lost"));
            capture(c,"sao-universal-modded"); close(c);
            // Merchant opens from server packets, and keeps its real offer/result semantics.
            world.getServer().runOnServer(server -> {
                var p1=server.getPlayerList().getPlayers().getFirst();
                var merchant=new net.minecraft.world.entity.npc.villager.Villager((EntityType)BuiltInRegistries.ENTITY_TYPE.getValue(Identifier.withDefaultNamespace("villager")),p1.level());
                merchant.setPos(p1.getX()+1,p1.getY(),p1.getZ()); merchant.setNoAi(true); p1.level().addFreshEntity(merchant);
                var offers=new MerchantOffers(); offers.add(new MerchantOffer(new ItemCost(Items.EMERALD),new ItemStack(Items.APPLE),10,1,0));
                offers.add(new MerchantOffer(new ItemCost(Items.EMERALD,2),new ItemStack(Items.BREAD),10,1,0));
                merchant.setOffers(offers); merchant.setTradingPlayer(p1); merchant.openTradingScreen(p1,Component.literal("SAO Merchant"),1);
                ((MerchantMenu)p1.containerMenu).getSlot(0).setByPlayer(new ItemStack(Items.EMERALD)); p1.containerMenu.broadcastChanges();
            });
            c.waitForScreen(MerchantScreen.class); settle(c);
            c.waitFor(client -> client.player.containerMenu.getSlot(2).getItem().is(Items.APPLE));
            clickTrade(c,1);
            c.waitFor(client -> client.player.containerMenu.getSlot(2).getItem().is(Items.BREAD));
            capture(c,"sao-universal-merchant"); BlockUiGameTest.clickSlot(c,2,0); close(c); ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> require(server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.BREAD)==1,"Merchant selection/output lost on close"));
            // Entity inventory uses its own open-horse packet, outside handleOpenScreen.
            world.getServer().runOnServer(server -> {
                var p1=server.getPlayerList().getPlayers().getFirst();
                var horse=new net.minecraft.world.entity.animal.equine.Horse((EntityType)BuiltInRegistries.ENTITY_TYPE.getValue(Identifier.withDefaultNamespace("horse")),p1.level());
                horse.setPos(p1.getX()+1,p1.getY(),p1.getZ()); horse.setTamed(true); horse.setNoAi(true); p1.level().addFreshEntity(horse);
            });
            c.waitTicks(5);
            world.getServer().runOnServer(server -> {
                var p1=server.getPlayerList().getPlayers().getFirst();
                var horse=p1.level().getEntitiesOfClass(net.minecraft.world.entity.animal.equine.Horse.class,p1.getBoundingBox().inflate(8)).getFirst(); horse.openCustomInventoryScreen(p1);
            });
            c.waitForScreen(HorseInventoryScreen.class); settle(c);
            world.getServer().runOnServer(server -> {
                var p1=server.getPlayerList().getPlayers().getFirst(); p1.getInventory().setItem(9,new ItemStack(Items.SADDLE)); p1.containerMenu.broadcastChanges();
            });
            c.waitFor(client -> client.player.getInventory().getItem(9).is(Items.SADDLE));
            int[] horseSlots=c.computeOnClient(client -> {
                var m=client.player.containerMenu; int from=-1,to=-1;
                for(var slot:m.slots) { if(slot.container==client.player.getInventory() && slot.getContainerSlot()==9)from=slot.index;
                    if(slot.container!=client.player.getInventory() && slot.isActive() && slot.mayPlace(new ItemStack(Items.SADDLE)))to=slot.index; }
                require(from>=0 && to>=0,"Horse fixture has no saddle slot"); return new int[]{from,to};
            });
            BlockUiGameTest.clickSlot(c,horseSlots[0],0); BlockUiGameTest.clickSlot(c,horseSlots[1],0); ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> require(server.getPlayerList().getPlayers().getFirst().containerMenu.getSlot(horseSlots[1]).getItem().is(Items.SADDLE),"Horse saddle packet failed"));
            capture(c,"sao-universal-horse"); close(c);
            // Creative has tab-dependent slot sets, search controls and offscreen hidden slots.
            world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().setGameMode(GameType.CREATIVE));
            c.waitFor(client -> client.player.isCreative());
            c.getInput().pressKey(InputConstants.KEY_E); c.waitForScreen(CreativeModeInventoryScreen.class); settle(c);
            capture(c,"sao-universal-creative");
            for (var id : new String[]{"search","inventory","building_blocks"}) {
                clickCreativeTab(c,id);
                c.waitTicks(2); checkFit(c); capture(c,"sao-universal-creative-"+id);
            }
            var picked=c.computeOnClient(client -> ((AbstractContainerScreen<?>)client.gui.screen()).getMenu().getSlot(0).getItem().copy());
            BlockUiGameTest.clickSlot(c,0,0); BlockUiGameTest.clickSlot(c,45,0); ServerPacketBarrier.await(c);
            world.getServer().runOnServer(server -> require(server.getPlayerList().getPlayers().getFirst().getInventory().getItem(0).is(picked.getItem()),"Creative item placement did not reach server"));
            close(c);
            world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().setGameMode(GameType.SURVIVAL));
            c.waitFor(client -> !client.player.isCreative());
            SaoUiClient.LOGGER.info("SAO universal containers passed: settings drafts, client E inventory/null menu type, server-opened plugin menu/quick move, irregular mod menu/button synchronization, merchant trade, horse and creative tabs");
        } finally {
            c.runOnClient(client -> { try { SaoUiClient.saveConfig(original); } catch(java.io.IOException e) { throw new RuntimeException(e); } });
        }
    }
    private static void openChest(TestSingleplayerContext world) {
        world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().openMenu(new SimpleMenuProvider((id,inv,p)->{
            var storage=new SimpleContainer(27); storage.setItem(0,new ItemStack(Items.DIAMOND,12));
            return ChestMenu.threeRows(id,inv,storage);
        },Component.literal("Server Plugin Menu"))));
    }
    private static void pressToggle(ClientGameTestContext c) {
        SettingsNavigation.expose(c,"settings.saoui.all_containers");
        String label=c.computeOnClient(client -> Component.translatable("settings.saoui.all_containers",Component.translatable(SaoUiClient.config().replaceAllContainers?"options.on":"options.off")).getString());
        SettingsNavigation.click(c,"settings.saoui.all_containers");
    }
    private static void settle(ClientGameTestContext c) {
        c.waitFor(client -> BlockFloatingUi.active(client.gui.screen()) && BlockFloatingUi.ready(client.gui.screen()));
        c.waitTicks(2); checkFit(c);
        require(c.computeOnClient(client -> FlatContainerUi.skinned(client.gui.screen())),"Container not skinned");
    }
    private static void checkFit(ClientGameTestContext c) {
        c.runOnClient(client -> {
            var s=client.gui.screen(); var b=FlatContainerUi.bounds(s); var f=BlockFloatingUi.frame(s);
            require(f.screenX(b.x())>=0 && f.screenY(b.y())>=0 && f.screenX(b.x()+b.width())<=s.width && f.screenY(b.y()+b.height())<=s.height,"Universal canvas clipped: "+s.getClass()+" "+b);
            require(b.width()<s.width*3 && b.height()<s.height*3,"Offscreen hidden slots expanded the canvas: "+s.getClass()+" "+b);
        });
    }
    private static void clickWidget(ClientGameTestContext c,String label) {
        double[] point=c.computeOnClient(client -> {
            var s=client.gui.screen(); var f=BlockFloatingUi.frame(s); var win=client.getWindow();
            var w=SettingsNavigation.widgets(s).stream().filter(AbstractWidget.class::isInstance).map(AbstractWidget.class::cast).filter(b->b.getMessage().getString().equals(label)).findFirst().orElseThrow();
            return new double[]{f.screenX(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width, f.screenY(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};
        });
        c.getInput().setCursorPos(point[0],point[1]); c.waitTick(); c.getInput().pressMouse(0); c.waitTick();
    }
    private static void clickTrade(ClientGameTestContext c,int row) {
        double[] point=c.computeOnClient(client -> {
            var s=client.gui.screen(); var f=BlockFloatingUi.frame(s); var win=client.getWindow();
            var w=SettingsNavigation.widgets(s).stream().filter(AbstractWidget.class::isInstance).map(AbstractWidget.class::cast)
                .filter(b->b.visible && b.getClass().getSimpleName().equals("TradeOfferButton"))
                .sorted(java.util.Comparator.comparingInt(AbstractWidget::getY)).toList().get(row);
            return new double[]{f.screenX(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width,f.screenY(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};
        });
        c.getInput().setCursorPos(point[0],point[1]); c.waitTick(); c.getInput().pressMouse(0); c.waitTick();
    }
    private static void clickCreativeTab(ClientGameTestContext c,String id) {
        double[] point=c.computeOnClient(client -> {
            var s=client.gui.screen(); var a=(ContainerScreenAccessor)s; var f=BlockFloatingUi.frame(s); var win=client.getWindow();
            var tab=BuiltInRegistries.CREATIVE_MODE_TAB.getValue(Identifier.withDefaultNamespace(id)); var t=(CreativeTestAccessor)s;
            return new double[]{f.screenX(a.saoui$left()+t.saoui$tabX(tab)+13)*win.getScreenWidth()/s.width,
                f.screenY(a.saoui$top()+t.saoui$tabY(tab)+16)*win.getScreenHeight()/s.height};
        });
        c.getInput().setCursorPos(point[0],point[1]); c.waitTick(); c.getInput().pressMouse(0); c.waitTick();
    }
    private static void close(ClientGameTestContext c) { c.getInput().pressKey(InputConstants.KEY_ESCAPE); c.waitForScreen(null); c.waitTick(); }
    private static void capture(ClientGameTestContext c,String name) { c.runOnClient(client -> { client.gui.toastManager().clear(); client.gui.hud.getChat().clearMessages(true); }); c.waitTick(); c.takeScreenshot(name); }
    private static void require(boolean c,String message) { if(!c) throw new AssertionError(message); }
}
