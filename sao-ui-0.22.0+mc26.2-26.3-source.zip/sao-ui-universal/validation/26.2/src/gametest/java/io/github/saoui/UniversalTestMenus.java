package io.github.saoui;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;

/** Fixture only: deliberately irregular mod menu, real server slots and button packets. */
public final class UniversalTestMenus implements ModInitializer, ClientModInitializer {
    static final MenuType<TestMenu> TYPE = new MenuType<>(TestMenu::new, FeatureFlags.VANILLA_SET);
    @Override public void onInitialize() {
        Registry.register(BuiltInRegistries.MENU, Identifier.fromNamespaceAndPath("saoui-test", "irregular"), TYPE);
    }
    @Override public void onInitializeClient() { MenuScreens.register(TYPE, TestScreen::new); }
    static final class TestMenu extends AbstractContainerMenu {
        final DataSlot clicks = DataSlot.standalone();
        TestMenu(int id, Inventory inventory) {
            super(TYPE, id);
            var storage = new SimpleContainer(6);
            for (int i=0;i<6;i++) addSlot(new Slot(storage,i,12+(i%3)*56,22+(i/3)*31));
            addStandardInventorySlots(inventory, 8, 94);
            addDataSlot(clicks);
        }
        @Override public boolean stillValid(Player player) { return true; }
        @Override public ItemStack quickMoveStack(Player p, int index) {
            var slot = getSlot(index); if (!slot.hasItem()) return ItemStack.EMPTY;
            var stack = slot.getItem(); var old = stack.copy();
            if (!moveItemStackTo(stack,index<6?6:0,index<6?slots.size():6,index<6)) return ItemStack.EMPTY;
            if(stack.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
            return old;
        }
        @Override public boolean clickMenuButton(Player p,int button) {
            if(button!=0) return false; clicks.set(clicks.get()+1); broadcastChanges(); return true;
        }
    }
    static final class TestScreen extends AbstractContainerScreen<TestMenu> {
        static int labelFrames, customFrames;
        TestScreen(TestMenu menu, Inventory inv, Component title) { super(menu,inv,title,176,180); }
        @Override protected void init() {
            super.init();
            addRenderableOnly((g,x,y,d)->{ customFrames++; g.text(font,"READY",leftPos+8,topPos+76,0xFF397633,false); });
            addRenderableWidget(Button.builder(Component.literal("SERVER ACTION"), b -> Minecraft.getInstance().gameMode.handleInventoryButtonClick(menu.containerId,0))
                .bounds(leftPos+50,topPos+69,118,20).build());
        }
        @Override public void extractBackground(GuiGraphicsExtractor g,int x,int y,float d) {
            g.blit(RenderPipelines.GUI_TEXTURED,INVENTORY_LOCATION,leftPos,topPos,0,0,176,180,256,256);
        }
        @Override protected void extractLabels(GuiGraphicsExtractor g,int x,int y) {
            labelFrames++;
            g.text(font,"Synchronized: "+menu.clicks.get(),8,7,0xFFFFFFFF,false);
        }
    }
}
