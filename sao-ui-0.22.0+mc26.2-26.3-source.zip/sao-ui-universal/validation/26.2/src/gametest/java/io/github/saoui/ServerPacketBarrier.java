package io.github.saoui;

import java.util.concurrent.atomic.AtomicInteger;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;

/** Test-only ordered round trip using vanilla stats request/response, absent from the 26.2 fixture API. */
public final class ServerPacketBarrier {
    public static final AtomicInteger replies = new AtomicInteger();
    public static void await(ClientGameTestContext context) {
        int previous = replies.get();
        context.runOnClient(client -> client.getConnection().send(
                new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.REQUEST_STATS)));
        context.waitFor(client -> replies.get() > previous);
    }
    private ServerPacketBarrier() {}
}
