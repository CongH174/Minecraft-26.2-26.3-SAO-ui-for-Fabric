package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import io.github.saoui.testmixin.MouseTestAccessor;
import io.github.saoui.mixin.ContainerScreenAccessor;
import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.*;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import io.github.saoui.mixin.RecipeScreenAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.Vec3;

public final class BlockUiGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext context) {
        context.runOnClient(client -> client.options.pauseOnLostFocus = false);
        try (var world = context.worldBuilder().create()) {
            world.getClientLevel().waitForChunksRender();
            context.waitForScreen(null);
            BlockPos position = context.computeOnClient(client -> client.player.blockPosition().offset(0, 0, 2));
            place(context, world, position, Blocks.CHEST);
            world.getServer().runOnServer(server -> {
                var player = server.getPlayerList().getPlayers().getFirst();
                ((Container) player.level().getBlockEntity(position)).setItem(0, new ItemStack(Items.DIAMOND, 12));
            });
            AtomicLong clock = new AtomicLong();
            context.runOnClient(client -> BlockFloatingUi.testClock(clock::get));
            open(context, position);
            context.runOnClient(client -> {
                var screen = client.gui.screen();
                require(BlockFloatingUi.source(screen).equals(position), "Entrance was not attached to the used chest");
                require(!BlockFloatingUi.ready(screen), "Entrance was skipped");
            });
            clickSlot(context, 0, InputConstants.MOUSE_BUTTON_LEFT); // Input during approach is ignored.
            require(context.computeOnClient(client -> client.player.containerMenu.getCarried().isEmpty()),
                    "Opening animation accepted an inventory mutation");
            for (int i = 0; i <= 6; i++) {
                clock.set(i * 70L);
                context.waitTick();
                capture(context, String.format("sao-chest-opening-%02d", i));
            }
            require(context.computeOnClient(client -> BlockFloatingUi.ready(client.gui.screen())), "Chest entrance did not settle");
            clickSlot(context, 0, InputConstants.MOUSE_BUTTON_LEFT);
            require(context.computeOnClient(client -> client.player.containerMenu.getCarried().getCount() == 12),
                    "Transformed pointer did not pick up the chest stack");
            clickSlot(context, 27, InputConstants.MOUSE_BUTTON_LEFT);
            require(context.computeOnClient(client -> client.player.containerMenu.getCarried().isEmpty()
                    && client.player.containerMenu.getSlot(27).getItem().getCount() == 12), "Chest placement failed");
            clickSlot(context, 27, InputConstants.MOUSE_BUTTON_LEFT, InputConstants.MOD_SHIFT);
            ServerPacketBarrier.await(context);
            world.getServer().runOnServer(server -> {
                var player = server.getPlayerList().getPlayers().getFirst();
                var chest = (Container) player.level().getBlockEntity(position);
                require(chest.getItem(0).is(Items.DIAMOND) && chest.getItem(0).getCount() == 12,
                        "Native chest quick move did not synchronize to the server");
                require(player.containerMenu.getCarried().isEmpty(), "Chest cursor not cleared after transfer");
                require(player.getInventory().countItem(Items.DIAMOND) == 0, "Chest transfer duplicated items in player inventory");
            });
            capture(context, "sao-block-chest");
            close(context);
            context.runOnClient(client -> BlockFloatingUi.testClock(null));

            Block[] cases = {Blocks.ENDER_CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.SHULKER_BOX, Blocks.HOPPER,
                    Blocks.DISPENSER, Blocks.DROPPER, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
                    Blocks.CRAFTING_TABLE, Blocks.ANVIL, Blocks.GRINDSTONE, Blocks.SMITHING_TABLE,
                    Blocks.STONECUTTER, Blocks.ENCHANTING_TABLE, Blocks.BREWING_STAND, Blocks.BEACON,
                    Blocks.LOOM, Blocks.CARTOGRAPHY_TABLE, Blocks.CRAFTER};
            for (var block : cases) {
                place(context, world, position, block);
                open(context, position);
                context.waitFor(client -> BlockFloatingUi.ready(client.gui.screen()));
                context.runOnClient(client -> {
                    var screen = (AbstractContainerScreen<?>) client.gui.screen();
                    require(screen.getMenu() == client.player.containerMenu, "Animation replaced the native container");
                    require(!screen.getMenu().slots.isEmpty(), "Native container lost its slots");
                    require(FlatContainerUi.skinned(screen), "Missing flat adapter: " + block);
                    for (var slot : screen.getMenu().slots) if (slot.container == client.player.getInventory())
                        require(slot.x >= FlatContainerLayout.playerX(FlatContainerLayout.workWidth(((ContainerScreenAccessor) screen).saoui$width())), "Player slots were not moved to the right panel");
                });
                if (block == Blocks.FURNACE) {
                    world.getServer().runOnServer(server -> {
                        var player = server.getPlayerList().getPlayers().getFirst();
                        var furnace = (Container) player.level().getBlockEntity(position);
                        furnace.setItem(0, new ItemStack(Items.RAW_IRON));
                        furnace.setItem(1, new ItemStack(Items.COAL));
                    });
                    context.waitFor(client -> ((AbstractFurnaceMenu) client.player.containerMenu).isLit());
                    capture(context, "sao-block-furnace");
                } else if (block == Blocks.CRAFTING_TABLE) {
                    world.getServer().runOnServer(server -> {
                        var player = server.getPlayerList().getPlayers().getFirst();
                        var menu = (CraftingMenu) player.containerMenu;
                        menu.getInputGridSlots().get(0).setByPlayer(new ItemStack(Items.OAK_PLANKS));
                        menu.getInputGridSlots().get(3).setByPlayer(new ItemStack(Items.OAK_PLANKS));
                        menu.broadcastChanges();
                    });
                    context.waitFor(client -> client.player.containerMenu.getSlot(0).getItem().is(Items.STICK));
                    capture(context, "sao-block-crafting");
                    clickSlot(context, 0, InputConstants.MOUSE_BUTTON_LEFT);
                    require(context.computeOnClient(client -> client.player.containerMenu.getCarried().getCount() == 4),
                            "Native crafting result pickup failed: cursor="+context.computeOnClient(client -> client.player.containerMenu.getCarried().toString()));
                } else if (block == Blocks.ANVIL) {
                    setInputs(world, new ItemStack(Items.DIAMOND_SWORD));
                    context.waitFor(client -> client.player.containerMenu.getSlot(0).hasItem());
                    context.runOnClient(client -> {
                        var edit = SettingsNavigation.widgets(client.gui.screen()).stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).findFirst().orElseThrow();
                        edit.setValue("Elucidator"); // Native responder sends the real rename packet.
                    });
                    context.waitFor(client -> client.player.containerMenu.getSlot(2).getItem().getHoverName().getString().equals("Elucidator"));
                    capture(context, "sao-block-anvil");
                } else if (block == Blocks.STONECUTTER) {
                    setInputs(world, new ItemStack(Items.STONE, 12));
                    context.waitFor(client -> ((StonecutterMenu)client.player.containerMenu).getNumberOfVisibleRecipes() > 0);
                    clickPoint(context, 59, 22);
                    context.waitFor(client -> client.player.containerMenu.getSlot(1).hasItem());
                    capture(context, "sao-block-stonecutter");
                    clickSlot(context, 1, InputConstants.MOUSE_BUTTON_LEFT);
                    require(context.computeOnClient(client -> !client.player.containerMenu.getCarried().isEmpty()), "Stonecutter recipe result was not usable");
                } else if (block == Blocks.LOOM) {
                    setInputs(world, new ItemStack(Items.BANNER.white()), new ItemStack(Items.DYE.red()));
                    context.waitFor(client -> !((LoomMenu)client.player.containerMenu).getSelectablePatterns().isEmpty());
                    clickPoint(context, 67, 20);
                    context.waitFor(client -> ((LoomMenu)client.player.containerMenu).getResultSlot().hasItem());
                    capture(context, "sao-block-loom");
                } else if (block == Blocks.SMITHING_TABLE) {
                    setInputs(world, new ItemStack(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE), new ItemStack(Items.DIAMOND_SWORD), new ItemStack(Items.NETHERITE_INGOT));
                    context.waitFor(client -> client.player.containerMenu.getSlot(3).getItem().is(Items.NETHERITE_SWORD));
                    capture(context, "sao-block-smithing");
                } else if (block == Blocks.GRINDSTONE) {
                    var damaged = new ItemStack(Items.IRON_SWORD); damaged.setDamageValue(100);
                    setInputs(world, damaged, damaged.copy());
                    context.waitFor(client -> client.player.containerMenu.getSlot(2).hasItem());
                    capture(context, "sao-block-grindstone");
                } else if (block == Blocks.ENCHANTING_TABLE) {
                    world.getServer().runOnServer(server -> server.getPlayerList().getPlayers().getFirst().giveExperienceLevels(60));
                    setInputs(world, new ItemStack(Items.DIAMOND_SWORD), new ItemStack(Items.LAPIS_LAZULI, 32));
                    context.waitFor(client -> ((EnchantmentMenu)client.player.containerMenu).costs[0] > 0);
                    capture(context, "sao-block-enchanting");
                    clickPoint(context, 100, 22);
                    context.waitFor(client -> client.player.containerMenu.getSlot(0).getItem().isEnchanted());
                } else if (block == Blocks.BREWING_STAND) {
                    world.getServer().runOnServer(server -> {
                        var player = server.getPlayerList().getPlayers().getFirst();
                        var stand = (Container)player.level().getBlockEntity(position);
                        stand.setItem(0, net.minecraft.world.item.alchemy.PotionContents.createItemStack(Items.POTION, net.minecraft.world.item.alchemy.Potions.WATER));
                        stand.setItem(3, new ItemStack(Items.NETHER_WART)); stand.setItem(4, new ItemStack(Items.BLAZE_POWDER));
                    });
                    context.waitFor(client -> ((BrewingStandMenu)client.player.containerMenu).getBrewingTicks() > 0);
                    capture(context, "sao-block-brewing");
                } else if (block == Blocks.CRAFTER) {
                    clickSlot(context, 0, InputConstants.MOUSE_BUTTON_LEFT);
                    context.waitFor(client -> ((CrafterMenu)client.player.containerMenu).isSlotDisabled(0));
                    capture(context, "sao-block-crafter");
                } else if (block == Blocks.BEACON) {
                    world.getServer().runOnServer(server -> {
                        var player = server.getPlayerList().getPlayers().getFirst();
                        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++)
                            player.level().setBlockAndUpdate(position.offset(dx, -1, dz), Blocks.IRON_BLOCK.defaultBlockState());
                        player.containerMenu.getSlot(0).setByPlayer(new ItemStack(Items.EMERALD));
                        player.containerMenu.broadcastChanges();
                    });
                    context.waitFor(client -> ((BeaconMenu)client.player.containerMenu).getLevels() >= 1);
                    clickPoint(context, 64, 33);
                    require(context.computeOnClient(client -> SettingsNavigation.widgets(client.gui.screen()).stream().filter(AbstractWidget.class::isInstance)
                            .map(AbstractWidget.class::cast).anyMatch(widget -> widget.active
                                    && widget.getX() == ((ContainerScreenAccessor)client.gui.screen()).saoui$left() + 164
                                    && widget.getY() == ((ContainerScreenAccessor)client.gui.screen()).saoui$top() + 107)),
                            "Beacon confirmation did not enable after payment and effect selection");
                    capture(context, "sao-block-beacon");
                } else if (block == Blocks.CARTOGRAPHY_TABLE) {
                    world.getServer().runOnServer(server -> {
                        var player = server.getPlayerList().getPlayers().getFirst();
                        var map = net.minecraft.world.item.MapItem.create(player.level(), position.getX(), position.getZ(), (byte)0, true, false);
                        var data = net.minecraft.world.item.MapItem.getSavedData(map, player.level());
                        for (int x = 0; x < 128; x++) for (int y = 0; y < 128; y++)
                            data.setColor(x, y, (byte)(Math.abs(x - y) < 12 ? 50 : (x / 16 + y / 16) % 2 == 0 ? 6 : 10));
                        player.connection.send(new net.minecraft.network.protocol.game.ClientboundMapItemDataPacket(
                                map.get(net.minecraft.core.component.DataComponents.MAP_ID), (byte)0, false, java.util.List.of(),
                                new net.minecraft.world.level.saveddata.maps.MapItemSavedData.MapPatch(0, 0, 128, 128, data.colors)));
                        player.containerMenu.getSlot(0).setByPlayer(map);
                        player.containerMenu.getSlot(1).setByPlayer(new ItemStack(Items.PAPER));
                        player.containerMenu.broadcastChanges();
                    });
                    context.waitFor(client -> client.player.containerMenu.getSlot(2).hasItem()
                            && net.minecraft.world.item.MapItem.getSavedData(client.player.containerMenu.getSlot(0).getItem(), client.level) != null);
                    capture(context, "sao-block-cartography");
                }
                if (block == Blocks.CRAFTING_TABLE) {
                    // Put the cursor away, then exercise the real recipe-book toggle and the right panel with it open.
                    clickSlot(context, 10, InputConstants.MOUSE_BUTTON_LEFT);
                    context.runOnClient(client -> { var book = ((RecipeScreenAccessor)client.gui.screen()).saoui$book(); if (book.isVisible()) book.toggleVisibility(); });
                    context.waitTick();
                    clickPoint(context, 202, 16);
                    context.waitTick();
                    require(context.computeOnClient(client -> ((RecipeScreenAccessor)client.gui.screen()).saoui$book().isVisible()), "Recipe drawer failed to open");
                    context.runOnClient(client -> {
                        var book = (io.github.saoui.mixin.RecipeBookAccessor)((RecipeScreenAccessor)client.gui.screen()).saoui$book();
                        int row = 0;
                        for (var tab : book.saoui$tabs()) if (tab.visible) {
                            require(tab.getX() == book.saoui$x() - 30 && tab.getY() == book.saoui$y() + 3 + row++ * 27,
                                    "Recipe categories escaped the relocated drawer: " + tab.getX() + "," + tab.getY() + " vs " + book.saoui$x() + "," + book.saoui$y());
                        }
                        require(row > 0, "Recipe category regression did not exercise any visible tabs");
                    });
                    capture(context, "sao-block-recipe-drawer");
                    clickSlot(context, 10, InputConstants.MOUSE_BUTTON_LEFT);
                    require(context.computeOnClient(client -> client.player.containerMenu.getCarried().getCount() == 4), "Recipe drawer blocked the new backpack slots");
                }
                ServerPacketBarrier.await(context);
                world.getServer().runOnServer(server -> {
                    var player = server.getPlayerList().getPlayers().getFirst();
                    for (var slot : player.containerMenu.slots) if (slot.container == player.getInventory())
                        require(slot.x < 210, "Client layout mutated server slot geometry");
                });
                close(context);
                if (block == Blocks.CRAFTING_TABLE) world.getServer().runOnServer(server ->
                        require(server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.STICK) == 4,
                                "Closing the workbench did not preserve its crafted cursor stack"));
            }

            place(context, world, position, Blocks.CHEST);
            world.getServer().runOnServer(server -> {
                var level = server.getPlayerList().getPlayers().getFirst().level();
                level.setBlockAndUpdate(position, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH).setValue(ChestBlock.TYPE, ChestType.LEFT));
                level.setBlockAndUpdate(position.east(), Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, Direction.NORTH).setValue(ChestBlock.TYPE, ChestType.RIGHT));
            });
            context.waitTicks(3);
            open(context, position);
            context.waitFor(client -> BlockFloatingUi.ready(client.gui.screen()));
            require(context.computeOnClient(client -> (ContainerCraftingState.get(client.player.containerMenu)==null?client.player.containerMenu.slots.size():ContainerCraftingState.get(client.player.containerMenu).base)) == 90,
                    "Double chest did not retain all 54+36 slots");
            context.runOnClient(client -> SaoUiClient.config().parallaxStrength = 2);
            context.getInput().setCursorPos(0, 0);
            context.waitTicks(10);
            context.runOnClient(client -> {
                var screen = client.gui.screen();
                var bounds = FlatContainerUi.bounds(screen);
                var frame = BlockFloatingUi.frame(screen);
                require(frame.screenY(bounds.y()) >= 0
                        && frame.screenY(bounds.y() + bounds.height()) + 4 <= screen.height
                        && frame.screenX(bounds.x()) >= 0
                        && frame.screenX(bounds.x() + bounds.width()) + 4 <= screen.width,
                        "Maximum parallax clipped the double chest border");
            });
            capture(context, "sao-block-double-chest");
            close(context);
            context.runOnClient(client -> SaoUiClient.config().blockUiEnabled = false);
            place(context, world, position, Blocks.BARREL);
            context.getInput().pressMouse(InputConstants.MOUSE_BUTTON_RIGHT);
            context.waitForScreen(AbstractContainerScreen.class);
            require(!context.computeOnClient(client -> BlockFloatingUi.active(client.gui.screen())), "Block UI disable switch was ignored");
            close(context);
            context.runOnClient(client -> SaoUiClient.config().blockUiEnabled = true);
            context.getInput().pressKey(InputConstants.KEY_E);
            context.waitForScreen(InventoryScreen.class);
            require(!context.computeOnClient(client -> BlockFloatingUi.active(client.gui.screen())), "Player inventory inherited a block animation");
            close(context);
            SaoUiClient.LOGGER.info("SAO block UI passed: 23 block variants, flat adapters, client-only geometry, recipe drawer, chest sync, crafting, rename, smithing, stonecutting, enchanting, brewing, beacon, loom, maps and crafter");
        } finally {
            context.runOnClient(client -> { BlockFloatingUi.testClock(null); SaoUiClient.config().blockUiEnabled = true;
                SaoUiClient.config().parallaxStrength = 1; });
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    private static void capture(ClientGameTestContext context, String name) {
        context.runOnClient(client -> { client.gui.toastManager().clear(); client.gui.hud.getChat().clearMessages(true); });
        context.waitTick();
        context.takeScreenshot(name);
    }

    static void setInputs(TestSingleplayerContext world, ItemStack... stacks) {
        world.getServer().runOnServer(server -> {
            var menu = server.getPlayerList().getPlayers().getFirst().containerMenu;
            for (int i = 0; i < stacks.length; i++) menu.getSlot(i).setByPlayer(stacks[i]);
            menu.broadcastChanges();
        });
    }

    private static void clickPoint(ClientGameTestContext context, int x, int y) {
        double[] raw = context.computeOnClient(client -> {
            var screen = client.gui.screen(); var a = (ContainerScreenAccessor)screen;
            var frame = BlockFloatingUi.frame(screen); var window = client.getWindow();
            return new double[]{frame.screenX(a.saoui$left() + x) * window.getScreenWidth() / screen.width,
                    frame.screenY(a.saoui$top() + y) * window.getScreenHeight() / screen.height};
        });
        context.getInput().setCursorPos(raw[0], raw[1]); context.waitTick();
        context.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT); context.waitTick();
    }

    static void place(ClientGameTestContext context, TestSingleplayerContext world, BlockPos position, Block block) {
        world.getServer().runOnServer(server -> {
            var level = server.getPlayerList().getPlayers().getFirst().level();
            if (level.getBlockEntity(position) instanceof Container old) old.clearContent();
            level.setBlockAndUpdate(position, Blocks.AIR.defaultBlockState());
            level.setBlockAndUpdate(position.east(), Blocks.AIR.defaultBlockState());
            level.setBlockAndUpdate(position.below(), Blocks.STONE.defaultBlockState());
            level.setBlockAndUpdate(position.above(), Blocks.AIR.defaultBlockState());
            level.setBlockAndUpdate(position, block.defaultBlockState());
        });
        context.waitFor(client -> client.level.getBlockState(position).is(block));
        context.getInput().lookAt(position);
        context.waitTicks(2);
    }

    static void open(ClientGameTestContext context, BlockPos position) {
        context.getInput().lookAt(position);
        context.waitTicks(2);
        context.getInput().pressMouse(InputConstants.MOUSE_BUTTON_RIGHT);
        context.waitForScreen(AbstractContainerScreen.class);
        require(context.computeOnClient(client -> BlockFloatingUi.active(client.gui.screen())),
                "Native block screen was not animated: " + position);
    }

    static void close(ClientGameTestContext context) {
        context.getInput().pressKey(InputConstants.KEY_ESCAPE);
        context.waitForScreen(null);
        context.waitTick();
    }

    static void clickSlot(ClientGameTestContext context, int index, int button) {
        clickSlot(context, index, button, 0);
    }

    static void clickSlot(ClientGameTestContext context, int index, int button, int modifiers) {
        double[] raw = context.computeOnClient(client -> {
            var screen = (AbstractContainerScreen<?>) client.gui.screen();
            var bounds = (ContainerScreenAccessor) screen;
            var slot = screen.getMenu().getSlot(index);
            var frame = BlockFloatingUi.frame(screen);
            var window = client.getWindow();
            return new double[]{frame.screenX(bounds.saoui$left() + slot.x + 8) * window.getScreenWidth() / screen.width,
                    frame.screenY(bounds.saoui$top() + slot.y + 8) * window.getScreenHeight() / screen.height};
        });
        context.getInput().setCursorPos(raw[0], raw[1]);
        context.waitTick();
        // Fabric's TestInput currently hardcodes modifiers=0; dispatch real MouseHandler events instead.
        var held = new java.util.concurrent.atomic.AtomicReference<BlockSurfaceMotion.Frame>();
        context.runOnClient(client -> {
            ((MouseTestAccessor)client.mouseHandler).saoui$button(client.getWindow().handle(), new net.minecraft.client.input.MouseButtonInfo(button, modifiers), 1);
            if (BlockFloatingUi.ready(client.gui.screen())) held.set(BlockFloatingUi.frame(client.gui.screen()));
        });
        context.waitTick();
        context.runOnClient(client -> {
            if (held.get() != null) require(held.get().equals(BlockFloatingUi.frame(client.gui.screen())), "Parallax moved the panel during an item gesture");
            ((MouseTestAccessor)client.mouseHandler).saoui$button(client.getWindow().handle(), new net.minecraft.client.input.MouseButtonInfo(button, modifiers), 0);
        });
        context.waitTick();
    }
}
