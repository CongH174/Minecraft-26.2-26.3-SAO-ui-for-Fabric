package io.github.saoui.testmixin;

import io.github.saoui.ServerPacketBarrier;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundAwardStatsPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Marks the native reply after queued serverbound container actions have run. Test sources only. */
@Mixin(ClientPacketListener.class)
public abstract class StatsReplyMixin {
    @Inject(method = "handleAwardStats", at = @At("RETURN"))
    private void saoui$reply(ClientboundAwardStatsPacket packet, CallbackInfo ci) { ServerPacketBarrier.replies.incrementAndGet(); }
}
