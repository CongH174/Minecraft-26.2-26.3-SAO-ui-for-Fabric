package io.github.saoui.testmixin;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.world.item.CreativeModeTab;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(CreativeModeInventoryScreen.class)
public interface CreativeTestAccessor {
    @Invoker("getTabX") int saoui$tabX(CreativeModeTab tab);
    @Invoker("getTabY") int saoui$tabY(CreativeModeTab tab);
    @Invoker("selectTab") void saoui$select(CreativeModeTab tab);
}
