from pathlib import Path
import argparse,hashlib,io,json,zipfile
ROOT=Path(__file__).resolve().parent
RELEASE=json.loads((ROOT/'release.json').read_text(encoding='utf-8'))
VERSION=RELEASE['version']
def metadata(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:return json.loads(z.read('fabric.mod.json'))
def payload(data,mc):
    source=metadata(data)
    assert source['id']=='saoui' and source['depends']['minecraft']=='~'+mc
    result=io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(data)) as src,zipfile.ZipFile(result,'w',zipfile.ZIP_DEFLATED) as dst:
        assert not any('GameTest' in n or 'testmixin/' in n or 'UniversalTestMenus' in n or 'ServerPacketBarrier' in n for n in src.namelist())
        for n in sorted(src.namelist()):
            value=src.read(n)
            if n=='fabric.mod.json':
                source['id']='saoui_runtime';source['version']=VERSION+'-mc'+mc
                source['name']='SAO UI Runtime '+mc
                value=(json.dumps(source,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
            dst.writestr(n,value)
    return result.getvalue()
def default_input(mc):
    project=ROOT/RELEASE['targets'][mc]['project']
    props=dict(line.split('=',1) for line in (project/'gradle.properties').read_text(encoding='utf-8').splitlines() if '=' in line)
    return project/'build/libs'/('sao-ui-'+props['mod_version']+'.jar')
def assemble(inputs,out):
    nested={mc:payload(p.read_bytes(),mc) for mc,p in inputs.items()}
    meta={'schemaVersion':1,'id':'saoui','version':VERSION,'name':'SAO UI',
        'description':'SAO UI with automatic Minecraft 26.2 / 26.3 runtime selection.',
        'environment':'*','license':'GPL-3.0-only',
        'jars':[{'file':'META-INF/jars/saoui-runtime-'+mc+'.jar'} for mc in nested],
        'depends':{'fabricloader':'>='+RELEASE['loader'],'minecraft':['~26.2','~26.3'],'java':'>=25','fabric-api':'>=0.152.1','saoui_runtime':'*'}}
    out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('fabric.mod.json',json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
        for mc,data in nested.items():z.writestr('META-INF/jars/saoui-runtime-'+mc+'.jar',data)
        for name in ['LICENSE','ASSETS.md']:
            z.writestr(name,(ROOT/name).read_bytes())
        z.writestr('saoui-runtimes.json',json.dumps({'version':VERSION,'runtimes':{mc:{'sha256':hashlib.sha256(data).hexdigest(),'minecraft':'~'+mc} for mc,data in nested.items()}},indent=2)+'\n')
    print(json.dumps({'jar':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser(description='Assemble one SAO UI jar from the two API-specific builds.')
    p.add_argument('--input262',type=Path);p.add_argument('--input263',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args()
    assemble({'26.2':a.input262 or default_input('26.2'),'26.3':a.input263 or default_input('26.3')},a.out or ROOT/'dist'/('sao-ui-'+VERSION+'+mc26.2-26.3.jar'))
