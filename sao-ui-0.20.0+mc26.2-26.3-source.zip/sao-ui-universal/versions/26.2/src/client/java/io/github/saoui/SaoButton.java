package io.github.saoui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** Native button input, focus, click sound and narration with SAO presentation. */
public final class SaoButton extends Button {
    private final Identifier icon;
    private final Component displayLabel;

    public SaoButton(int x, int y, int width, int height, Component label, String icon, Runnable action) {
        this(x, y, width, height, label, null, icon, action);
    }

    public SaoButton(int x, int y, int width, int height, Component label, Component displayLabel, String icon, Runnable action) {
        super(x, y, width, height, label, button -> action.run(), DEFAULT_NARRATION);
        this.icon = icon == null ? null : SaoUiClient.id("textures/sao/menu/icons/" + icon + ".png");
        this.displayLabel = displayLabel;
    }

    @Override
    protected void extractContents(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        boolean highlighted = isHoveredOrFocused();
        int x = getX(), y = getY();
        g.fill(x, y, x + width, y + height, highlighted ? ThemePalette.accent() : ThemePalette.cell());
        g.fill(x, y, x + 3, y + height, highlighted ? 0xFFFFD580 : 0xFF909CA5);
        g.fill(x + 3, y, x + width, y + 1, 0xAAFFFFFF);
        int textX = x + 13;
        if (icon != null) {
            UiSprites.icon(g, icon, x + 10, y + (height - 18) / 2, 18);
            textX = x + 38;
        }
        var font = Minecraft.getInstance().font;
        String label = (displayLabel == null ? getMessage() : displayLabel).getString();
        if (icon == null && width < 80) {
            label = font.plainSubstrByWidth(label, width - 8);
            textX = x + (width - font.width(label)) / 2;
        } else label = font.plainSubstrByWidth(label, Math.max(1, width - (textX - x) - 8));
        g.text(font, label,
                textX, y + (height - font.lineHeight) / 2, active ? (highlighted ? ThemePalette.onAccent() : ThemePalette.ink()) : 0xFF79828A, false);
    }
}
