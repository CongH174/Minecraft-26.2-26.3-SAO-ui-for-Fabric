package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Independent nested draft: preview is local until both this page and its parent are saved. */
public final class SaoThemeSettingsScreen extends Screen {
    private final Screen parent;
    private final Consumer<UiTheme> apply;
    private UiTheme draft;
    private int target;
    private String editing;
    private EditBox hex;
    private SaoButton done, fontMode;
    private final List<RgbSlider> sliders=new ArrayList<>();
    private int left,top;
    public SaoThemeSettingsScreen(Screen parent,UiTheme initial,Consumer<UiTheme> apply) {
        super(Component.translatable("settings.saoui.theme"));
        this.parent=parent;this.apply=apply;draft=initial.copy();editing=UiTheme.hex(draft.background);
    }
    private int current(){return target==1?draft.accent:target==2?draft.font:draft.background;}
    private void setCurrent(int rgb){if(target==1)draft.accent=rgb;else if(target==2){draft.font=rgb;draft.customFont=true;}else draft.background=rgb;}
    private void select(int next){target=next;editing=UiTheme.hex(current());rebuildWidgets();}
    @Override protected void init(){
        left=(width-360)/2;top=Math.max(4,(height-222)/2);sliders.clear();
        addRenderableWidget(new SaoButton(left,top+22,53,20,Component.translatable("settings.saoui.theme.background"),null,()->select(0)));
        addRenderableWidget(new SaoButton(left+57,top+22,53,20,Component.translatable("settings.saoui.theme.accent"),null,()->select(1)));
        addRenderableWidget(new SaoButton(left+114,top+22,54,20,Component.translatable("settings.saoui.theme.font"),null,()->select(2)));
        fontMode=addRenderableWidget(new SaoButton(left+184,top+160,176,20,Component.translatable("settings.saoui.theme.font_mode",Component.translatable(draft.customFont?"settings.saoui.theme.custom":"settings.saoui.theme.auto")),null,()->{draft.customFont=!draft.customFont;rebuildWidgets();}));
        hex=addRenderableWidget(new EditBox(font,left,top+51,168,20,Component.translatable("settings.saoui.theme.hex")));
        hex.setMaxLength(7);hex.setValue(editing);hex.setHint(Component.literal("#RRGGBB"));
        hex.setResponder(value->{editing=value;Integer rgb=UiTheme.parse(value);if(rgb!=null)setCurrent(rgb);sync();});
        for(int i=0;i<3;i++){var slider=new RgbSlider(left,top+80+i*25,i);sliders.add(slider);addRenderableWidget(slider);}
        addRenderableWidget(new SaoButton(left,top+160,168,20,Component.translatable("settings.saoui.theme.reset"),null,()->{
            draft=new UiTheme();editing=UiTheme.hex(current());rebuildWidgets();
        }));
        done=addRenderableWidget(new SaoButton(left,top+187,168,20,Component.translatable("gui.done"),null,()->{if(UiTheme.parse(editing)!=null){apply.accept(draft.copy());onClose();}}));
        addRenderableWidget(new SaoButton(left+184,top+187,176,20,Component.translatable("gui.cancel"),null,this::onClose));
        sync();
    }
    private void sync(){
        boolean valid=UiTheme.parse(editing)!=null;
        if(fontMode!=null)fontMode.setMessage(Component.translatable("settings.saoui.theme.font_mode",Component.translatable(draft.customFont?"settings.saoui.theme.custom":"settings.saoui.theme.auto")));
        if(hex!=null)hex.setTextColor(valid?0xFFFFFFFF:0xFFFF7777);
        if(done!=null)done.active=valid;
        for(var slider:sliders)slider.sync();
    }
    private final class RgbSlider extends AbstractSliderButton {
        private final int channel;
        RgbSlider(int x,int y,int channel){super(x,y,168,20,Component.empty(),0);this.channel=channel;sync();}
        void sync(){value=(current()>>(16-channel*8)&255)/255.0;updateMessage();}
        @Override protected void updateMessage(){setMessage(Component.literal(new String[]{"R","G","B"}[channel]+": "+Math.round(value*255)));}
        @Override protected void applyValue(){
            int shift=16-channel*8;setCurrent(current()&~(255<<shift)|(int)Math.round(value*255)<<shift);
            editing=UiTheme.hex(current());hex.setValue(editing);sync();
        }
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float delta){
        g.fill(0,0,width,height,0xED101820);
        g.text(font,title,left,top,0xFFF3A72E,false);
        g.text(font,Component.translatable(target==1?"settings.saoui.theme.accent":target==2?"settings.saoui.theme.font":"settings.saoui.theme.background"),left+184,top+28,0xFFE2E9E7,false);
        int x=left+184,y=top+51,bg=0xFF000000|draft.background,ink=draft.customFont?0xFF000000|draft.font:UiTheme.text(bg),accent=0xFF000000|draft.accent;
        g.fill(x+3,y+4,x+179,y+104,0x40000000);g.fill(x,y,x+176,y+100,bg);
        g.fill(x,y,x+3,y+30,accent);g.fill(x,y,x+176,y+1,UiTheme.mix(bg,ink,.15));
        g.text(font,Component.translatable("settings.saoui.theme.preview"),x+14,y+12,ink,false);
        g.fill(x+12,y+33,x+164,y+34,UiTheme.mix(bg,ink,.3));
        for(int i=0;i<4;i++){
            g.fill(x+14+i*38,y+40,x+46+i*38,y+72,i==0?accent:UiTheme.mix(bg,ink,.3));
            g.fill(x+15+i*38,y+41,x+45+i*38,y+71,UiTheme.mix(bg,ink,.08));
        }
        g.fill(x+14,y+78,x+162,y+96,accent);
        g.text(font,Component.translatable("settings.saoui.theme.sample"),x+24,y+83,draft.customFont?ink:UiTheme.text(accent),false);
        if(UiTheme.parse(editing)==null)g.text(font,Component.translatable("settings.saoui.theme.invalid"),x,top+166,0xFFFF7777,false);
        super.extractRenderState(g,mouseX,mouseY,delta);
        g.text(font,Component.translatable("settings.saoui.hud_draft_hint"),left,top+213,0xFFB6C3CD,false);
    }
    @Override public boolean isPauseScreen(){return false;}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
}
