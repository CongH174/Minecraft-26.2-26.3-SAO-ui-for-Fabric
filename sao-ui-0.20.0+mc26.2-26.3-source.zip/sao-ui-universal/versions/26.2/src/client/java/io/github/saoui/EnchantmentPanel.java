package io.github.saoui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/** Independently scrollable detail module. Text is wrapped before projection, never truncated. */
final class EnchantmentPanel {
    static final int X=322,Y=-124,W=222,H=252,VISIBLE_LINES=15;
    private record Row(String text,boolean heading) {}
    private final List<Row> lines=new ArrayList<>();
    private ItemStack cached=ItemStack.EMPTY;
    private boolean built,preview;
    private net.minecraft.core.RegistryAccess cachedRegistry;
    private net.minecraft.locale.Language cachedLanguage;
    private boolean cachedDescriptions,cachedEffects,cachedLore;
    private int scroll;
    boolean scroll(double x,double y,double amount,MenuProjection p){
        var b=FloatingDraw.bounds(p,X,Y,W,H);
        if(!SaoUiClient.config().enchantmentDetailsVisible||x<b.left()||x>=b.left()+b.width()||y<b.top()||y>=b.top()+b.height())return false;
        scroll=Math.clamp(scroll-(int)Math.copySign(3,amount),0,Math.max(0,lines.size()-VISIBLE_LINES));return true;
    }
    private void add(String text,boolean heading){
        // Minecraft's splitter preserves CJK and resource-pack font metrics.
        for(var part:Minecraft.getInstance().font.getSplitter().splitLines(Component.literal(text),W-32,net.minecraft.network.chat.Style.EMPTY))
            lines.add(new Row(part.getString(),heading));
    }
    private void enchant(Holder<Enchantment> enchantment,int level,boolean armor){
        add(Enchantment.getFullname(enchantment,level).getString(),true);
        var id=enchantment.unwrapKey().map(k->k.identifier()).orElse(null);
        for(var detail:EnchantmentDetails.describe(enchantment,level,armor,SaoUiClient.config(),Minecraft.getInstance().player.registryAccess()))add(detail.getString(),false);
        if(id!=null&&(!id.getNamespace().equals("minecraft")||!EnchantmentFacts.IDS.contains(id.getPath())))add(id.toString(),false);
        lines.add(new Row("",false));
    }
    private void refresh(ItemStack stack){
        var registry=Minecraft.getInstance().player.registryAccess();
        var language=net.minecraft.locale.Language.getInstance();
        var config=SaoUiClient.config();
        if(built&&ItemStack.matches(cached,stack)&&cachedRegistry==registry&&cachedLanguage==language&&cachedDescriptions==config.enchantmentDescriptions&&cachedEffects==config.syncedEnchantmentEffects&&cachedLore==config.serverEnchantmentLore)return;
        cachedRegistry=registry;cachedLanguage=language;cachedDescriptions=config.enchantmentDescriptions;cachedEffects=config.syncedEnchantmentEffects;cachedLore=config.serverEnchantmentLore;
        built=true;cached=stack.copy();scroll=0;lines.clear();preview=false;
        if(stack.isEmpty())return;
        var itemLore=ServerItemDescriptions.describe(stack,config);
        if(!itemLore.isEmpty()){
            add(Component.translatable("saoui.enchant.item_lore").getString(),true);
            for(var line:itemLore)add(line.getString(),false);
            add(Component.translatable("saoui.enchant.item_lore_source").getString(),false);
            lines.add(new Row("",false));
        }
        boolean armor=stack.is(ItemTags.ARMOR_ENCHANTABLE);
        var existing=stack.getEnchantments();var stored=stack.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY);
        if(!existing.isEmpty()||!stored.isEmpty()){
            existing.entrySet().stream().sorted(Comparator.comparing(e->e.getKey().value().description().getString()))
                    .forEach(e->enchant(e.getKey(),e.getIntValue(),armor));
            if(!stored.isEmpty()){
                add(Component.translatable("saoui.enchant.stored").getString(),true);
                stored.entrySet().stream().sorted(Comparator.comparing(e->e.getKey().value().description().getString()))
                        .forEach(e->enchant(e.getKey(),e.getIntValue(),false));
            }
        }else{
            preview=true;
            var player=Minecraft.getInstance().player;
            player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).listElements()
                    .filter(e->stack.is(Items.BOOK)||e.value().isSupportedItem(stack))
                    .sorted(Comparator.comparing(e->e.value().description().getString()))
                    .forEach(e->enchant(e,e.value().getMaxLevel(),armor));
        }
    }
    void render(GuiGraphicsExtractor g,MenuProjection p,ItemStack stack,double opacity){
        if(!SaoUiClient.config().enchantmentDetailsVisible)return;
        PlayerPanels.panel(g,p,X,Y,W*opacity,H,opacity);if(opacity<.65)return;
        refresh(stack);
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.title").getString(),X+14,Y+14,FloatingDraw.alpha(ThemePalette.ink(),opacity));
        String mode=Component.translatable(preview?"saoui.enchant.preview":"saoui.enchant.active").getString();
        FloatingDraw.text(g,p,mode,X+14,Y+30,FloatingDraw.alpha(ThemePalette.muted(),opacity));
        FloatingDraw.rect(g,p,X+14,Y+43,W-28,.8,FloatingDraw.alpha(ThemePalette.line(),opacity));
        for(int i=0;i<VISIBLE_LINES&&i+scroll<lines.size();i++){
            var row=lines.get(i+scroll);
            FloatingDraw.text(g,p,row.text(),X+14,Y+51+i*11,FloatingDraw.alpha(row.heading()?ThemePalette.accent():ThemePalette.ink(),opacity));
        }
        if(lines.isEmpty())FloatingDraw.text(g,p,Component.translatable("saoui.enchant.empty").getString(),X+14,Y+52,FloatingDraw.alpha(ThemePalette.muted(),opacity));
        if(lines.size()>VISIBLE_LINES){
            double thumb=165.0*VISIBLE_LINES/lines.size(),dy=(165-thumb)*scroll/(lines.size()-VISIBLE_LINES);
            FloatingDraw.rect(g,p,X+W-9,Y+49,2,165,FloatingDraw.alpha(ThemePalette.line(),opacity));
            FloatingDraw.rect(g,p,X+W-9,Y+49+dy,2,thumb,FloatingDraw.alpha(ThemePalette.accent(),opacity));
        }
        FloatingDraw.rect(g,p,X+14,Y+221,W-28,.8,FloatingDraw.alpha(ThemePalette.line(),opacity));
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.footer").getString(),X+14,Y+226,FloatingDraw.alpha(ThemePalette.muted(),opacity));
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.server_rules").getString(),X+14,Y+239,FloatingDraw.alpha(ThemePalette.muted(),opacity));
    }
}
