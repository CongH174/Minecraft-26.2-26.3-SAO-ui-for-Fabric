package io.github.saoui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;

/** Edits the parent's draft. Only the parent's Save commits these independent modules. */
final class SaoFeatureSettingsScreen extends Screen {
    private final Screen parent; private final SaoConfig draft;
    SaoFeatureSettingsScreen(Screen parent,SaoConfig draft){super(Component.translatable("settings.saoui.features"));this.parent=parent;this.draft=draft;}
    @Override protected void init(){
        int x=(width-280)/2,y=height/2-60;
        addRenderableWidget(new SaoButton(x,y,280,22,label("enchantments",draft.enchantmentDetailsVisible),null,()->{draft.enchantmentDetailsVisible=!draft.enchantmentDetailsVisible;rebuildWidgets();}));
        addRenderableWidget(new SaoButton(x,y+28,280,22,label("ipn",draft.ipnIntegration),null,()->{draft.ipnIntegration=!draft.ipnIntegration;rebuildWidgets();}));
        var craft=addRenderableWidget(new SaoButton(x,y+56,280,22,label("container_crafting",draft.containerCraftingVisible),null,()->{draft.containerCraftingVisible=!draft.containerCraftingVisible;rebuildWidgets();}));
        craft.setTooltip(Tooltip.create(Component.translatable("settings.saoui.container_crafting_hint")));
        addRenderableWidget(new SaoButton(x,y+96,280,22,Component.translatable("gui.back"),null,this::onClose));
    }
    private Component label(String key,boolean value){return Component.translatable("settings.saoui."+key,Component.translatable(value?"options.on":"options.off"));}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float delta){g.fill(0,0,width,height,0xDA101820);g.text(font,title,(width-280)/2,height/2-82,0xFFF3A72E,false);super.extractRenderState(g,x,y,delta);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
}
