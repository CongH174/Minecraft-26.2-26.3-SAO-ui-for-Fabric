package io.github.saoui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Four categories, then direct controls. The entire editor shares one unsaved draft. */
public final class SaoSettingsScreen extends Screen {
    enum Page {HOME,INTERFACE,HUD,COMPAT}
    private final Screen parent;
    private SaoConfig draft;
    private Page page=Page.HOME;
    private SaoSettingsList list;
    private SaoButton done,fontMode;
    private boolean saveFailed;
    private int colorTarget;
    private String editing;
    private EditBox hex;
    private final List<RgbSlider> rgb=new ArrayList<>();
    private double scroll;
    public SaoSettingsScreen(Screen parent){super(Component.translatable("screen.saoui.settings"));this.parent=parent;draft=SaoUiClient.config().copy();editing=UiTheme.hex(currentColor());}
    Page page(){return page;}
    List<AbstractWidget> options(){return list==null?List.of():list.widgets();}
    void reveal(AbstractWidget widget){if(list!=null)list.reveal(widget);}
    private void open(Page next){page=next;scroll=0;rebuildWidgets();}
    private void rebuild(){if(list!=null)scroll=list.scrollAmount();rebuildWidgets();}
    @Override protected void init(){
        list=null;hex=null;fontMode=null;rgb.clear();
        int panelWidth=Math.min(400,width-24),left=(width-panelWidth)/2,half=(panelWidth-8)/2;
        if(page==Page.HOME){
            int y=Math.max(45,height/2-48);
            addRenderableWidget(button("settings.saoui.category.interface",()->open(Page.INTERFACE))).setRectangle(half,22,left,y);
            addRenderableWidget(button("settings.saoui.category.hud",()->open(Page.HUD))).setRectangle(half,22,left+half+8,y);
            addRenderableWidget(button("settings.saoui.category.menu",()->minecraft.gui.setScreen(new SaoModuleSettingsScreen(this,draft,next->{draft.moduleOrder=next.moduleOrder;draft.hiddenModules=next.hiddenModules;draft.homeModule=next.homeModule;})))).setRectangle(half,22,left,y+28);
            addRenderableWidget(button("settings.saoui.category.compat",()->open(Page.COMPAT))).setRectangle(half,22,left+half+8,y+28);
            addRenderableWidget(button("settings.saoui.reset",()->{draft=new SaoConfig();editing=UiTheme.hex(currentColor());rebuild();})).setRectangle(panelWidth,22,left,y+64);
        } else {
            list=addRenderableWidget(new SaoSettingsList(minecraft,width,Math.max(40,height-82),38));
            switch(page){case INTERFACE->interfaceOptions();case HUD->hudOptions();case COMPAT->compatOptions();default->{}}
            list.setScrollAmount(scroll);
        }
        int footer=height-30;
        if(page==Page.HOME){done=addRenderableWidget(button("gui.done",this::save));done.setRectangle(half,20,left,footer);addRenderableWidget(button("gui.cancel",this::cancel)).setRectangle(half,20,left+half+8,footer);}
        else {int third=(panelWidth-16)/3;addRenderableWidget(button("gui.back",()->open(Page.HOME))).setRectangle(third,20,left,footer);done=addRenderableWidget(button("gui.done",this::save));done.setRectangle(third,20,left+third+8,footer);addRenderableWidget(button("gui.cancel",this::cancel)).setRectangle(third,20,left+2*(third+8),footer);}
        syncColors();
    }
    private void interfaceOptions(){
        list.row(slider("ui_scale",draft.uiScale,v->draft.uiScale=v),slider("opacity",draft.uiOpacity,v->draft.uiOpacity=v));
        list.row(slider("parallax",draft.parallaxStrength,v->draft.parallaxStrength=v),toggle("parallax_enabled",draft.parallaxEnabled,()->draft.parallaxEnabled=!draft.parallaxEnabled));
        list.row(slider("animation_speed",draft.animationSpeed,v->draft.animationSpeed=v),toggle("animations_enabled",draft.animationsEnabled,()->draft.animationsEnabled=!draft.animationsEnabled));
        list.row(slider("blur",draft.blurStrength,v->draft.blurStrength=v),toggle("blur_enabled",draft.blurEnabled,()->draft.blurEnabled=!draft.blurEnabled));
        list.row(toggle("armor_slots",draft.armorSlotsVisible,()->draft.armorSlotsVisible=!draft.armorSlotsVisible),toggle("crafting",draft.craftingVisible,()->draft.craftingVisible=!draft.craftingVisible));
        list.row(toggle("enchantments",draft.enchantmentDetailsVisible,()->draft.enchantmentDetailsVisible=!draft.enchantmentDetailsVisible),toggle("container_crafting",draft.containerCraftingVisible,()->draft.containerCraftingVisible=!draft.containerCraftingVisible));
        list.row(toggle("block_ui",draft.blockUiEnabled,()->draft.blockUiEnabled=!draft.blockUiEnabled),toggle("all_containers",draft.replaceAllContainers,()->draft.replaceAllContainers=!draft.replaceAllContainers));
        list.row(button("settings.saoui.container_rules",()->minecraft.gui.setScreen(new SaoContainerSettingsScreen(this,draft,next->draft.containers=next.containers))));
        list.drawing(18,(g,row)->g.text(font,Component.translatable("settings.saoui.theme"),row.getContentX(),row.getContentY()+3,0xFFFFCF70,false));
        list.row(button("settings.saoui.theme.background",()->selectColor(0)),button("settings.saoui.theme.accent",()->selectColor(1)),button("settings.saoui.theme.font",()->selectColor(2)));
        hex=new EditBox(font,0,0,196,20,Component.translatable("settings.saoui.theme.hex"));hex.setMaxLength(7);hex.setValue(editing);hex.setHint(Component.literal("#RRGGBB"));
        hex.setResponder(value->{editing=value;Integer color=UiTheme.parse(value);if(color!=null)setColor(color);syncColors();});
        fontMode=new SaoButton(0,0,196,20,Component.translatable("settings.saoui.theme.font_mode",Component.translatable(draft.theme.customFont?"settings.saoui.theme.custom":"settings.saoui.theme.auto")),null,()->{draft.theme.customFont=!draft.theme.customFont;rebuild();});
        list.row(hex,fontMode);
        for(int i=0;i<3;i++){var slider=new RgbSlider(i);rgb.add(slider);list.row(slider);}
        list.drawing(58,(g,row)->{int x=row.getContentX(),y=row.getContentY(),w=row.getContentWidth(),bg=0xFF000000|draft.theme.background,ink=draft.theme.customFont?0xFF000000|draft.theme.font:UiTheme.text(bg);g.fill(x,y,x+w,y+50,bg);g.fill(x,y,x+3,y+27,0xFF000000|draft.theme.accent);g.text(font,Component.translatable("settings.saoui.theme.preview"),x+12,y+10,ink,false);g.fill(x+12,y+27,x+w-12,y+43,0xFF000000|draft.theme.accent);g.text(font,Component.translatable("settings.saoui.theme.sample"),x+19,y+31,draft.theme.customFont?ink:UiTheme.text(draft.theme.accent),false);});
        list.row(button("settings.saoui.theme.reset",()->{draft.theme=new UiTheme();editing=UiTheme.hex(currentColor());rebuild();}));
    }
    private void hudOptions(){
        list.row(toggle("hud",draft.hudEnabled,()->draft.hudEnabled=!draft.hudEnabled),slider("scale",draft.scale,v->draft.scale=v));
        list.row(toggle("smooth",draft.smoothHealth,()->draft.smoothHealth=!draft.smoothHealth),slider("smoothing",draft.healthSmoothing,v->draft.healthSmoothing=v));
        list.row(new SaoButton(0,0,196,20,Component.translatable("settings.saoui.x",draft.x),null,()->{draft.x=draft.x>=100?0:draft.x+10;rebuild();}),new SaoButton(0,0,196,20,Component.translatable("settings.saoui.y",draft.y),null,()->{draft.y=draft.y>=100?0:draft.y+10;rebuild();}));
        list.row(bar("health",draft.hud.health,()->draft.hud.health=!draft.hud.health),bar("hide_vanilla_health",draft.hud.hideVanillaHealth,()->draft.hud.hideVanillaHealth=!draft.hud.hideVanillaHealth));
        list.row(bar("hunger",draft.hud.hunger,()->draft.hud.hunger=!draft.hud.hunger),bar("hide_vanilla_hunger",draft.hud.hideVanillaHunger,()->draft.hud.hideVanillaHunger=!draft.hud.hideVanillaHunger));
        list.row(bar("experience",draft.hud.experience,()->draft.hud.experience=!draft.hud.experience),bar("hide_vanilla_experience",draft.hud.hideVanillaExperience,()->draft.hud.hideVanillaExperience=!draft.hud.hideVanillaExperience));
        list.row(bar("armor",draft.hud.armor,()->draft.hud.armor=!draft.hud.armor),bar("hide_vanilla_armor",draft.hud.hideVanillaArmor,()->draft.hud.hideVanillaArmor=!draft.hud.hideVanillaArmor));
        list.row(bar("saturation",draft.hud.saturation,()->draft.hud.saturation=!draft.hud.saturation),bar("hide_vanilla_crosshair",draft.hud.hideVanillaCrosshair,()->draft.hud.hideVanillaCrosshair=!draft.hud.hideVanillaCrosshair));
        list.drawing(28,(g,row)->g.text(font,Component.translatable("settings.saoui.hotbar_kept"),row.getContentX(),row.getContentY()+4,0xFFB6C3CD,false));
    }
    private void compatOptions(){
        list.row(toggle("enchantment_descriptions",draft.enchantmentDescriptions,()->draft.enchantmentDescriptions=!draft.enchantmentDescriptions),toggle("synced_enchantment_effects",draft.syncedEnchantmentEffects,()->draft.syncedEnchantmentEffects=!draft.syncedEnchantmentEffects));
        list.row(toggle("server_enchantment_lore",draft.serverEnchantmentLore,()->draft.serverEnchantmentLore=!draft.serverEnchantmentLore));
        list.row(toggle("ipn",draft.ipnIntegration,()->draft.ipnIntegration=!draft.ipnIntegration),bar("saturation",draft.hud.saturation,()->draft.hud.saturation=!draft.hud.saturation));
        list.drawing(36,(g,row)->{g.text(font,Component.translatable(AppleSkinBridge.AVAILABLE?"settings.saoui.appleskin_ready":"settings.saoui.appleskin_missing"),row.getContentX(),row.getContentY()+2,0xFFFFDF64,false);g.text(font,font.plainSubstrByWidth(Component.translatable("settings.saoui.appleskin_sync").getString(),row.getContentWidth()),row.getContentX(),row.getContentY()+17,0xFFB6C3CD,false);});
    }
    private SaoButton button(String key,Runnable action){return new SaoButton(0,0,196,20,Component.translatable(key),null,action);}
    private SaoButton toggle(String key,boolean value,Runnable change){return toggleKey("settings.saoui."+key,value,change);}
    private SaoButton bar(String key,boolean value,Runnable change){return toggleKey("settings.saoui.bar."+key,value,change);}
    private SaoButton toggleKey(String key,boolean value,Runnable change){var button=new SaoButton(0,0,196,20,Component.translatable(key,Component.translatable(value?"options.on":"options.off")),null,()->{change.run();rebuild();});button.setTooltip(Tooltip.create(button.getMessage()));return button;}
    private SaoSlider slider(String key,float value,Consumer<Float> change){var slider=new SaoSlider(0,0,196,20,"settings.saoui."+key,value,change);slider.setTooltip(Tooltip.create(Component.translatable("settings.saoui."+key+"_hint")));return slider;}
    private int currentColor(){return colorTarget==1?draft.theme.accent:colorTarget==2?draft.theme.font:draft.theme.background;}
    private void setColor(int color){if(colorTarget==1)draft.theme.accent=color;else if(colorTarget==2){draft.theme.font=color;draft.theme.customFont=true;}else draft.theme.background=color;}
    private void selectColor(int target){colorTarget=target;editing=UiTheme.hex(currentColor());rebuild();}
    private void syncColors(){if(fontMode!=null)fontMode.setMessage(Component.translatable("settings.saoui.theme.font_mode",Component.translatable(draft.theme.customFont?"settings.saoui.theme.custom":"settings.saoui.theme.auto")));if(done!=null)done.active=UiTheme.parse(editing)!=null;if(hex!=null)hex.setTextColor(UiTheme.parse(editing)!=null?0xFFFFFFFF:0xFFFF7777);for(var slider:rgb)slider.sync();}
    private final class RgbSlider extends AbstractSliderButton {
        private final int channel;
        RgbSlider(int channel){super(0,0,196,20,Component.empty(),0);this.channel=channel;sync();}
        void sync(){value=(currentColor()>>(16-channel*8)&255)/255.0;updateMessage();}
        @Override protected void updateMessage(){setMessage(Component.literal(new String[]{"R","G","B"}[channel]+": "+Math.round(value*255)));}
        @Override protected void applyValue(){int shift=16-channel*8;setColor(currentColor()&~(255<<shift)|(int)Math.round(value*255)<<shift);editing=UiTheme.hex(currentColor());hex.setValue(editing);syncColors();}
    }
    private void save(){if(UiTheme.parse(editing)==null)return;try{SaoUiClient.saveConfig(draft);cancel();}catch(IOException error){saveFailed=true;SaoUiClient.LOGGER.error("Cannot save SAO settings",error);}}
    private void cancel(){minecraft.gui.setScreen(parent);}
    @Override public void onClose(){if(page==Page.HOME)cancel();else open(Page.HOME);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void resize(int width,int height){if(list!=null)scroll=list.scrollAmount();super.resize(width,height);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float delta){
        g.fill(0,0,width,height,0xEA101820);
        var heading=page==Page.HOME?title:Component.translatable("settings.saoui.category."+page.name().toLowerCase(java.util.Locale.ROOT));
        g.text(font,heading,(width-font.width(heading))/2,18,ThemePalette.font(0xFFF3A72E),false);
        if(saveFailed||UiTheme.parse(editing)==null)g.text(font,Component.translatable(saveFailed?"settings.saoui.save_failed":"settings.saoui.theme.invalid"),12,height-43,0xFFFF7777,false);
        super.extractRenderState(g,x,y,delta);
    }
}
