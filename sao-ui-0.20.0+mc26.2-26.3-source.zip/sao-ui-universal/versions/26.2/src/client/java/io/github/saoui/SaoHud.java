package io.github.saoui;

import java.util.UUID;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.world.effect.MobEffects;

public final class SaoHud {
    private UUID playerId;
    private String name = "";
    private HudValues values;
    private double displayedRatio;
    private long lastFrame;

    static HudValues sample(Minecraft client) {
        var p = client.player;
        return new HudValues(p.getHealth(), p.getMaxHealth(), p.getAbsorptionAmount(),
                p.getFoodData().getFoodLevel(), AppleSkinBridge.saturation(p),
                p.experienceProgress, p.experienceLevel, p.getArmorValue(),
                HudValues.condition(p.hasEffect(MobEffects.POISON), p.hasEffect(MobEffects.WITHER)));
    }
    public void tick(Minecraft client) {
        var player = client.player;
        if (player == null) { playerId = null; values = null; lastFrame = 0; return; }
        if (!player.getUUID().equals(playerId)) {
            playerId = player.getUUID(); displayedRatio = UiMath.ratio(player.getHealth(), player.getMaxHealth()); lastFrame = 0;
        }
        name = player.getName().getString(); values = sample(client);
    }
    public void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        var client = Minecraft.getInstance(); var config = SaoUiClient.config(); var bars = config.hud;
        if (config.scale<=0 || !config.hudEnabled || !bars.anyBar() || client.player == null || values == null
                || client.player.isSpectator() || client.gui.hud.isHidden()) { lastFrame = 0; return; }
        long now = Util.getMillis(); float target = UiMath.ratio(values.health(), values.maximum());
        displayedRatio = config.smoothHealth && config.healthSmoothing>0 && lastFrame != 0
                ? UiMath.approach(displayedRatio, target, (now - lastFrame) / (1000.0 * config.healthSmoothing)) : target;
        lastFrame = now;
        String shortName = client.font.plainSubstrByWidth(name, 90);
        int nameWidth = Math.max(48, client.font.width(shortName)), panelWidth = nameWidth + 250, panelHeight = bars.height();
        int viewportWidth = client.getWindow().getGuiScaledWidth(), viewportHeight = client.getWindow().getGuiScaledHeight();
        double unit=UiEffects.unit(client.getWindow().getHeight(),client.getWindow().getGuiScale());
        float scale=(float)UiEffects.fit(UiEffects.scale(client.getWindow().getHeight(),client.getWindow().getGuiScale(),config.scale),viewportWidth,viewportHeight,panelWidth,panelHeight,4*unit);
        int x = UiMath.fitPosition((int)Math.round(config.x*unit), viewportWidth, (int)Math.ceil(panelWidth * scale));
        int y = UiMath.fitPosition((int)Math.round(config.y*unit), viewportHeight, (int)Math.ceil(panelHeight * scale));
        g.pose().pushMatrix(); g.pose().translate(x, y); g.pose().scale(scale, scale);
        if (bars.health) HudBarRenderer.draw(g, client, nameWidth, 0, shortName, displayedRatio,
                values.healthTint(), values.absorptionRatio(), values.healthText(bars.experience));
        else {
            g.fill(4, 0, panelWidth - 8, 15, 0xBB172027);
            g.text(client.font, shortName, 12, 3, ThemePalette.font(0xFFFFFFFF), true);
            if (!bars.experience) {
                String level = "Lv. " + values.level();
                g.text(client.font, level, panelWidth - 13 - client.font.width(level), 3, ThemePalette.font(0xFFDFE7EB), true);
            }
        }
        int row = 20;
        if (bars.hunger) {
            HudBarRenderer.draw(g, client, nameWidth, row, label("hunger"), values.foodRatio(), 0xFFE99C43,
                    bars.saturation ? values.saturationRatio() : 0, values.food() + " / 20"); row += 20;
        }
        if (bars.experience) {
            HudBarRenderer.draw(g, client, nameWidth, row, label("experience"), values.experienceRatio(), 0xFF75CF9C,
                    0, "Lv. " + values.level() + "  " + Math.round(values.experienceRatio() * 100) + "%"); row += 20;
        }
        if (bars.armor) HudBarRenderer.draw(g, client, nameWidth, row, label("armor"), values.armorRatio(),
                0xFF8DB8D5, 0, values.armor() + " / 20");
        g.pose().popMatrix();
    }
    private static String label(String key) { return Component.translatable("hud.saoui." + key).getString(); }
}
