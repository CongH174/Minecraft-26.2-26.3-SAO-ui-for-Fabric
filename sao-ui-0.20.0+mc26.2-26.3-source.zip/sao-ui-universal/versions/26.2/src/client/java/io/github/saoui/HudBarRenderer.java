package io.github.saoui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** All four bars share the original SAO frame, gradient fill and full-height overlay geometry. */
final class HudBarRenderer {
    static final int WIDTH = 215;
    static final int GOLD = 0xFFFFD76A;
    static void draw(GuiGraphicsExtractor g, Minecraft client, int nameWidth, int y, String label,
                     double ratio, int tint, float overlay, String value) {
        UiSprites.gui(g, 0, y, 16, 15, 0, 0, 16, 15);
        UiSprites.gui(g, 16, y, nameWidth, 15, 16, 0, 5, 15);
        UiSprites.gui(g, 16 + nameWidth, y, 234, 15, 21, 0, 234, 15);
        int barX = nameWidth + 18;
        fill(g, barX, y + 3, ratio, tint);
        fill(g, barX, y + 3, overlay, GOLD);
        g.nextStratum(); // Keep glyphs above the chrome's textured render batch.
        int valueX = barX + WIDTH - 4 - client.font.width(value);
        g.fill(valueX - 2, y + 2, barX + WIDTH - 2, y + 13, 0xD019242C);
        g.text(client.font, client.font.plainSubstrByWidth(label, nameWidth), 12, y + 3, ThemePalette.font(0xFFFFFFFF), true);
        g.text(client.font, value, valueX, y + 3, ThemePalette.font(0xFFFFFFFF), true);
    }
    private static void fill(GuiGraphicsExtractor g, int x, int y, double ratio, int tint) {
        int pixels = (int)Math.round(WIDTH * Math.clamp(ratio, 0, 1));
        if (pixels > 0) UiSprites.gui(g, x, y, pixels, 9, 0, 188, pixels, 9, tint);
    }
    private HudBarRenderer() {}
}
