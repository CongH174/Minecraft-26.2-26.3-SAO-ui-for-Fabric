package io.github.saoui;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
public final class UniversalBundleGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        var loader=FabricLoader.getInstance();
        var root=loader.getModContainer("saoui").orElseThrow();
        var runtime=loader.getModContainer("saoui_runtime").orElseThrow();
        var mc=loader.getModContainer("minecraft").orElseThrow().getMetadata().getVersion().getFriendlyString();
        if(!root.getMetadata().getVersion().getFriendlyString().equals("0.20.0"))throw new AssertionError("Wrong universal artifact");
        if(!runtime.getMetadata().getVersion().getFriendlyString().equals("0.20.0-mc"+mc))throw new AssertionError("Wrong runtime selected");
        if(!runtime.getOrigin().getKind().name().equals("NESTED") || !runtime.getOrigin().getParentModId().equals("saoui"))throw new AssertionError("Runtime was loaded from another classpath, not the delivered jar");
        c.runOnClient(client->{if(SaoUiClient.config()==null)throw new AssertionError("Selected runtime did not initialize");});
        SaoUiClient.LOGGER.info("SAO universal bundle passed: Minecraft {}, parent 0.20.0, selected {}, origin {}/{}",mc,runtime.getMetadata().getVersion(),runtime.getOrigin().getKind(),runtime.getOrigin().getParentModId());
    }
}
