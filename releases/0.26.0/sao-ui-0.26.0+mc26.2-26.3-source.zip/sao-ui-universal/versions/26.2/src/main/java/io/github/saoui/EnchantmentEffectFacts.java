package io.github.saoui;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.function.ToDoubleFunction;

/** Read-only descriptions of serialized effects. Never executes effects or loot predicates. */
public final class EnchantmentEffectFacts {
    public record Detail(String component, String operation, List<String> values, List<JsonElement> requirements, String target) {
        public boolean conditional(){return !requirements.isEmpty();}
    }
    private static final int MAX_ROWS=64, MAX_DEPTH=8;
    private final List<Detail> rows=new ArrayList<>();
    private final ToDoubleFunction<JsonElement> values;
    private boolean omitted;
    private EnchantmentEffectFacts(ToDoubleFunction<JsonElement> values){this.values=values;}

    public static List<Detail> describe(JsonObject effects,ToDoubleFunction<JsonElement> values){
        var reader=new EnchantmentEffectFacts(values);
        for(var entry:effects.entrySet()){
            if(reader.rows.size()>=MAX_ROWS){reader.omitted=true;break;}
            String component=entry.getKey();
            if(component.equals("minecraft:prevent_armor_change")||component.equals("minecraft:prevent_equipment_drop"))
                reader.add(component,"flag",List.of(),"",List.of());
            else if(entry.getValue().isJsonArray()){
                for(var element:entry.getValue().getAsJsonArray()){
                    if(reader.rows.size()>=MAX_ROWS){reader.omitted=true;break;}
                    reader.read(component,element,List.of(),"",0);
                }
            }else reader.read(component,entry.getValue(),List.of(),"",0);
        }
        if(reader.omitted)reader.rows.add(new Detail("","omitted",List.of(),List.of(),""));
        return List.copyOf(reader.rows);
    }
    private void add(String component,String operation,List<JsonElement> requirements,String target,List<String> args){
        if(rows.size()<MAX_ROWS)rows.add(new Detail(component,operation,List.copyOf(args),List.copyOf(requirements),target));else omitted=true;
    }
    private String value(JsonObject o,String key){
        double n=values.applyAsDouble(o.get(key));
        if(!Double.isFinite(n))throw new IllegalArgumentException("Non-finite enchantment value");
        return java.math.BigDecimal.valueOf(n).stripTrailingZeros().toPlainString();
    }
    private static String string(JsonObject o,String key,String fallback){
        var e=o.get(key);return e!=null&&e.isJsonPrimitive()&&e.getAsJsonPrimitive().isString()?e.getAsString():fallback;
    }
    private void read(String component,JsonElement element,List<JsonElement> requirements,String target,int depth){
        if(rows.size()>=MAX_ROWS){omitted=true;return;}
        if(depth>MAX_DEPTH||!element.isJsonObject()){add(component,"unsupported",requirements,target,List.of(component));return;}
        var o=element.getAsJsonObject();
        if(o.has("requirements")&&!o.get("requirements").isJsonNull()){
            var nested=new ArrayList<JsonElement>(requirements);nested.add(o.get("requirements"));requirements=List.copyOf(nested);
        }
        target=string(o,"affected",target);
        if(o.has("effect")){read(component,o.get("effect"),requirements,target,depth+1);return;}
        String type=string(o,"type",component.equals("minecraft:attributes")?"minecraft:attribute":component);
        try{
            switch(type){
                case "minecraft:all_of" -> {
                    for(var e:o.getAsJsonArray("effects")){
                        if(rows.size()>=MAX_ROWS){omitted=true;break;}
                        read(component,e,requirements,target,depth+1);
                    }
                }
                case "minecraft:add", "minecraft:multiply", "minecraft:set" -> add(component,type.substring(10),requirements,target,List.of(value(o,type.equals("minecraft:multiply")?"factor":"value")));
                case "minecraft:remove_binomial" -> {
                    double chance=values.applyAsDouble(o.get("chance"));
                    if(!Double.isFinite(chance)||chance<0||chance>1)throw new IllegalArgumentException("Invalid probability");
                    add(component,"remove_binomial",requirements,target,List.of(EnchantmentFacts.number(chance*100)));
                }
                case "minecraft:ignite" -> add(component,"ignite",requirements,target,List.of(value(o,"duration")));
                case "minecraft:damage_entity" -> add(component,"damage_entity",requirements,target,List.of(value(o,"min_damage"),value(o,"max_damage"),string(o,"damage_type","?")));
                case "minecraft:attribute" -> add(component,"attribute",requirements,target,List.of(string(o,"attribute","?"),string(o,"operation","?"),value(o,"amount")));
                // Function bodies, entity predicates and custom codecs are not interpreted as numeric bonuses.
                default -> add(component,"unsupported",requirements,target,List.of(type));
            }
        }catch(RuntimeException invalid){add(component,"unsupported",requirements,target,List.of(type));}
    }
}
