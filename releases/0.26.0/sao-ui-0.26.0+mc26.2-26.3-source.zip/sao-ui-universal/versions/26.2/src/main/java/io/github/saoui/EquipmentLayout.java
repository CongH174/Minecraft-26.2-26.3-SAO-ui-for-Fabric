package io.github.saoui;

/** Shared geometry for the equipment catalogue and its reading column. */
public final class EquipmentLayout {
    public static final int X=44,Y=-156,WIDTH=176,COLUMNS=6,GRID_Y=-108;
    public static final int DETAILS_X=232,DETAILS_WIDTH=340,HEIGHT=316;
    public static final float TEXT_SCALE=1.15f;
    public static int rows(int items){return Math.max(1,(Math.clamp(items,0,41)+COLUMNS-1)/COLUMNS);}
    public static int summaryY(int items){return GRID_Y+rows(items)*22+16;}
    public static int actionY(int items){return summaryY(items)+64;}
    public static int catalogueHeight(int items){return actionY(items)+24-Y;}
    private EquipmentLayout(){}
}
