package io.github.saoui;

import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;

/** Exact hundredths, including keyboard changes independent of widget width. */
public final class SaoSlider extends AbstractSliderButton {
    private final String key;
    private final Consumer<Float> apply;
    public SaoSlider(int x,int y,int width,int height,String key,float initial,Consumer<Float> apply) {
        super(x,y,width,height,Component.empty(),(UiEffects.value(initial,1)-.2)/1.8);
        this.key=key;this.apply=apply;updateMessage();SettingsHelp.attach(this);
    }
    public String settingKey() { return key; }
    public float amount() { return UiEffects.value((float)(value*1.8+.2),1); }
    @Override protected void updateMessage() {
        if(key!=null){
            String value=switch(key){case "settings.saoui.opacity"->String.format(Locale.ROOT,"%.1f%%",amount()*50);case "settings.saoui.scale","settings.saoui.ui_scale"->String.format(Locale.ROOT,"%.0f%%",amount()*100);default->String.format(Locale.ROOT,"%.2f×",amount());};
            setMessage(Component.translatable(key,value));
        }
    }
    @Override protected void applyValue() { value=(amount()-.2)/1.8;apply.accept(amount());updateMessage(); }
    @Override public boolean keyPressed(KeyEvent event) {
        if(event.key()==InputConstants.KEY_LEFT || event.key()==InputConstants.KEY_RIGHT) {
            float next=UiEffects.value(amount()+(event.key()==InputConstants.KEY_LEFT?-.01f:.01f),1);
            value=Math.clamp((next-.2)/1.8,0,1);
            applyValue();return true;
        }
        return super.keyPressed(event);
    }
}
