package io.github.saoui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.client.input.MouseButtonEvent;

/** Native focus/narration with inverse-projected pointer hit testing. */
public final class FloatingButton extends Button {
    private final boolean orb;
    private final Identifier icon;
    private MenuProjection projection;
    private double planeX, planeY, planeWidth, planeHeight, opacity;
    private boolean selected;

    public FloatingButton(Component label, String icon, boolean orb, Runnable action) {
        super(0, 0, 1, 1, label, ignored -> action.run(), DEFAULT_NARRATION);
        this.orb = orb;
        if(orb){setTooltip(net.minecraft.client.gui.components.Tooltip.create(label));setTooltipDelay(java.time.Duration.ofMillis(200));}
        this.icon = icon == null ? null : SaoUiClient.id("textures/sao/menu/icons/" + icon + ".png");
    }

    public void place(MenuProjection projection, double x, double y, double width, double height,
                      double opacity, boolean selected, boolean interactive) {
        this.projection = projection;
        this.planeX = x; this.planeY = y; this.planeWidth = width; this.planeHeight = height;
        this.opacity = opacity; this.selected = selected;
        active = interactive;
        visible = opacity > 0.01;
        var bounds = FloatingDraw.bounds(projection, x, y, width, height);
        setX(bounds.left()); setY(bounds.top());
        setWidth(bounds.width()); setHeight(bounds.height());
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        if (!active || !visible || projection == null) return false;
        var point = projection.unproject(mouseX, mouseY);
        double x = point.x() - planeX, y = point.y() - planeY;
        if (!orb) return x >= 0 && x < planeWidth && y >= 0 && y < planeHeight;
        double dx = (x - planeWidth / 2) / (planeWidth / 2);
        double dy = (y - planeHeight / 2) / (planeHeight / 2);
        return dx * dx + dy * dy <= 1;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        return isMouseOver(event.x(), event.y()) && super.mouseClicked(event, doubleClick);
    }

    @Override
    protected void extractContents(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        if (projection == null || opacity <= 0.01) return;
        boolean highlighted = selected || isFocused() || isMouseOver(mouseX, mouseY);
        double x = planeX, y = planeY, w = planeWidth, h = planeHeight;
        if (orb) {
            double cx = x + w / 2, cy = y + h / 2, r = w / 2;
            FloatingDraw.disc(g, projection, cx + 1.5, cy + 2.5, r + 2, color(0x22000000));
            FloatingDraw.disc(g, projection, cx, cy, r + 1.5, color(0xF2F8FAF6));
            FloatingDraw.disc(g, projection, cx, cy, r - 0.2, color(highlighted ? ThemePalette.accent() : 0xFFC1C9C5));
            FloatingDraw.disc(g, projection, cx, cy, r - 2, color(highlighted ? ThemePalette.accent() : 0xFFF0F3EE));
            if (icon != null) FloatingDraw.icon(g, projection, icon, cx, cy, (float) (w * 0.67), opacity);
        } else {
            FloatingDraw.rect(g, projection, x + 2, y + 2, w, h, color(0x20000000));
            FloatingDraw.rect(g, projection, x, y, w, h, color(highlighted ? ThemePalette.accent() : ThemePalette.cell()));
            FloatingDraw.rect(g, projection, x, y, 2, h, color(highlighted ? 0xFFFFE19D : 0xFFB6BEBA));
            String label = Minecraft.getInstance().font.plainSubstrByWidth(getMessage().getString(), (int) w - 28);
            FloatingDraw.text(g, projection, label, x + 10, y + (h - 9) / 2, color(highlighted ? ThemePalette.onAccent() : ThemePalette.ink()));
            FloatingDraw.text(g, projection, ">", x + w - 14, y + (h - 9) / 2, color(highlighted ? ThemePalette.onAccent() : ThemePalette.muted()));
        }
    }

    private int color(int color) { return FloatingDraw.alpha(color, opacity); }
}
