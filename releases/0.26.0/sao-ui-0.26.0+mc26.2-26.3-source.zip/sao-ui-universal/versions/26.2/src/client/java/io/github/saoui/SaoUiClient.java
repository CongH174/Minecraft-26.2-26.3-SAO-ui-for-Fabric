package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.io.IOException;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class SaoUiClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("saoui");
    private static SaoConfig config;
    private static ConfigStore store;
    static KeyMapping menuKey;

    public static Identifier id(String path) { return Identifier.fromNamespaceAndPath("saoui", path); }
    public static SaoConfig config() { return config; }

    public static void saveConfig(SaoConfig next) throws IOException {
        store.save(next);
        config = next.copy().validated();
    }

    @Override
    public void onInitializeClient() {
        store = new ConfigStore(FabricLoader.getInstance().getConfigDir().resolve("saoui.json"));
        config = store.load();
        BlockFloatingUi.register();
        ContainerCraftingUi.register();
        var category = KeyMapping.Category.register(id("controls"));
        menuKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.saoui.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_K, category));
        GammaOverride.register(category);
        SaoHud hud = new SaoHud();
        VanillaHudVisibility.register();
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, id("player_hud"), hud::extract);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            hud.tick(client);
            BlockFloatingUi.tick(client);
            while (menuKey.consumeClick()) {
                if (client.player != null && client.gui.screen() == null) {
                    client.gui.setScreen(new SaoMenuScreen());
                }
            }
        });
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            BlockFloatingUi.onScreenInit(client, screen);
            ContainerCraftingUi.onInit(screen);
            if (screen instanceof AbstractContainerScreen<?>) ScreenKeyboardEvents.allowKeyPress(screen).register((s, event) ->
                    !BlockFloatingUi.active(s) || BlockFloatingUi.ready(s) || event.isEscape() || client.options.keyInventory.matches(event) || menuKey.matches(event));
            if (screen instanceof SaoMenuScreen || screen instanceof AbstractContainerScreen<?>) {
                ScreenKeyboardEvents.allowKeyPress(screen).register((s, event) -> {
                    if (menuKey.matches(event)) {
                        while (menuKey.consumeClick()) {}
                        s.onClose();
                        return false; // Consume it so the same press cannot reopen the menu.
                    }
                    return true;
                });
            }
        });
        LOGGER.info("SAO UI initialized for Minecraft {}", FabricLoader.getInstance()
                .getModContainer("minecraft").orElseThrow().getMetadata().getVersion().getFriendlyString());
    }
}
