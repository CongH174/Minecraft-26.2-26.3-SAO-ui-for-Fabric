package io.github.saoui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;

/** A native focusable link over an already-rendered status row. */
final class FloatingRegion extends Button {
    private MenuProjection projection;private double px,py,pw,ph;
    FloatingRegion(Component label,Component help,Runnable action){super(0,0,1,1,label,b->action.run(),DEFAULT_NARRATION);setTooltip(Tooltip.create(help));}
    void place(MenuProjection p,double x,double y,double w,double h,boolean shown,boolean enabled){projection=p;px=x;py=y;pw=w;ph=h;visible=shown;active=shown&&enabled;var box=FloatingDraw.bounds(p,x,y,w,h);setRectangle(box.width(),box.height(),box.left(),box.top());}
    @Override public boolean isMouseOver(double x,double y){if(!visible||!active||projection==null)return false;var q=projection.unproject(x,y);return q.x()>=px&&q.x()<px+pw&&q.y()>=py&&q.y()<py+ph;}
    @Override protected void extractContents(GuiGraphicsExtractor g,int x,int y,float delta){if(projection!=null&&active&&(isFocused()||isMouseOver(x,y)))FloatingDraw.rect(g,projection,px,py+ph-1,pw,1,ThemePalette.accent());}
}
