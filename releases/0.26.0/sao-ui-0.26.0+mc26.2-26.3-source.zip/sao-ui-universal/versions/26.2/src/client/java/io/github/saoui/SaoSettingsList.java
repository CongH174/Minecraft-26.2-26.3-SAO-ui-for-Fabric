package io.github.saoui;

import java.util.List;
import java.util.ArrayList;
import java.util.function.BiConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;

/** Vanilla scrolling and input, with an optional text filter over labels and explanations. */
final class SaoSettingsList extends ContainerObjectSelectionList<SaoSettingsList.Row> {
    private record Stored(Row row,int height){}
    private final int rowWidth;private final List<Stored> all=new ArrayList<>();private String group="";
    SaoSettingsList(Minecraft client,int width,int height,int top){super(client,width,height,top,24);rowWidth=Math.min(400,width-24);centerListVertically=false;}
    @Override public int getRowWidth(){return rowWidth;}
    @Override protected void extractListBackground(GuiGraphicsExtractor g){}
    private void append(Row row,int height){all.add(new Stored(row,height));addEntry(row,height);}
    void row(AbstractWidget... widgets){for(var widget:widgets)SettingsHelp.attach(widget);append(new Row(List.of(widgets),null,group),24);}
    void drawing(int height,BiConsumer<GuiGraphicsExtractor,Row> draw){append(new Row(List.of(),draw,group),height);}
    void section(String key){group=Component.translatable(key).getString();drawing(19,(g,row)->g.text(Minecraft.getInstance().font,Component.translatable(key),row.getContentX(),row.getContentY()+4,0xFFFFCF70,false));}
    void clearRows(){all.clear();clearEntries();group="";}
    void filter(String query){
        String text=query.strip().toLowerCase(java.util.Locale.ROOT);clearEntries();
        for(var stored:all)if(text.isEmpty()||stored.row.searchText().contains(text))addEntry(stored.row,stored.height);
        setScrollAmount(0);
    }
    List<AbstractWidget> widgets(){var result=new ArrayList<AbstractWidget>();for(var row:children())result.addAll(row.widgets);return result;}
    void reveal(AbstractWidget widget){for(var row:children())if(row.widgets.contains(widget)){scrollToEntry(row);return;}}
    static final class Row extends ContainerObjectSelectionList.Entry<Row> {
        final List<AbstractWidget> widgets;private final BiConsumer<GuiGraphicsExtractor,Row> draw;private final String group;
        Row(List<AbstractWidget> widgets,BiConsumer<GuiGraphicsExtractor,Row> draw,String group){this.widgets=widgets;this.draw=draw;this.group=group;}
        private String searchText(){
            var text=new StringBuilder(group);
            for(var widget:widgets){text.append(' ').append(widget.getMessage().getString());String key=widget instanceof SaoSlider slider?slider.settingKey():widget.getMessage().getContents() instanceof TranslatableContents t?t.getKey():"";if(net.minecraft.locale.Language.getInstance().has(key+".help"))text.append(' ').append(Component.translatable(key+".help").getString());}
            return text.toString().toLowerCase(java.util.Locale.ROOT);
        }
        private void position(){
            if(widgets.isEmpty())return;int width=(getContentWidth()-8*(widgets.size()-1))/widgets.size();
            for(int i=0;i<widgets.size();i++){var widget=widgets.get(i);widget.setWidth(width);widget.setPosition(getContentX()+i*(width+8),getContentY());}
        }
        @Override public void setX(int x){super.setX(x);position();}
        @Override public void setY(int y){super.setY(y);position();}
        @Override public void setWidth(int width){super.setWidth(width);position();}
        @Override public void extractContent(GuiGraphicsExtractor g,int x,int y,boolean hovered,float delta){position();if(draw!=null)draw.accept(g,this);for(var widget:widgets)widget.extractRenderState(g,x,y,delta);}
        @Override public List<? extends GuiEventListener> children(){return widgets;}
        @Override public List<? extends NarratableEntry> narratables(){return widgets;}
    }
}
