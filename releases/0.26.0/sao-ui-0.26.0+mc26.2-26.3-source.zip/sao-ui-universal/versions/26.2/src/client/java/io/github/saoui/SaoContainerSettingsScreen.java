package io.github.saoui;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** A draft editor for independently inherited block presets. Nothing applies before Save. */
public final class SaoContainerSettingsScreen extends Screen {
    enum Scope { DEFAULT, BLOCK, LOCATION }
    private final Screen parent;
    private final java.util.function.Consumer<SaoConfig> apply;
    private final SaoConfig draft;
    private final ContainerTargets.Target aimed;
    private Scope scope = Scope.DEFAULT;
    private String selected = "minecraft:chest", filter = "";
    private List<String> targets;
    private int page, left, right, top, panelWidth, listWidth, detailWidth, body, step, rowHeight;
    private boolean saveFailed, invalidNumbers;
    private record NumberField(EditBox box, int min, int max) {
        boolean valid() { try { int n = Integer.parseInt(box.getValue()); return n >= min && n <= max; } catch (NumberFormatException e) { return false; } }
    }
    private final java.util.ArrayList<NumberField> numbers = new java.util.ArrayList<>();

    public SaoContainerSettingsScreen(Screen parent) {
        this(parent,SaoUiClient.config(),null);
    }
    public SaoContainerSettingsScreen(Screen parent,SaoConfig initial,java.util.function.Consumer<SaoConfig> apply) {
        super(t("title")); this.parent = parent;this.apply=apply;
        draft = initial.copy().validated();
        aimed = ContainerTargets.aimed();
        if (aimed != null && targetsValid(aimed.block())) selected = ContainerTypeGroups.key(aimed.block());
    }
    private static Component t(String key, Object... args) { return Component.translatable("settings.saoui.containers." + key, args); }
    private ContainerUiProfile current() {
        return switch (scope) {
            case DEFAULT -> draft.containers.defaults;
            case BLOCK -> draft.containers.forBlock(selected);
            case LOCATION -> draft.containers.resolve(aimed.block(), aimed.location());
        };
    }
    private ContainerUiProfile edit() {
        return switch (scope) {
            case DEFAULT -> draft.containers.defaults;
            case BLOCK -> draft.containers.blocks.computeIfAbsent(selected, id -> draft.containers.defaults.copy());
            case LOCATION -> draft.containers.locations.computeIfAbsent(aimed.location(), id -> draft.containers.forBlock(aimed.block()).copy());
        };
    }
    @Override protected void init() {
        numbers.clear();
        panelWidth = Math.min(510, width - 20); left = (width - panelWidth) / 2; top = 8;
        addRenderableWidget(new SaoButton(left+panelWidth-112,7,112,18,Component.translatable("settings.saoui.layout.container_title"),null,()->{invalidNumbers=numbers.stream().anyMatch(n->!n.valid());if(invalidNumbers)return;minecraft.gui.setScreen(new SaoContainerLayoutScreen(this,current(),next->{var p=edit();p.backpackSide=next.backpackSide;p.gap=next.gap;p.containerX=next.containerX;p.containerY=next.containerY;p.backpackX=next.backpackX;p.backpackY=next.backpackY;}));}));
        listWidth = Math.min(154, panelWidth / 3); right = left + listWidth + 12; detailWidth = panelWidth - listWidth - 12;
        body = 68; step = Math.min(23, Math.max(13, (height - 124) / 5)); rowHeight = step - 3;
        int third = (panelWidth - 8) / 3;
        for (var value : Scope.values()) {
            int x = left + value.ordinal() * (third + 4);
            var button = addRenderableWidget(new SaoButton(x, 29, third, 18, t("scope." + value.name().toLowerCase(Locale.ROOT)), null,
                    () -> { scope = value; if (scope == Scope.LOCATION) selected = ContainerTypeGroups.key(aimed.block()); rebuildWidgets(); }));
            button.active = value != scope && (value != Scope.LOCATION || aimed != null && aimed.location() != null && targetsValid(aimed.block()));
        }
        var search = addRenderableWidget(new EditBox(font, left, body, listWidth, rowHeight, t("search")));
        SettingsHelp.attach(search);
        search.setMaxLength(80); search.setValue(filter); search.setHint(t("search"));
        search.setResponder(value -> { filter = value; page = 0; refreshTargets(); });
        refreshTargets();
        var profile = current();
        addRenderableWidget(new SaoButton(right, body, detailWidth, rowHeight,
                t("enabled", Component.translatable(profile.enabled ? "options.on" : "options.off")), null,
                () -> { edit().enabled = !current().enabled; rebuildWidgets(); }));
        addRenderableWidget(new SaoButton(right, body + step, detailWidth, rowHeight, t("side", t("side." + profile.backpackSide.name().toLowerCase(Locale.ROOT))), null,
                () -> { var p = edit(); p.backpackSide = ContainerUiProfile.Side.values()[(p.backpackSide.ordinal() + 1) % 4]; rebuildWidgets(); }));
        number(right + 64, body + step * 2, 48, profile.gap, value -> edit().gap = Math.clamp(value, 0, 96), false, "gap");
        offsets(body + step * 3, profile.containerX, profile.containerY, true);
        offsets(body + step * 4, profile.backpackX, profile.backpackY, false);
        addRenderableWidget(new SaoButton(right, height - 51, detailWidth, 18, t(scope == Scope.DEFAULT ? "reset_default" : "inherit"), null, () -> {
            switch (scope) {
                case DEFAULT -> draft.containers.defaults = new ContainerUiProfile();
                case BLOCK -> draft.containers.blocks.remove(selected);
                case LOCATION -> draft.containers.locations.remove(aimed.location());
            }
            rebuildWidgets();
        }));
        int half = (panelWidth - 8) / 2;
        addRenderableWidget(new SaoButton(left, height - 27, half, 19, Component.translatable(apply==null?"settings.saoui.save_return":"settings.saoui.apply_draft"), null, this::save));
        addRenderableWidget(new SaoButton(left + half + 8, height - 27, half, 19, Component.translatable("gui.cancel"), null, this::onClose));
    }
    private boolean targetsValid(String id) { return ContainerTargets.catalog(draft.containers).contains(ContainerTypeGroups.key(id)); }
    private final java.util.ArrayList<SaoButton> targetButtons = new java.util.ArrayList<>();
    private void refreshTargets() {
        for (var widget : targetButtons) removeWidget(widget);
        targetButtons.clear();
        String query = filter.toLowerCase(Locale.ROOT);
        targets = ContainerTargets.catalog(draft.containers).stream().filter(id -> id.contains(query) || ContainerTargets.name(id).toLowerCase(Locale.ROOT).contains(query)).toList();
        int rows = Math.max(1, (height - body - 83) / step), pages = Math.max(1, (targets.size() + rows - 1) / rows);
        page = Math.clamp(page, 0, pages - 1);
        for (int i = page * rows; i < Math.min(targets.size(), (page + 1) * rows); i++) {
            String id = targets.get(i);
            var button = new SaoButton(left, body + step * (i % rows + 1), listWidth, rowHeight,
                    Component.literal((draft.containers.blocks.containsKey(id) ? "• " : "") + ContainerTargets.name(id)), null,
                    () -> { selected = id; scope = Scope.BLOCK; rebuildWidgets(); });
            SettingsHelp.attach(button,"settings.saoui.containers.target",ContainerTargets.name(id),id);
            button.active = scope != Scope.BLOCK || !selected.equals(id);
            targetButtons.add(addRenderableWidget(button));
        }
        int pagerY = height - 52, half = (listWidth - 4) / 2;
        var prev = new SaoButton(left, pagerY, half, 18, Component.literal("‹ " + (page + 1) + "/" + pages), null, () -> { page--; refreshTargets(); });
        var next = new SaoButton(left + half + 4, pagerY, half, 18, Component.literal("›"), null, () -> { page++; refreshTargets(); });
        SettingsHelp.attach(prev,"settings.saoui.containers.previous");SettingsHelp.attach(next,"settings.saoui.containers.next");
        prev.active = page > 0; next.active = page < pages - 1;
        targetButtons.add(addRenderableWidget(prev)); targetButtons.add(addRenderableWidget(next));
    }
    private void number(int x, int y, int w, int value, IntConsumer change, boolean signed, String setting) {
        var box = addRenderableWidget(new EditBox(font, x, y, w, rowHeight, t(setting)));
        SettingsHelp.attach(box);
        box.setMaxLength(signed ? 4 : 2);
        box.setValue(Integer.toString(value));
        var field = new NumberField(box, signed ? -200 : 0, signed ? 200 : 96);
        numbers.add(field);
        box.setResponder(text -> {
            box.setTextColor(field.valid() ? 0xFFE4E9E7 : 0xFFFF7777);
            if (field.valid()) change.accept(Integer.parseInt(text));
            if (invalidNumbers) invalidNumbers = numbers.stream().anyMatch(number -> !number.valid());
        });
    }
    private void offsets(int y, int xValue, int yValue, boolean container) {
        int valueWidth = Math.max(28, (detailWidth - 116) / 2);
        number(right + 78, y, valueWidth, xValue, value -> { if (container) edit().containerX = value; else edit().backpackX = value; }, true, container ? "container_x" : "backpack_x");
        number(right + 96 + valueWidth, y, valueWidth, yValue, value -> { if (container) edit().containerY = value; else edit().backpackY = value; }, true, container ? "container_y" : "backpack_y");
    }
    private void save() {
        invalidNumbers = numbers.stream().anyMatch(field -> !field.valid());
        if (invalidNumbers) return;
        try { if(apply!=null)apply.accept(draft.copy());else SaoUiClient.saveConfig(draft); onClose(); }
        catch (IOException error) { saveFailed = true; SaoUiClient.LOGGER.error("Cannot save per-block UI rules", error); }
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0xEA101820);
        g.text(font, title, left, top, 0xFFF1B438, false);
        String info = scope == Scope.DEFAULT ? t("default_hint").getString() : ContainerTargets.name(scope == Scope.LOCATION ? aimed.block() : selected) + "  "
                + (scope == Scope.LOCATION ? aimed.position().toShortString() : selected);
        g.text(font, font.plainSubstrByWidth(info, panelWidth), left, 53, 0xFFDDE5DD, false);
        g.text(font, t("gap"), right, body + step * 2 + 3, 0xFFDDE5DD, false);
        int valueWidth = Math.max(28, (detailWidth - 116) / 2);
        for (int row = 3; row <= 4; row++) {
            int y = body + step * row + 3;
            g.text(font, t(row == 3 ? "container_offset" : "backpack_offset"), right, y, 0xFFDDE5DD, false);
            g.text(font, "X", right + 66, y, 0xFFF1B438, false);
            g.text(font, "Y", right + 84 + valueWidth, y, 0xFFF1B438, false);
        }
        if (saveFailed || invalidNumbers) g.text(font, invalidNumbers ? t("invalid_numbers") : Component.translatable("settings.saoui.save_failed"), left, 18, 0xFFFF7777, false);
        super.extractRenderState(g, mx, my, delta);
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.gui.setScreen(parent); }
}
