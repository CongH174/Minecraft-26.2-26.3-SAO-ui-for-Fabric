package io.github.saoui;

import com.mojang.serialization.JsonOps;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentEffectComponents;
import net.minecraft.world.item.enchantment.LevelBasedValue;

/** Uses the connected world's registry and loaded language resources; no companion or reflection required. */
final class EnchantmentDetails {
    private EnchantmentDetails() {}

    static Optional<String> descriptionKey(String nameKey,String idKey,int level,Predicate<String> exists){
        var bases=new LinkedHashSet<String>();
        if(nameKey!=null)bases.add(nameKey);
        if(idKey!=null)bases.add(idKey);
        for(String base:bases){
            // A level-specific author description is more useful than the generic one in this panel.
            for(String suffix:List.of(".desc",".description",".info"))if(exists.test(base+suffix+"."+level))return Optional.of(base+suffix+"."+level);
            for(String suffix:List.of(".desc",".description",".info"))if(exists.test(base+suffix))return Optional.of(base+suffix);
            if(exists.test("description."+base))return Optional.of("description."+base);
        }
        return Optional.empty();
    }

    static List<Component> describe(Holder<Enchantment> holder,int level,boolean armor,SaoConfig config,HolderLookup.Provider registries){
        var result=new ArrayList<Component>();
        var enchantment=holder.value();
        var id=holder.unwrapKey().map(k->k.identifier()).orElse(null);
        if(config.enchantmentDescriptions){
            String nameKey=enchantment.description().getContents() instanceof TranslatableContents t?t.getKey():null;
            String idKey=id==null?null:id.toLanguageKey("enchantment");
            descriptionKey(nameKey,idKey,level,Language.getInstance()::has).ifPresent(key->result.add(Component.translatable("saoui.enchant.resource",Component.translatable(key))));
        }
        if(config.syncedEnchantmentEffects){
            var encoded=EnchantmentEffectComponents.CODEC.encodeStart(registries.createSerializationContext(JsonOps.INSTANCE),enchantment.effects()).result();
            if(encoded.isPresent()&&encoded.get().isJsonObject()){
                String vanillaId=id!=null&&id.getNamespace().equals("minecraft")?id.getPath():"";
                if(matchesShipped(vanillaId,encoded.get(),registries)){
                    var fact=EnchantmentFacts.describe(vanillaId,level,armor);
                    result.add(Component.translatable("saoui.enchant."+fact.id(),fact.values()));
                }else{
                    var facts=EnchantmentEffectFacts.describe(encoded.get().getAsJsonObject(),json->LevelBasedValue.CODEC.parse(JsonOps.INSTANCE,json).getOrThrow().calculate(Math.max(1,level)));
                    for(var fact:facts)result.add(EnchantmentEffectText.describe(fact,level));
                }
            }else result.add(Component.translatable("saoui.enchant.unavailable"));
        }
        if(result.isEmpty())result.add(Component.translatable("saoui.enchant.unknown"));
        return List.copyOf(result);
    }
    private static HolderLookup.Provider baselineRegistry;
    private static final java.util.Map<String,com.google.gson.JsonElement> normalizedBaselines=new java.util.HashMap<>();
    private static final com.google.gson.JsonObject SHIPPED=loadShipped();
    private static com.google.gson.JsonObject loadShipped(){
        try(var stream=EnchantmentDetails.class.getResourceAsStream("/assets/saoui/enchantment_effect_baseline.json")){
            if(stream!=null)return com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
        }catch(java.io.IOException|RuntimeException invalid){SaoUiClient.LOGGER.warn("Cannot read enchantment description baselines",invalid);}
        return new com.google.gson.JsonObject();
    }
    /** Compare the complete effects, including every predicate, after the native codec's normalization. */
    static boolean matchesShipped(String id,com.google.gson.JsonElement actual,HolderLookup.Provider registries){
        if(!EnchantmentFacts.IDS.contains(id)||!SHIPPED.has(id))return false;
        if(baselineRegistry!=registries){baselineRegistry=registries;normalizedBaselines.clear();}
        var baseline=normalizedBaselines.computeIfAbsent(id,key->{
            var ops=registries.createSerializationContext(JsonOps.INSTANCE);
            return EnchantmentEffectComponents.CODEC.parse(ops,SHIPPED.get(key))
                .flatMap(value->EnchantmentEffectComponents.CODEC.encodeStart(ops,value)).result().orElse(com.google.gson.JsonNull.INSTANCE);
        });
        return !baseline.isJsonNull()&&baseline.equals(actual);
    }
}
