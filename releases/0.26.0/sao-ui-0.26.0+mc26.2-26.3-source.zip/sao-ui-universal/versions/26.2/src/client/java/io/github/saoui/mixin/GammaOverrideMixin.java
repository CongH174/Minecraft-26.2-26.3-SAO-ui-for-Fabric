package io.github.saoui.mixin;

import io.github.saoui.GammaOverride;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import net.minecraft.client.renderer.state.LightmapRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LightmapRenderStateExtractor.class)
public abstract class GammaOverrideMixin {
    @Inject(method="extract",at=@At("TAIL"))
    private void saoui$gamma(LightmapRenderState state,float partialTick,CallbackInfo ci){GammaOverride.apply(state);}
}
