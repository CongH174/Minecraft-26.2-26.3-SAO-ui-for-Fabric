package io.github.saoui;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.enchantment.LevelBasedValue;
import com.mojang.serialization.JsonOps;

/** Player-facing fallback for changed/custom effects. Predicates are described, never evaluated. */
final class EnchantmentEffectText {
    private EnchantmentEffectText() {}
    private static Component text(String key,Object... values){return Component.translatable("saoui.enchant."+key,values);}
    private static Component label(String prefix,String id,String fallback){
        String key="saoui.enchant."+prefix+id;
        return Language.getInstance().has(key)?Component.translatable(key):text(fallback);
    }
    static Component describe(EnchantmentEffectFacts.Detail fact,int level){
        Component line=body(fact);
        if(!fact.target().isEmpty())line=text("target",line,label("target.",fact.target(),"target.other"));
        if(fact.conditional()){
            var conditions=fact.requirements().stream().map(e->condition(e,level,0)).toList();
            line=text("when",join(conditions,"and"),line);
        }
        return line;
    }
    private static Component body(EnchantmentEffectFacts.Detail f){
        var values=f.values();String op=f.operation(),component=f.component();
        Component subject=label("component.",component,"component.other");
        if(op.equals("unsupported"))return text("special");
        if(op.equals("omitted"))return text("effect.omitted");
        if(op.equals("flag"))return subject;
        if(op.equals("attribute")){
            String id=values.get(0),operation=values.get(1);double amount=Double.parseDouble(values.get(2));
            Component name=label("attribute.",id,"attribute.other");
            if(operation.equals("add_value")&&id.equals("minecraft:sweeping_damage_ratio"))return text("actual.sweeping",EnchantmentFacts.number(amount*100));
            if(operation.equals("add_multiplied_base")||operation.equals("add_multiplied_total"))return text("attribute."+operation,name,EnchantmentFacts.number(amount*100));
            if(operation.equals("add_value")){
                boolean ratio=java.util.Set.of("minecraft:explosion_knockback_resistance","minecraft:water_movement_efficiency","minecraft:movement_efficiency","minecraft:sneaking_speed").contains(id);
                return text(ratio?"attribute.points":"attribute.add",name,EnchantmentFacts.number(amount*(ratio?100:1)));
            }
            return text("special");
        }
        if(op.equals("add")){
            double value=Double.parseDouble(values.getFirst());
            return switch(component){
                case "minecraft:damage" -> text("actual.damage",EnchantmentFacts.number(value));
                case "minecraft:equipment_drops" -> text("actual.equipment_drops",EnchantmentFacts.number(value*100));
                case "minecraft:armor_effectiveness" -> text("actual.armor",EnchantmentFacts.number(value*100));
                case "minecraft:damage_protection" -> text("actual.protection",EnchantmentFacts.number(value*4));
                case "minecraft:crossbow_charge_time" -> text(value<0?"actual.charge_less":"actual.charge_more",EnchantmentFacts.number(Math.abs(value)));
                case "minecraft:knockback" -> text("actual.knockback",EnchantmentFacts.number(value));
                default -> text("effect.add",subject,EnchantmentFacts.number(value));
            };
        }
        if(op.equals("ignite")&&component.equals("minecraft:projectile_spawned"))return text("actual.projectile_fire",values.getFirst());
        if(op.equals("damage_entity"))return text("actual.hurt",values.get(0),values.get(1));
        var args=new ArrayList<Object>();args.add(subject);for(var value:values){try{args.add(EnchantmentFacts.number(Double.parseDouble(value)));}catch(NumberFormatException notNumeric){args.add(value);}}
        return text("effect."+op,args.toArray());
    }
    private static String string(JsonObject o,String key){var value=o.get(key);return value!=null&&value.isJsonPrimitive()?value.getAsString():"";}
    private static Component join(List<Component> parts,String operation){
        if(parts.isEmpty())return text("condition.custom");
        Component result=parts.getFirst();for(int i=1;i<parts.size();i++)result=text("condition."+operation,result,parts.get(i));return result;
    }
    static Component condition(JsonElement element,int level,int depth){
        if(depth>8||element==null||!element.isJsonObject())return text("condition.custom");
        var o=element.getAsJsonObject();String type=string(o,"condition");if(type.isEmpty())type=string(o,"type");
        try{
            switch(type){
                case "minecraft:all_of","minecraft:any_of":{
                    var parts=new ArrayList<Component>();var terms=o.getAsJsonArray("terms");
                    if(terms.size()>16)return text("condition.custom");
                    for(var term:terms)parts.add(condition(term,level,depth+1));return join(parts,type.equals("minecraft:all_of")?"and":"or");
                }
                case "minecraft:inverted":return text("condition.not",condition(o.get("term"),level,depth+1));
                case "minecraft:random_chance":{
                    var chance=o.get("chance");
                    if(chance.isJsonObject()&&string(chance.getAsJsonObject(),"type").equals("minecraft:enchantment_level"))chance=chance.getAsJsonObject().get("amount");
                    double value=LevelBasedValue.CODEC.parse(JsonOps.INSTANCE,chance).getOrThrow().calculate(Math.max(1,level));
                    return Double.isFinite(value)?text("condition.chance",EnchantmentFacts.number(Math.clamp(value,0,1)*100)):text("condition.custom");
                }
                case "minecraft:entity_properties":{
                    var predicate=o.getAsJsonObject("predicate");
                    var entityType=predicate.get("minecraft:entity_type");
                    if(entityType==null)entityType=predicate.get("type");
                    if(entityType!=null&&entityType.isJsonPrimitive()&&predicate.size()==1){
                        return text("condition.entity",label("condition.subject.",string(o,"entity"),"condition.subject.this"),label("condition.entity_type.",entityType.getAsString(),"condition.entity_type.other"));
                    }
                    return text("condition.custom");
                }
                case "minecraft:match_tool":{
                    var predicate=o.getAsJsonObject("predicate");
                    if(predicate.size()==1&&predicate.has("items")&&predicate.get("items").isJsonPrimitive())return text("condition.item",label("condition.item_type.",predicate.get("items").getAsString(),"condition.item_type.other"));
                    return text("condition.custom");
                }
                case "minecraft:damage_source_properties":{
                    var predicate=o.getAsJsonObject("predicate");var parts=new ArrayList<Component>();
                    if(predicate.has("is_direct"))parts.add(text(predicate.get("is_direct").getAsBoolean()?"condition.direct":"condition.indirect"));
                    if(predicate.has("tags"))for(var tag:predicate.getAsJsonArray("tags")){
                        var t=tag.getAsJsonObject();var name=label("condition.damage.",string(t,"id"),"condition.damage.other");parts.add(t.get("expected").getAsBoolean()?name:text("condition.not",name));
                    }
                    if(predicate.size()>(predicate.has("is_direct")?1:0)+(predicate.has("tags")?1:0))parts.add(text("condition.custom"));
                    return join(parts,"and");
                }
                default:return text("condition.custom");
            }
        }catch(RuntimeException invalid){return text("condition.custom");}
    }
}
