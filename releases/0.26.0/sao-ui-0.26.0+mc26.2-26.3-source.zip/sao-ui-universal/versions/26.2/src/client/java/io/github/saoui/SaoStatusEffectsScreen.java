package io.github.saoui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectCategory;

/** Full native status list, with harmful and soon-expiring effects first. */
final class SaoStatusEffectsScreen extends Screen {
    private final Screen parent;private SaoSettingsList list;private int ticks;
    SaoStatusEffectsScreen(Screen parent){super(Component.translatable("profile.saoui.open_effects"));this.parent=parent;}
    @Override protected void init(){
        list=addRenderableWidget(new SaoSettingsList(minecraft,width,Math.max(24,height-80),38));refresh();
        addRenderableWidget(new SaoButton(width/2-80,height-30,160,20,Component.translatable("gui.back"),null,this::onClose));
    }
    private void refresh(){
        double scroll=list.scrollAmount();list.clearRows();
        if(minecraft.player!=null)for(var effect:PlayerStatusPanel.effects(minecraft.player))list.drawing(30,(g,row)->{
            int color=effect.getEffect().value().getCategory()==MobEffectCategory.HARMFUL?0xFFFFA18C:0xFFE5EEE9;
            String level=effect.getAmplifier()>0?" "+(effect.getAmplifier()+1):"";
            String duration=effect.isInfiniteDuration()?"∞":String.format(java.util.Locale.ROOT,"%d:%02d",Math.max(0,effect.getDuration()/20)/60,Math.max(0,effect.getDuration()/20)%60);
            g.text(font,effect.getEffect().value().getDisplayName().getString()+level,row.getContentX(),row.getContentY()+2,color,false);
            g.text(font,duration,row.getContentX()+row.getContentWidth()-font.width(duration),row.getContentY()+2,color,false);
        });
        list.setScrollAmount(scroll);
    }
    @Override public void tick(){if(++ticks%20==0)refresh();}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float delta){g.fill(0,0,width,height,0xED101820);g.text(font,title,(width-font.width(title))/2,16,0xFFFFCF70,false);if(list.children().isEmpty())g.text(font,Component.translatable("profile.saoui.normal"),width/2-50,64,0xFFCED8D9,false);super.extractRenderState(g,x,y,delta);}
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
