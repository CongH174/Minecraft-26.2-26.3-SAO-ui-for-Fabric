package io.github.saoui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;

/** Four categories, then direct controls. The entire editor shares one unsaved draft. */
public final class SaoSettingsScreen extends Screen {
    enum Page {HOME,INTERFACE,HUD,COMPAT}
    private final Screen parent;
    private SaoConfig draft;
    private Page page=Page.HOME;
    private SaoSettingsList list;
    private SaoButton done,fontMode;
    private boolean saveFailed,dirty;
    private final String initialState;
    private static final com.google.gson.Gson SNAPSHOT=new com.google.gson.Gson();
    private EditBox search;private String query="";
    private final java.util.Map<Page,String> queries=new java.util.EnumMap<>(Page.class);
    private final java.util.Map<Page,Double> positions=new java.util.EnumMap<>(Page.class);
    private int colorTarget;
    private String editing;
    private EditBox hex;
    private final List<RgbSlider> rgb=new ArrayList<>();
    private double scroll;
    private SaoHudStylePicker stylePicker;
    public SaoSettingsScreen(Screen parent){super(Component.translatable("screen.saoui.settings"));this.parent=parent;draft=SaoUiClient.config().copy();initialState=SNAPSHOT.toJson(draft);editing=UiTheme.hex(currentColor());}
    private void changed(){dirty=!initialState.equals(SNAPSHOT.toJson(draft));}
    static void openMenu(Screen parent){var editor=new SaoSettingsScreen(parent);net.minecraft.client.Minecraft.getInstance().gui.setScreen(editor);editor.menuEditor();}
    static void openContainers(Screen parent){var editor=new SaoSettingsScreen(parent);editor.page=Page.INTERFACE;net.minecraft.client.Minecraft.getInstance().gui.setScreen(editor);editor.containerEditor();}
    private void menuEditor(){minecraft.gui.setScreen(new SaoModuleSettingsScreen(this,draft,next->{draft.moduleOrder=next.moduleOrder;draft.hiddenModules=next.hiddenModules;draft.homeModule=next.homeModule;changed();}));}
    private void containerEditor(){minecraft.gui.setScreen(new SaoContainerSettingsScreen(this,draft,next->{draft.containers=next.containers;changed();}));}
    Page page(){return page;}
    List<AbstractWidget> options(){return list==null?List.of():list.widgets();}
    void reveal(AbstractWidget widget){if(list!=null)list.reveal(widget);}
    private void open(Page next){if(list!=null)positions.put(page,list.scrollAmount());queries.put(page,query);page=next;scroll=positions.getOrDefault(next,0.0);query=queries.getOrDefault(next,"");rebuildWidgets();}
    private void rebuild(){if(list!=null)scroll=list.scrollAmount();rebuildWidgets();}
    @Override protected void init(){
        list=null;search=null;hex=null;fontMode=null;stylePicker=null;rgb.clear();
        int panelWidth=Math.min(400,width-24),left=(width-panelWidth)/2,half=(panelWidth-8)/2;
        if(page==Page.HOME){
            int y=Math.max(45,height/2-48);
            addRenderableWidget(button("settings.saoui.category.interface",()->open(Page.INTERFACE))).setRectangle(half,22,left,y);
            addRenderableWidget(button("settings.saoui.category.hud",()->open(Page.HUD))).setRectangle(half,22,left+half+8,y);
            addRenderableWidget(button("settings.saoui.category.menu",this::menuEditor)).setRectangle(half,22,left,y+28);
            addRenderableWidget(button("settings.saoui.category.compat",()->open(Page.COMPAT))).setRectangle(half,22,left+half+8,y+28);
            addRenderableWidget(button("settings.saoui.reset",()->{draft=new SaoConfig();editing=UiTheme.hex(currentColor());rebuild();})).setRectangle(panelWidth,22,left,y+64);
        } else {
            list=addRenderableWidget(new SaoSettingsList(minecraft,width,Math.max(40,height-106),62));
            switch(page){case INTERFACE->interfaceOptions();case HUD->hudOptions();case COMPAT->compatOptions();default->{}}
            search=addRenderableWidget(new EditBox(font,left,35,panelWidth,20,Component.translatable("settings.saoui.search")));
            search.setMaxLength(80);search.setHint(Component.translatable("settings.saoui.search_hint"));search.setValue(query);SettingsHelp.attach(search,"settings.saoui.search");
            search.setResponder(value->{query=value;list.filter(value);});list.filter(query);
            list.setScrollAmount(scroll);
        }
        int footer=height-30;
        if(page==Page.HOME){done=addRenderableWidget(button("settings.saoui.save_return",this::save));done.setRectangle(half,20,left,footer);addRenderableWidget(button("settings.saoui.discard",this::cancel)).setRectangle(half,20,left+half+8,footer);}
        else {int third=(panelWidth-16)/3;addRenderableWidget(button("settings.saoui.back_categories",()->open(Page.HOME))).setRectangle(third,20,left,footer);done=addRenderableWidget(button("settings.saoui.save_return",this::save));done.setRectangle(third,20,left+third+8,footer);addRenderableWidget(button("settings.saoui.discard",this::cancel)).setRectangle(third,20,left+2*(third+8),footer);}
        syncColors();
    }
    private void interfaceOptions(){
        list.row(button("settings.saoui.layout.container_shortcut",()->minecraft.gui.setScreen(new SaoContainerLayoutScreen(this,draft.containers.defaults,next->{draft.containers.defaults=next.copy();changed();}))));
        list.section("settings.saoui.section.display");
        list.row(slider("ui_scale",draft.uiScale,v->draft.uiScale=v),slider("opacity",draft.uiOpacity,v->draft.uiOpacity=v));
        list.row(slider("parallax",draft.parallaxStrength,v->draft.parallaxStrength=v),toggle("parallax_enabled",draft.parallaxEnabled,()->draft.parallaxEnabled=!draft.parallaxEnabled));
        list.row(slider("animation_speed",draft.animationSpeed,v->draft.animationSpeed=v),toggle("animations_enabled",draft.animationsEnabled,()->draft.animationsEnabled=!draft.animationsEnabled));
        list.row(slider("blur",draft.blurStrength,v->draft.blurStrength=v),toggle("blur_enabled",draft.blurEnabled,()->draft.blurEnabled=!draft.blurEnabled));
        list.section("settings.saoui.section.features");
        list.row(toggle("equipment_portrait",draft.equipmentPortrait,()->draft.equipmentPortrait=!draft.equipmentPortrait));
        list.row(toggle("armor_slots",draft.armorSlotsVisible,()->draft.armorSlotsVisible=!draft.armorSlotsVisible),toggle("crafting",draft.craftingVisible,()->draft.craftingVisible=!draft.craftingVisible));
        list.row(toggle("enchantments",draft.enchantmentDetailsVisible,()->draft.enchantmentDetailsVisible=!draft.enchantmentDetailsVisible),toggle("container_crafting",draft.containerCraftingVisible,()->draft.containerCraftingVisible=!draft.containerCraftingVisible));
        list.row(toggle("block_ui",draft.blockUiEnabled,()->draft.blockUiEnabled=!draft.blockUiEnabled),toggle("all_containers",draft.replaceAllContainers,()->draft.replaceAllContainers=!draft.replaceAllContainers));
        list.row(button("settings.saoui.container_rules",this::containerEditor));
        list.section("settings.saoui.theme");
        list.row(button("settings.saoui.theme.background",()->selectColor(0)),button("settings.saoui.theme.accent",()->selectColor(1)),button("settings.saoui.theme.font",()->selectColor(2)));
        hex=new EditBox(font,0,0,196,20,Component.translatable("settings.saoui.theme.hex"));hex.setMaxLength(7);hex.setValue(editing);hex.setHint(Component.literal("#RRGGBB"));
        hex.setResponder(value->{editing=value;Integer color=UiTheme.parse(value);if(color!=null)setColor(color);syncColors();changed();});
        fontMode=new SaoButton(0,0,196,20,Component.translatable("settings.saoui.theme.font_mode",Component.translatable(draft.theme.customFont?"settings.saoui.theme.custom":"settings.saoui.theme.auto")),null,()->{draft.theme.customFont=!draft.theme.customFont;changed();rebuild();});
        list.row(hex,fontMode);
        for(int i=0;i<3;i++){var slider=new RgbSlider(i);rgb.add(slider);list.row(slider);}
        list.drawing(58,(g,row)->{int x=row.getContentX(),y=row.getContentY(),w=row.getContentWidth(),bg=0xFF000000|draft.theme.background,ink=draft.theme.customFont?0xFF000000|draft.theme.font:UiTheme.text(bg);g.fill(x,y,x+w,y+50,bg);g.fill(x,y,x+3,y+27,0xFF000000|draft.theme.accent);g.text(font,Component.translatable("settings.saoui.theme.preview"),x+12,y+10,ink,false);g.fill(x+12,y+27,x+w-12,y+43,0xFF000000|draft.theme.accent);g.text(font,Component.translatable("settings.saoui.theme.sample"),x+19,y+31,draft.theme.customFont?ink:UiTheme.text(draft.theme.accent),false);});
        list.row(button("settings.saoui.theme.reset",()->{draft.theme=new UiTheme();editing=UiTheme.hex(currentColor());rebuild();}));
    }
    private void hudOptions(){
        list.row(toggle("hud",draft.hudEnabled,()->draft.hudEnabled=!draft.hudEnabled),slider("scale",draft.scale,v->draft.scale=v));
        stylePicker=new SaoHudStylePicker(draft.hud.style,value->draft.hud.style=value);
        list.row(toggle("hud_right",draft.hud.rightAligned,()->draft.hud.rightAligned=!draft.hud.rightAligned),stylePicker.control);
        list.row(toggle("smooth",draft.smoothHealth,()->draft.smoothHealth=!draft.smoothHealth),slider("smoothing",draft.healthSmoothing,v->draft.healthSmoothing=v));
        list.row(button("settings.saoui.layout.hud_title",()->minecraft.gui.setScreen(new SaoHudLayoutScreen(this,draft,next->{draft.x=next.x;draft.y=next.y;draft.scale=next.scale;}))));
        list.section("settings.saoui.section.bars");
        list.row(bar("health",draft.hud.health,()->draft.hud.health=!draft.hud.health),bar("hide_vanilla_health",draft.hud.hideVanillaHealth,()->draft.hud.hideVanillaHealth=!draft.hud.hideVanillaHealth));
        list.row(bar("hunger",draft.hud.hunger,()->draft.hud.hunger=!draft.hud.hunger),bar("hide_vanilla_hunger",draft.hud.hideVanillaHunger,()->draft.hud.hideVanillaHunger=!draft.hud.hideVanillaHunger));
        list.row(toggle("food_preview",draft.hud.foodPreview,()->draft.hud.foodPreview=!draft.hud.foodPreview));
        list.row(bar("experience",draft.hud.experience,()->draft.hud.experience=!draft.hud.experience),bar("hide_vanilla_experience",draft.hud.hideVanillaExperience,()->draft.hud.hideVanillaExperience=!draft.hud.hideVanillaExperience));
        list.row(bar("armor",draft.hud.armor,()->draft.hud.armor=!draft.hud.armor),bar("hide_vanilla_armor",draft.hud.hideVanillaArmor,()->draft.hud.hideVanillaArmor=!draft.hud.hideVanillaArmor));
        list.row(bar("saturation",draft.hud.saturation,()->draft.hud.saturation=!draft.hud.saturation),bar("hide_vanilla_crosshair",draft.hud.hideVanillaCrosshair,()->draft.hud.hideVanillaCrosshair=!draft.hud.hideVanillaCrosshair));
        list.drawing(28,(g,row)->g.text(font,Component.translatable("settings.saoui.hotbar_kept"),row.getContentX(),row.getContentY()+4,0xFFB6C3CD,false));
    }
    private void compatOptions(){
        list.section("settings.saoui.section.descriptions");
        list.row(toggle("enchantment_descriptions",draft.enchantmentDescriptions,()->draft.enchantmentDescriptions=!draft.enchantmentDescriptions),toggle("synced_enchantment_effects",draft.syncedEnchantmentEffects,()->draft.syncedEnchantmentEffects=!draft.syncedEnchantmentEffects));
        list.row(toggle("server_enchantment_lore",draft.serverEnchantmentLore,()->draft.serverEnchantmentLore=!draft.serverEnchantmentLore));
        list.section("settings.saoui.section.integrations");
        list.row(toggle("ipn",draft.ipnIntegration,()->draft.ipnIntegration=!draft.ipnIntegration),bar("saturation",draft.hud.saturation,()->draft.hud.saturation=!draft.hud.saturation));
        list.drawing(36,(g,row)->{g.text(font,Component.translatable(AppleSkinBridge.AVAILABLE?"settings.saoui.appleskin_ready":"settings.saoui.appleskin_missing"),row.getContentX(),row.getContentY()+2,0xFFFFDF64,false);g.text(font,font.plainSubstrByWidth(Component.translatable("settings.saoui.appleskin_sync").getString(),row.getContentWidth()),row.getContentX(),row.getContentY()+17,0xFFB6C3CD,false);});
    }
    private SaoButton button(String key,Runnable action){return new SaoButton(0,0,196,20,Component.translatable(key),null,()->{action.run();changed();});}
    private SaoButton toggle(String key,boolean value,Runnable change){return toggleKey("settings.saoui."+key,value,change);}
    private SaoButton bar(String key,boolean value,Runnable change){return toggleKey("settings.saoui.bar."+key,value,change);}
    private SaoButton toggleKey(String key,boolean value,Runnable change){var button=new SaoButton(0,0,196,20,Component.translatable(key,Component.translatable(value?"options.on":"options.off")),null,()->{change.run();changed();rebuild();});return button;}
    private SaoSlider slider(String key,float value,Consumer<Float> change){var slider=new SaoSlider(0,0,196,20,"settings.saoui."+key,value,next->{change.accept(next);changed();});return slider;}
    private int currentColor(){return colorTarget==1?draft.theme.accent:colorTarget==2?draft.theme.font:draft.theme.background;}
    private void setColor(int color){if(colorTarget==1)draft.theme.accent=color;else if(colorTarget==2){draft.theme.font=color;draft.theme.customFont=true;}else draft.theme.background=color;}
    private void selectColor(int target){colorTarget=target;editing=UiTheme.hex(currentColor());rebuild();}
    private void syncColors(){if(fontMode!=null)fontMode.setMessage(Component.translatable("settings.saoui.theme.font_mode",Component.translatable(draft.theme.customFont?"settings.saoui.theme.custom":"settings.saoui.theme.auto")));if(done!=null)done.active=UiTheme.parse(editing)!=null;if(hex!=null)hex.setTextColor(UiTheme.parse(editing)!=null?0xFFFFFFFF:0xFFFF7777);for(var slider:rgb)slider.sync();}
    private final class RgbSlider extends AbstractSliderButton {
        private final int channel;
        RgbSlider(int channel){super(0,0,196,20,Component.empty(),0);this.channel=channel;sync();SettingsHelp.attach(this,"settings.saoui.theme.rgb."+channel);}
        void sync(){value=(currentColor()>>(16-channel*8)&255)/255.0;updateMessage();}
        @Override protected void updateMessage(){setMessage(Component.literal(new String[]{"R","G","B"}[channel]+": "+Math.round(value*255)));}
        @Override protected void applyValue(){int shift=16-channel*8;setColor(currentColor()&~(255<<shift)|(int)Math.round(value*255)<<shift);editing=UiTheme.hex(currentColor());hex.setValue(editing);syncColors();changed();}
    }
    private void save(){if(UiTheme.parse(editing)==null)return;try{SaoUiClient.saveConfig(draft);cancel();}catch(IOException error){saveFailed=true;SaoUiClient.LOGGER.error("Cannot save SAO settings",error);}}
    private void cancel(){minecraft.gui.setScreen(parent);}
    @Override public void onClose(){if(page==Page.HOME)cancel();else open(Page.HOME);}
    @Override public boolean mouseClicked(MouseButtonEvent event,boolean doubleClick){if(stylePicker!=null&&stylePicker.click(event,doubleClick,this))return true;return super.mouseClicked(event,doubleClick);}
    @Override public boolean keyPressed(KeyEvent event){if(event.isEscape()&&search!=null&&!query.isEmpty()){search.setValue("");return true;}if(stylePicker!=null&&stylePicker.key(event))return true;return super.keyPressed(event);}
    @Override public boolean mouseScrolled(double x,double y,double horizontal,double vertical){if(stylePicker!=null&&stylePicker.scroll(vertical))return true;return super.mouseScrolled(x,y,horizontal,vertical);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void resize(int width,int height){if(list!=null)scroll=list.scrollAmount();super.resize(width,height);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int x,int y,float delta){
        g.fill(0,0,width,height,0xEA101820);
        var heading=page==Page.HOME?title:Component.translatable("settings.saoui.category."+page.name().toLowerCase(java.util.Locale.ROOT));
        g.text(font,heading,(width-font.width(heading))/2,18,ThemePalette.font(0xFFF3A72E),false);
        if(!saveFailed&&UiTheme.parse(editing)!=null)g.text(font,Component.translatable(dirty?"settings.saoui.unsaved":"settings.saoui.no_changes"),12,height-44,dirty?0xFFFFCF70:0xFFB6C3CD,false);
        if(list!=null&&list.children().isEmpty())g.text(font,Component.translatable("settings.saoui.no_results"),12,70,0xFFCED8D9,false);
        if(saveFailed||UiTheme.parse(editing)==null)g.text(font,Component.translatable(saveFailed?"settings.saoui.save_failed":"settings.saoui.theme.invalid"),12,height-43,0xFFFF7777,false);
        super.extractRenderState(g,x,y,delta);
        if(stylePicker!=null)stylePicker.render(g,x,y,delta,this);
    }
}
