package io.github.saoui;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class EquipmentLayoutTest {
 @Test void fullCatalogueFitsAboveActionsAndReadingColumn(){
  assertEquals(7,EquipmentLayout.rows(41));
  int lastY=EquipmentLayout.GRID_Y+6*22+20;
  assertTrue(lastY<EquipmentLayout.summaryY(41));
  assertTrue(EquipmentLayout.actionY(41)+20<=EquipmentLayout.Y+EquipmentLayout.HEIGHT);
  assertTrue(58+5*22+20<EquipmentLayout.X+EquipmentLayout.WIDTH);
  assertTrue(EquipmentLayout.X+EquipmentLayout.WIDTH<EquipmentLayout.DETAILS_X);
 }
 @Test void shortCatalogueLeavesRoomWithoutAnEmptyGrid(){assertTrue(EquipmentLayout.catalogueHeight(1)<EquipmentLayout.catalogueHeight(41)-100);}
 @Test void newPreferencesCopyCancelAndResetIndependently(){var live=new SaoConfig();var draft=live.copy();draft.equipmentPortrait=true;assertFalse(live.equipmentPortrait);var next=draft.copy();assertTrue(next.equipmentPortrait);next.resetHud();assertFalse(next.equipmentPortrait);}
}
