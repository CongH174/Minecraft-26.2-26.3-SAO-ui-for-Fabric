package io.github.saoui;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class EnchantmentFactsTest {
    @Test void concreteExamplesUseJavaRulesAndArmorBranch(){
        assertEquals("75",EnchantmentFacts.describe("unbreaking",3,false).values()[0]);
        assertEquals("30",EnchantmentFacts.describe("unbreaking",3,true).values()[0]);
        assertEquals("3",EnchantmentFacts.describe("sharpness",5,false).values()[0]);
        assertEquals("26",EnchantmentFacts.describe("efficiency",5,false).values()[0]);
        assertEquals("2.2",EnchantmentFacts.describe("fortune",3,false).values()[0]);
        assertEquals("0.5",EnchantmentFacts.describe("quick_charge",3,false).values()[0]);
        assertEquals("48",EnchantmentFacts.describe("feather_falling",4,true).values()[0]);
        assertEquals("60",EnchantmentFacts.describe("breach",4,false).values()[0]);
        assertEquals("75",EnchantmentFacts.describe("swift_sneak",3,true).values()[0]);
        assertEquals("61.5",EnchantmentFacts.describe("soul_speed",3,true).values()[0]);
    }
    @Test void allFortyThreeEnchantmentsHaveLocalizedDescriptions() throws Exception {
        assertEquals(43,EnchantmentFacts.IDS.size());
        for(var lang:new String[]{"zh_cn","en_us"})try(var stream=getClass().getResourceAsStream("/assets/saoui/lang/"+lang+".json")){
            var json=com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            for(var id:EnchantmentFacts.IDS)assertTrue(json.has("saoui.enchant."+id),lang+":"+id);
        }
        assertEquals("unknown",EnchantmentFacts.describe("modded_spell",3,false).id());
    }
    @Test void currentNativeBoundsAndExtraProjectileLevelsAreReadable(){
        assertEquals("16",EnchantmentFacts.describe("frost_walker",30,false).values()[0]);
        assertEquals("5",EnchantmentFacts.describe("multishot",2,false).values()[0]);
        assertEquals("20",EnchantmentFacts.describe("multishot",2,false).values()[1]);
        assertEquals("1.5",EnchantmentFacts.describe("bane_of_arthropods",3,false).values()[2]);
    }
    @Test void screenshotDescriptionsNameTargetsAndPercentagePoints() throws Exception {
        try(var stream=getClass().getResourceAsStream("/assets/saoui/lang/zh_cn.json")){
            var json=com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            assertTrue(json.get("saoui.enchant.smite").getAsString().contains("亡灵"));
            assertTrue(json.get("saoui.enchant.looting").getAsString().contains("个百分点"));
            assertTrue(json.get("saoui.enchant.sweeping_edge").getAsString().contains("周围"));
            assertTrue(json.get("saoui.enchant.knockback").getAsString().contains("击退更远"));
        }
    }
    @Test void shippedBaselinesIncludeEmptyLootTableDrivenEffects() throws Exception {
        try(var stream=getClass().getResourceAsStream("/assets/saoui/enchantment_effect_baseline.json")){
            var json=com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(stream,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
            assertEquals(EnchantmentFacts.IDS,json.keySet());assertTrue(json.getAsJsonObject("fortune").isEmpty());
        }
    }
    @Test void featureDraftIsIsolatedAndResettable(){
        var original=new SaoConfig();var draft=original.copy();draft.containerCraftingVisible=false;draft.enchantmentDetailsVisible=false;draft.ipnIntegration=false;
        assertTrue(original.containerCraftingVisible&&original.enchantmentDetailsVisible&&original.ipnIntegration);
        draft.resetHud();assertTrue(draft.containerCraftingVisible&&draft.enchantmentDetailsVisible&&draft.ipnIntegration);
    }
}
