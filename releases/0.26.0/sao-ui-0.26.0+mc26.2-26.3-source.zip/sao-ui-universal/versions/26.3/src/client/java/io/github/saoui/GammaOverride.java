package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.state.LightmapRenderState;
import net.minecraft.network.chat.Component;

/** Session-only full brightness. Never changes Options.gamma, effects or server state. */
public final class GammaOverride {
    // The vanilla lightmap's minimum ambient color reaches display white at this finite value.
    public static final float MAX_GAMMA=16.0f;
    private static volatile boolean enabled;
    static KeyMapping key;
    private GammaOverride(){}
    static void register(KeyMapping.Category category){
        key=KeyMappingHelper.registerKeyMapping(new KeyMapping("key.saoui.gamma_override",InputConstants.Type.KEYBOARD,InputConstants.KEY_G,category));
        ClientTickEvents.END_CLIENT_TICK.register(GammaOverride::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler,client)->enabled=false);
    }
    private static void tick(Minecraft client){
        while(key.consumeClick()){
            if(client.player==null||client.level==null||client.gui.screen()!=null)continue;
            enabled=!enabled;
            client.gui.hud.setOverlayMessage(Component.translatable("message.saoui.gamma_override",Component.translatable(enabled?"options.on":"options.off")),false);
        }
    }
    public static boolean enabled(){return enabled;}
    public static void apply(LightmapRenderState state){
        if(enabled)state.brightness=MAX_GAMMA;
    }
}
