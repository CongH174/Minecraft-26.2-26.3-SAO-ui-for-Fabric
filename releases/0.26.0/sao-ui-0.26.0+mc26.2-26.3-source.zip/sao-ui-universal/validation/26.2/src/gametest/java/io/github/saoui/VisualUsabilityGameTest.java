package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantments;

/** Exercises the delivered UI's input, real component updates, and nested draft commit boundaries. */
public final class VisualUsabilityGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        String oldLanguage=c.computeOnClient(client->client.getLanguageManager().getSelected());
        var languageReload=c.computeOnClient(client->{client.getLanguageManager().setSelected("zh_cn");return client.reloadResourcePacks();});c.waitFor(client->languageReload.isDone());languageReload.join();
        save(c,new SaoConfig());
        try(var world=c.worldBuilder().create()){
            world.getClientLevel().waitForChunksRender();c.waitForScreen(null);
            c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));c.clickScreenButton("settings.saoui.category.hud");SettingsNavigation.click(c,"settings.saoui.layout.hud_title");
            c.waitForScreen(SaoHudLayoutScreen.class);dragHud(c);shot(c,"sao-hud-layout-editor");
            c.runOnClient(client->{var s=client.gui.screen();var draft=(SaoConfig)field(s,"draft");check(draft.x!=12||draft.y!=12,"HUD drag did not change position");var x=(EditBox)field(s,"xField");x.setValue("-1");});
            c.clickScreenButton("settings.saoui.layout.apply");check(c.computeOnClient(client->client.gui.screen() instanceof SaoHudLayoutScreen),"Invalid coordinates were accepted");
            c.runOnClient(client->{var s=client.gui.screen();((EditBox)field(s,"xField")).setValue("64");});c.clickScreenButton("settings.saoui.layout.apply");
            check(c.computeOnClient(client->SaoUiClient.config().x)==12,"Child HUD Apply wrote live config");SettingsNavigation.click(c,"gui.cancel");
            check(c.computeOnClient(client->SaoUiClient.config().x)==12,"Outer Cancel leaked HUD layout");
            c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));c.clickScreenButton("settings.saoui.category.hud");SettingsNavigation.click(c,"settings.saoui.layout.hud_title");
            c.runOnClient(client->{var s=client.gui.screen();((EditBox)field(s,"xField")).setValue("64");((EditBox)field(s,"yField")).setValue("48");s.resize(s.width,s.height);});
            c.clickScreenButton("settings.saoui.layout.apply");SettingsNavigation.click(c,"gui.back");c.clickScreenButton("settings.saoui.category.interface");SettingsNavigation.click(c,"settings.saoui.container_rules");
            c.clickScreenButton("settings.saoui.layout.container_title");c.waitForScreen(SaoContainerLayoutScreen.class);dragContainer(c);shot(c,"sao-container-layout-editor");
            c.runOnClient(client->{var s=client.gui.screen();var p=(ContainerUiProfile)field(s,"draft");check(p.containerX!=0||p.containerY!=0,"Container drag did not update offsets");var before=p.copy();s.resize(s.width,s.height);var after=(ContainerUiProfile)field(s,"draft");check(before.containerX==after.containerX&&before.containerY==after.containerY,"Resize lost container draft");});
            c.clickScreenButton("settings.saoui.layout.apply");check(c.computeOnClient(client->SaoUiClient.config().containers.defaults.containerX)==0,"Container visual Apply wrote live config");
            SettingsNavigation.click(c,"gui.done");check(c.computeOnClient(client->SaoUiClient.config().containers.defaults.containerX)==0,"Rule editor wrote outer draft early");SettingsNavigation.click(c,"gui.done");
            check(c.computeOnClient(client->SaoUiClient.config().x)==64&&c.computeOnClient(client->SaoUiClient.config().y)==48,"Outer Save lost HUD draft");
            c.runOnClient(client->{var disk=new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();check(disk.x==64&&disk.y==48&&(disk.containers.defaults.containerX!=0||disk.containers.defaults.containerY!=0),"Saved layouts did not round trip");});
            // Local cancellation must not manufacture a per-block override.
            c.runOnClient(client->client.gui.setScreen(new SaoContainerSettingsScreen(null)));c.clickScreenButton("settings.saoui.layout.container_title");dragContainer(c);SettingsNavigation.click(c,"gui.cancel");SettingsNavigation.click(c,"gui.cancel");
            world.getServer().runOnServer(server->{
                var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();var registry=server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
                var sword=new ItemStack(Items.DIAMOND_SWORD);sword.enchant(registry.getOrThrow(Enchantments.SHARPNESS),5);sword.enchant(registry.getOrThrow(Enchantments.UNBREAKING),3);
                sword.set(DataComponents.LORE,new ItemLore(java.util.stream.IntStream.range(0,28).<Component>mapToObj(i->Component.literal("服务器原文 "+i+"：效果由服务器规则决定")).toList()));
                p.getInventory().setItem(0,sword);p.getInventory().setItem(1,new ItemStack(Items.SHIELD));p.getInventory().setItem(2,new ItemStack(Items.DIAMOND_CHESTPLATE));p.getInventory().setItem(3,new ItemStack(Items.DIAMOND_PICKAXE));var book=new ItemStack(Items.ENCHANTED_BOOK);var bookEnchants=new net.minecraft.world.item.enchantment.ItemEnchantments.Mutable(net.minecraft.world.item.enchantment.ItemEnchantments.EMPTY);bookEnchants.set(registry.getOrThrow(Enchantments.PROTECTION),4);book.set(DataComponents.STORED_ENCHANTMENTS,bookEnchants.toImmutable());p.getInventory().setItem(4,book);p.inventoryMenu.broadcastChanges();
            });
            c.waitFor(client->client.player.getInventory().getItem(0).has(DataComponents.LORE));
            c.runOnClient(client->{check(ItemDetails.kind(new ItemStack(Items.SHIELD))==ItemDetails.Kind.SHIELD,"Shield classified as weapon");check(ItemDetails.kind(new ItemStack(Items.DIAMOND_CHESTPLATE))==ItemDetails.Kind.ARMOR,"Armor classified as weapon");check(ItemDetails.kind(new ItemStack(Items.DIAMOND_PICKAXE))==ItemDetails.Kind.TOOL,"Pickaxe classified as weapon");check(ItemDetails.kind(new ItemStack(Items.ENCHANTED_BOOK))==ItemDetails.Kind.BOOK,"Book classified as weapon");var config=SaoUiClient.config();config.homeModule="equipment";config.parallaxEnabled=false;config.enchantmentDetailsVisible=true;});
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());c.waitTicks(2);
            c.runOnClient(client->{var s=(SaoMenuScreen)client.gui.screen();var p=projection(s);var point=p.project(EnchantmentPanel.X+30,EnchantmentPanel.Y+90);check(s.mouseScrolled(point.x(),point.y(),0,-3),"Reading panel did not scroll");check(panel(s).scrollPosition()>0,"Lore was not scrollable");});
            int scroll=c.computeOnClient(client->panel((SaoMenuScreen)client.gui.screen()).scrollPosition());
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().getItem(0).setDamageValue(7);p.inventoryMenu.broadcastChanges();});
            c.waitFor(client->client.player.getInventory().getItem(0).getDamageValue()==7);c.waitTicks(3);
            check(c.computeOnClient(client->panel((SaoMenuScreen)client.gui.screen()).scrollPosition())==scroll,"Durability update reset reading position");
            c.runOnClient(client->{var s=(SaoMenuScreen)client.gui.screen();var p=projection(s);var pt=p.project(EnchantmentPanel.X+30,EnchantmentPanel.Y+90);for(int i=0;i<100;i++)s.mouseScrolled(pt.x(),pt.y(),0,3);int before=panel(s).lineCount();var h=p.project(EnchantmentPanel.X+30,EnchantmentPanel.Y+55);var event=event(h.x(),h.y());check(s.mouseClicked(event,false),"Lore heading click was not handled");s.mouseReleased(event);check(panel(s).lineCount()<before,"Lore heading did not collapse");});
            shot(c,"sao-collapsible-enchantments");
            c.runOnClient(client->{var s=(SaoMenuScreen)client.gui.screen();var pt=projection(s).project(EnchantmentPanel.X+EnchantmentPanel.W-25,EnchantmentPanel.Y+15);s.mouseClicked(event(pt.x(),pt.y()),false);s.mouseReleased(event(pt.x(),pt.y()));check(panel(s).modal(),"Reading view did not open");try{var method=EnchantmentPanel.class.getDeclaredMethod("readerProjection");method.setAccessible(true);var rp=(MenuProjection)method.invoke(panel(s));var row=rp.project(30,68);s.mouseClicked(event(row.x(),row.y()),false);s.mouseReleased(event(row.x(),row.y()));}catch(ReflectiveOperationException e){throw new AssertionError(e);}});shot(c,"sao-enchantment-reading-view");
            c.getInput().pressKey(InputConstants.KEY_ESCAPE);check(c.computeOnClient(client->client.gui.screen() instanceof SaoMenuScreen&&!panel((SaoMenuScreen)client.gui.screen()).modal()),"Escape closed menu instead of reader");
            select(c,1);shot(c,"sao-shield-details");select(c,2);shot(c,"sao-armor-details");select(c,3);shot(c,"sao-tool-details");select(c,4);shot(c,"sao-book-details");
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
            SaoUiClient.LOGGER.info("SAO visual usability passed: typed summaries, native left-button editor dragging, numeric validation, snap bounds, resize, nested HUD/container drafts, cancel/save/disk, source folding and reading position under native durability updates");
        }finally{save(c,original);var restoreLanguage=c.computeOnClient(client->{client.getLanguageManager().setSelected(oldLanguage);return client.reloadResourcePacks();});c.waitFor(client->restoreLanguage.isDone());restoreLanguage.join();}
    }
    private static MouseButtonEvent event(double x,double y){return new MouseButtonEvent(x,y,new MouseButtonInfo(InputConstants.MOUSE_BUTTON_LEFT,0));}
    private static void dragHud(ClientGameTestContext c){c.runOnClient(client->{var s=(SaoHudLayoutScreen)client.gui.screen();var d=(SaoConfig)field(s,"draft");var f=SaoHud.frame(client,d,s.width,s.height);double k=(double)field(s,"canvasScale"),cx=(double)field(s,"canvasX"),cy=(double)field(s,"canvasY");double x=cx+(f.x()+f.width()/2.0)*k,y=cy+(f.y()+f.height()/2.0)*k;check(s.mouseClicked(event(x,y),false),"Native left button did not start HUD drag: "+InputConstants.MOUSE_BUTTON_LEFT);check(s.mouseDragged(event(x+35,y+20),35,20),"HUD did not handle drag");s.mouseReleased(event(x+35,y+20));});}
    private static void dragContainer(ClientGameTestContext c){c.runOnClient(client->{var s=(SaoContainerLayoutScreen)client.gui.screen();double k=(double)field(s,"viewScale");var d=(ContainerUiProfile)field(s,"draft");var p=ContainerPanelLayout.place(222,d);double x=(double)field(s,"centerX")+(111+d.containerX-p.baseline().centerX())*k,y=(double)field(s,"centerY")+(70+d.containerY-p.baseline().centerY())*k;check(s.mouseClicked(event(x,y),false),"Native left button did not start container drag");check(s.mouseDragged(event(x+25,y+15),25,15),"Container did not handle drag");s.mouseReleased(event(x+25,y+15));});}
    private static void select(ClientGameTestContext c,int index){c.runOnClient(client->{var s=client.gui.screen();var w=s.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(slot->slot.visible).toList().get(index);var e=event(w.getX()+w.getWidth()/2.0,w.getY()+w.getHeight()/2.0);s.mouseClicked(e,false);s.mouseReleased(e);});c.waitTicks(2);check(c.computeOnClient(client->panel((SaoMenuScreen)client.gui.screen()).scrollPosition())==0,"Changing selection retained another item's scroll");}
    private static Object field(Object target,String name){try{var f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
    private static EnchantmentPanel panel(SaoMenuScreen s){return (EnchantmentPanel)field(field(s,"panels"),"enchantments");}
    private static MenuProjection projection(SaoMenuScreen s){try{var m=SaoMenuScreen.class.getDeclaredMethod("projection",long.class);m.setAccessible(true);return (MenuProjection)m.invoke(s,net.minecraft.util.Util.getMillis());}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
    private static void shot(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.getInput().setCursorPos(4,4);c.waitTicks(2);c.takeScreenshot(name);}
    private static void save(ClientGameTestContext c,SaoConfig cfg){c.runOnClient(client->{try{SaoUiClient.saveConfig(cfg);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
}
