package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;

/** Only the reverted animation path, original controls and same-JAR loading are exercised. */
public final class MenuAnimationGameTest implements FabricClientGameTest {
 @Override public void runTest(ClientGameTestContext c){
  var original=c.computeOnClient(client->SaoUiClient.config().copy());var time=new AtomicLong(1000);
  try(var world=c.worldBuilder().create()){
   world.getClientLevel().waitForChunksRender();c.waitForScreen(null);
   open(c,time,1,true);
   time.addAndGet(180);c.waitTick();c.runOnClient(client->check(!menu(client).isAnimationSettled(),"Default opening is still accelerated"));
   time.addAndGet(339);c.waitTick();c.runOnClient(client->check(!menu(client).isAnimationSettled(),"Standard opening completed before 520ms"));
   time.incrementAndGet();c.waitTick();c.runOnClient(client->check(menu(client).isAnimationSettled(),"Standard opening did not finish at 520ms"));
   c.clickScreenButton("root.saoui.settings");time.addAndGet(259);c.waitTick();c.runOnClient(client->check(!menu(client).isAnimationSettled(),"Panel animation is still accelerated"));
   time.incrementAndGet();c.waitTick();c.runOnClient(client->check(menu(client).isAnimationSettled(),"Panel did not finish at 260ms"));
   c.clickScreenButton("menu.saoui.hud_settings");time.addAndGet(239);c.waitTicks(2);c.runOnClient(client->check(client.gui.screen() instanceof SaoMenuScreen,"Navigation skipped the 240ms close animation"));
   time.incrementAndGet();c.waitForScreen(SaoSettingsScreen.class);c.clickScreenButton("settings.saoui.category.interface");
   c.runOnClient(client->{var settings=(SaoSettingsScreen)client.gui.screen();check(settings.options().stream().noneMatch(w->w.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t&&t.getKey().equals("settings.saoui.quick_menu")),"Removed quick-menu switch is still present");});
   SettingsNavigation.expose(c,"settings.saoui.animation_speed");
   c.runOnClient(client->{var slider=(SaoSlider)SettingsNavigation.widget(client.gui.screen(),"settings.saoui.animation_speed");client.gui.screen().setFocused(slider);slider.setFocused(true);});
   c.getInput().pressKey(InputConstants.KEY_RIGHT);c.waitTick();
   c.runOnClient(client->{var slider=(SaoSlider)SettingsNavigation.widget(client.gui.screen(),"settings.saoui.animation_speed");check(Math.abs(slider.amount()-1.01f)<.001,"Existing speed slider lost its .01 keyboard step");check(SaoUiClient.config().animationSpeed==1,"Slider draft leaked before saving");});
   shot(c,"sao-animation-original-slider");c.clickScreenButton("settings.saoui.save_return");c.waitForScreen(SaoMenuScreen.class);
   c.runOnClient(client->{check(Math.abs(SaoUiClient.config().animationSpeed-1.01f)<.001,"Existing speed slider did not save");check(!menu(client).isAnimationSettled(),"Returning from settings still skips opening");});time.addAndGet(600);c.waitTicks(2);
   for(float speed:new float[]{.2f,2f}){
    open(c,time,speed,true);long end=Math.max((long)Math.ceil(520/speed),140+(long)Math.ceil(260/speed));
    time.addAndGet(end-5);c.waitTick();c.runOnClient(client->check(!menu(client).isAnimationSettled(),"Original speed mapping finished too early: "+speed));
    time.addAndGet(10);c.waitTick();c.runOnClient(client->check(menu(client).isAnimationSettled(),"Original speed mapping did not finish: "+speed));
   }
   open(c,time,1,false);c.runOnClient(client->check(menu(client).isAnimationSettled(),"Original animation-off switch no longer works"));shot(c,"sao-animation-restored-menu");
   c.runOnClient(client->{var legacy=new com.google.gson.Gson().fromJson("{\"quickMenu\":true,\"animationSpeed\":1.37}",SaoConfig.class);check(Math.abs(legacy.animationRate()-1.37f)<.001,"Stale quickMenu config still changes the animation rate");});
   SaoUiClient.LOGGER.info("SAO animation rollback passed: original 520/260/240ms timing, returned-menu opening, existing .01 speed slider/save, .20 and 2.00 speed mapping, animation-off switch and ignored stale quickMenu config");
  }finally{c.runOnClient(client->{client.gui.setScreen(null);save(original);});}
 }
 private static SaoMenuScreen menu(net.minecraft.client.Minecraft client){return (SaoMenuScreen)client.gui.screen();}
 private static void open(ClientGameTestContext c,AtomicLong time,float speed,boolean enabled){c.runOnClient(client->{var cfg=SaoUiClient.config().copy();cfg.animationSpeed=speed;cfg.animationsEnabled=enabled;cfg.parallaxEnabled=false;cfg.homeModule="profile";save(cfg);client.gui.setScreen(new SaoMenuScreen(time::get));});c.waitTick();}
 private static void save(SaoConfig config){try{SaoUiClient.saveConfig(config);}catch(java.io.IOException e){throw new RuntimeException(e);}}
 private static void shot(ClientGameTestContext c,String name){c.getInput().setCursorPos(4,4);c.waitTicks(2);c.takeScreenshot(name);}
 private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
