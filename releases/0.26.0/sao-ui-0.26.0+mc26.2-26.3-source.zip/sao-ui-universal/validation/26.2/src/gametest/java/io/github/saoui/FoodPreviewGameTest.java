package io.github.saoui;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.gamerules.GameRules;
/** Exercises optional class loading as well as the actual AppleSkin jar when installed. */
public final class FoodPreviewGameTest implements FabricClientGameTest {
 @Override public void runTest(ClientGameTestContext c){
  var original=c.computeOnClient(client->SaoUiClient.config().copy());var oldLanguage=c.computeOnClient(client->client.getLanguageManager().getSelected());language(c,"zh_cn");save(c,new SaoConfig());
  try(var world=c.worldBuilder().create()){
   world.getClientLevel().waitForChunksRender();c.waitForScreen(null);
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.setGameMode(GameType.SURVIVAL);p.level().getGameRules().set(GameRules.NATURAL_HEALTH_REGENERATION,false,server);p.getInventory().clearContent();p.getFoodData().setFoodLevel(12);p.getFoodData().setSaturation(2);p.getInventory().setItem(0,new ItemStack(Items.APPLE,4));p.getInventory().setItem(1,new ItemStack(Items.BREAD,4));p.getInventory().setItem(2,new ItemStack(Items.COOKED_BEEF,4));p.getInventory().setItem(3,new ItemStack(Items.STICK));p.getInventory().setItem(4,new ItemStack(Items.GOLDEN_APPLE));p.setItemSlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND,new ItemStack(Items.BREAD,3));p.inventoryMenu.broadcastChanges();});
   c.waitFor(client->client.player.getFoodData().getFoodLevel()==12&&client.player.getInventory().getItem(2).is(Items.COOKED_BEEF));
   if(AppleSkinBridge.AVAILABLE)AppleSkinPreviewChecks.run(c,world);
   else {c.runOnClient(client->{check(!AppleSkinBridge.preview(client,SaoUiClient.config().hud).present(),"Absent AppleSkin invented a prediction");check(client.player.getMainHandItem().getCount()==4&&client.player.getFoodData().getFoodLevel()==12,"Preview changed item count or hunger");});c.takeScreenshot("sao-food-preview-without-appleskin");SaoUiClient.LOGGER.info("SAO food preview absent passed: optional API classes remain unloaded and held food does not invent recovery");}
   c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));SettingsNavigation.click(c,"settings.saoui.food_preview");check(c.computeOnClient(client->SaoUiClient.config().hud.foodPreview),"Unsaved preview toggle wrote live configuration");SettingsNavigation.click(c,"gui.cancel");check(c.computeOnClient(client->SaoUiClient.config().hud.foodPreview),"Cancelled preview toggle leaked");
   c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));SettingsNavigation.click(c,"settings.saoui.food_preview");SettingsNavigation.click(c,"gui.done");c.runOnClient(client->{check(!SaoUiClient.config().hud.foodPreview,"Preview switch did not save");var disk=new ConfigStore(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();check(!disk.hud.foodPreview,"Preview switch did not persist");check(!AppleSkinBridge.preview(client,SaoUiClient.config().hud).present(),"Disabled SAO preview still renders");});
   SaoUiClient.LOGGER.info("SAO food preview controls passed: native setting input, isolated draft, cancel/save/disk and disable");
  }finally{c.runOnClient(client->client.gui.setScreen(null));save(c,original);language(c,oldLanguage);}
 }
 static void save(ClientGameTestContext c,SaoConfig config){c.runOnClient(client->{try{SaoUiClient.saveConfig(config);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 private static void language(ClientGameTestContext c,String code){var r=c.computeOnClient(client->{client.getLanguageManager().setSelected(code);return client.reloadResourcePacks();});c.waitFor(client->r.isDone());r.join();c.waitFor(client->client.gui.overlay()==null);}
}
