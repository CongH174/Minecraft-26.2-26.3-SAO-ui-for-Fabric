package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import java.util.Properties;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;

/** Only the server save contains this pack; the client must obtain definitions via registry sync. */
public final class ServerEnchantmentsGameTest implements FabricClientGameTest {
    private static final ResourceKey<Enchantment> EDGE=ResourceKey.create(Registries.ENCHANTMENT,Identifier.fromNamespaceAndPath("saoui_test","server_edge"));
    @Override public void runTest(ClientGameTestContext c){
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        try{
            Path save=Path.of("saoui-enchantment-registry-test-world").toAbsolutePath().normalize();
            var properties=new Properties();properties.setProperty("level-name",save.toString());properties.setProperty("server-ip","127.0.0.1");
            try(var socket=new java.net.ServerSocket(0)){properties.setProperty("server-port",Integer.toString(socket.getLocalPort()));}catch(java.io.IOException e){throw new RuntimeException(e);}
            try(var world=c.worldBuilder().adjustSettings(ignored->writePack(save)).createServer(properties);var connection=world.connect()){
                connection.getClientLevel().waitForChunksRender();c.waitForScreen(null);
                final Object[] serverDefinition={null};
                world.runOnServer(server->{
                    var registry=server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);var edge=registry.getOrThrow(EDGE);serverDefinition[0]=edge.value();
                    var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();
                    var sword=new ItemStack(Items.DIAMOND_SWORD);sword.enchant(edge,3);p.getInventory().setItem(0,sword);for(int i=0;i<itemSamples(server.registryAccess()).size();i++)p.getInventory().setItem(i+1,itemSamples(server.registryAccess()).get(i));p.inventoryMenu.broadcastChanges();
                });
                c.waitFor(client->client.player.getInventory().getItem(0).isEnchanted()&&client.player.getInventory().getItem(3).has(net.minecraft.core.component.DataComponents.LORE));
                c.runOnClient(client->{
                    var registry=client.player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);var holder=registry.getOrThrow(EDGE);
                    var maximumPanel=new EnchantmentPanel();maximumPanel.previewMode(true);try{var refresh=EnchantmentPanel.class.getDeclaredMethod("refresh",ItemStack.class,String.class);refresh.setAccessible(true);refresh.invoke(maximumPanel,new ItemStack(Items.DIAMOND_SWORD),"tcp-max");var field=EnchantmentPanel.class.getDeclaredField("sections");field.setAccessible(true);var rendered=field.get(maximumPanel).toString();require(rendered.contains(Enchantment.getFullname(holder,holder.value().getMaxLevel()).getString()),"Synced data-pack enchantment is missing its actual maximum level");}catch(ReflectiveOperationException e){throw new AssertionError(e);}
                    require(holder.value()!=serverDefinition[0],"Client reused the server object instead of a decoded registry definition");
                    var config=SaoUiClient.config();config.enchantmentDescriptions=true;config.syncedEnchantmentEffects=true;config.enchantmentDetailsVisible=true;
                    String details=EnchantmentDetails.describe(holder,3,false,config,client.player.registryAccess()).toString();
                    require(details.contains("4.5")&&details.contains("75"),"Server-only linear value or probability was not decoded at level 3: "+details);
                    require(details.contains("saoui.enchant.when")&&details.contains("saoui.enchant.special")&&!EnchantmentDetails.describe(holder,3,false,config,client.player.registryAccess()).stream().map(net.minecraft.network.chat.Component::getString).anyMatch(line->line.contains("minecraft:run_function")),"Conditional/function boundary was lost");
                    var sharp=registry.getOrThrow(Enchantments.SHARPNESS);
                    var actual=EnchantmentDetails.describe(sharp,5,false,config,client.player.registryAccess());
                    require(actual.toString().contains("17")&&!actual.toString().contains("saoui.enchant.reference"),"Actual overridden values were lost or duplicated with a default reference");
                    require(EnchantmentDetails.descriptionKey("custom.name","enchantment.test.edge",3,Set.of("custom.name.desc.3","custom.name.desc","enchantment.test.edge.desc")::contains).orElseThrow().equals("custom.name.desc.3"),"Level-specific custom name key not preferred");
                    require(EnchantmentDetails.descriptionKey(null,"enchantment.test.edge",3,Set.of("enchantment.test.edge.info")::contains).isPresent(),"Info fallback missing");
                    require(EnchantmentDetails.descriptionKey(null,"missing",3,key->false).isEmpty(),"Missing language entry exposed a raw key");
                    config.syncedEnchantmentEffects=false;
                    require(EnchantmentDetails.describe(holder,3,false,config,client.player.registryAccess()).toString().contains("saoui.enchant.unknown"),"Disabled parser still exposed effect rows");
                    config.serverEnchantmentLore=true;
                    String[] expected={"50%","强力击退","多支箭"};
                    for(int i=0;i<3;i++){
                        var sample=client.player.getInventory().getItem(i+1);var before=sample.copy();
                        String supplied=ServerItemDescriptions.describe(sample,config).toString();
                        require(supplied.contains(expected[i]),"Real server item lore missing: "+supplied);
                        require(ItemStack.matches(before,sample),"Description provider mutated native components");
                        config.serverEnchantmentLore=false;
                        require(ServerItemDescriptions.describe(sample,config).isEmpty(),"Disabled lore provider still returned rows");
                        config.serverEnchantmentLore=true;
                    }
                    var decorative=new ItemStack(Items.CLOCK);
                    decorative.set(net.minecraft.core.component.DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(java.util.List.of(net.minecraft.network.chat.Component.literal("重铸 I"))));
                    require(ServerItemDescriptions.describe(decorative,config).isEmpty(),"Unenchanted decorative lore was advertised as enchantment data");
                    var longLore=client.player.getInventory().getItem(1).copy();
                    longLore.set(net.minecraft.core.component.DataComponents.LORE,new net.minecraft.world.item.component.ItemLore(java.util.Collections.nCopies(65,net.minecraft.network.chat.Component.literal("说明".repeat(400)))));
                    var bounded=ServerItemDescriptions.describe(longLore,config);
                    require(bounded.size()==65&&bounded.getFirst().getString().codePointCount(0,bounded.getFirst().getString().length())==512&&bounded.getLast().toString().contains("item_lore_omitted"),"Untrusted item lore was not bounded or labeled");
                    config.syncedEnchantmentEffects=true;config.homeModule="equipment";config.parallaxEnabled=false;client.options.pauseOnLostFocus=false;
                });
                c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());
                c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.waitTick();c.takeScreenshot("sao-server-enchantment-effects");
                c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
                world.runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();var first=p.getInventory().getItem(0);p.getInventory().setItem(0,p.getInventory().getItem(1));p.getInventory().setItem(1,first);p.inventoryMenu.broadcastChanges();});
                c.waitFor(client->client.player.getInventory().getItem(0).is(Items.SHIELD));
                c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());
                c.takeScreenshot("sao-server-item-lore");
                c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
                c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));c.clickScreenButton("settings.saoui.category.compat");
                SettingsNavigation.click(c,"settings.saoui.synced_enchantment_effects");SettingsNavigation.click(c,"settings.saoui.enchantment_descriptions");SettingsNavigation.click(c,"settings.saoui.server_enchantment_lore");
                c.runOnClient(client->require(SaoUiClient.config().syncedEnchantmentEffects&&SaoUiClient.config().enchantmentDescriptions&&SaoUiClient.config().serverEnchantmentLore,"Unsaved compatibility draft leaked into live settings"));
                SettingsNavigation.click(c,"gui.cancel");
                c.runOnClient(client->require(SaoUiClient.config().syncedEnchantmentEffects&&SaoUiClient.config().enchantmentDescriptions&&SaoUiClient.config().serverEnchantmentLore,"Cancelled compatibility draft changed live settings"));
            }
            try(var fresh=c.worldBuilder().create()){
                fresh.getClientLevel().waitForChunksRender();
                c.runOnClient(client->require(client.player.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(EDGE).isEmpty(),"Server-only enchantment leaked into a different world"));
            }
            SaoUiClient.LOGGER.info("SAO server item lore passed: three real sanitized Aiyatsbus fixtures over native TCP, current item text, component conservation, non-enchanted exclusion, bounded output, independent switch and cancelled settings");
            SaoUiClient.LOGGER.info("SAO server enchantments passed: server-save-only datapack, native registry decoding, level values, probability, conditional functions, vanilla override, description keys, independent switches and fresh-world isolation");
        }finally{c.runOnClient(client->{try{SaoUiClient.saveConfig(original);}catch(java.io.IOException e){throw new RuntimeException(e);}});}
    }
    private static void writePack(Path save){
        try{
            Path pack=save.resolve("datapacks/saoui-server-enchantment-test");Files.createDirectories(pack.resolve("data/saoui_test/enchantment"));Files.createDirectories(pack.resolve("data/minecraft/enchantment"));Files.createDirectories(pack.resolve("data/saoui_test/function"));
            Files.writeString(pack.resolve("pack.mcmeta"),"""
                {"pack":{"description":"SAO server-only registry regression","min_format":[80,0],"max_format":[999,0]}}
                """);
            for(String id:java.util.List.of("indestructibility","annihilate","succession","_technical/infernal_infusion")){
                Path file=pack.resolve("data/minecraft/enchantment/"+id+".json");Files.createDirectories(file.getParent());
                String name=id.equals("indestructibility")?"重铸":id.equals("annihilate")?"威慑":id.equals("succession")?"迭累":"地狱灌注";
                Files.writeString(file,"{\"description\":{\"text\":\""+name+"\"},\"supported_items\":[\"minecraft:shield\",\"minecraft:iron_sword\",\"minecraft:bow\"],\"weight\":1,\"max_level\":3,\"min_cost\":{\"base\":1,\"per_level_above_first\":0},\"max_cost\":{\"base\":10,\"per_level_above_first\":0},\"anvil_cost\":1,\"slots\":[\"mainhand\"]}");
            }
            String definition="""
                {"description":{"text":"Server Edge"},"supported_items":["minecraft:diamond_sword"],"weight":1,"max_level":5,"min_cost":{"base":1,"per_level_above_first":1},"max_cost":{"base":20,"per_level_above_first":1},"anvil_cost":1,"slots":["mainhand"],"effects":{
                  "minecraft:damage":[{"effect":{"type":"minecraft:add","value":{"type":"minecraft:linear","base":2,"per_level_above_first":1.25}}}],
                  "minecraft:item_damage":[{"effect":{"type":"minecraft:remove_binomial","chance":0.75}}],
                  "minecraft:post_attack":[{"enchanted":"attacker","affected":"victim","requirements":{"condition":"minecraft:random_chance","chance":0.25},"effect":{"type":"minecraft:run_function","function":"saoui_test:uninspectable"}}]
                }}
                """;
            Files.writeString(pack.resolve("data/saoui_test/enchantment/server_edge.json"),definition);
            Files.writeString(pack.resolve("data/saoui_test/function/uninspectable.mcfunction"),"# Server-only function; deliberately not interpreted by the UI.\n");
            Files.writeString(pack.resolve("data/minecraft/enchantment/sharpness.json"),"""
                {"description":{"translate":"enchantment.minecraft.sharpness"},"supported_items":["minecraft:diamond_sword"],"weight":1,"max_level":5,"min_cost":{"base":1,"per_level_above_first":1},"max_cost":{"base":20,"per_level_above_first":1},"anvil_cost":1,"slots":["mainhand"],"effects":{"minecraft:damage":[{"effect":{"type":"minecraft:add","value":{"type":"minecraft:linear","base":9,"per_level_above_first":2}}}]}}
                """);
        }catch(java.io.IOException e){throw new RuntimeException(e);}
    }
    private static java.util.List<ItemStack> itemSamples(net.minecraft.core.HolderLookup.Provider registries){
        try(var stream=ServerEnchantmentsGameTest.class.getResourceAsStream("/saoui/server-item-lore-samples.json")){
            var data=com.google.gson.JsonParser.parseString(new String(stream.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonArray();
            var ops=registries.createSerializationContext(com.mojang.serialization.JsonOps.INSTANCE);
            var result=new java.util.ArrayList<ItemStack>();
            for(var entry:data)result.add(ItemStack.CODEC.parse(ops,entry).getOrThrow());
            return java.util.List.copyOf(result);
        }catch(java.io.IOException e){throw new RuntimeException(e);}
    }
    private static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
}
