package io.github.saoui;

import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetTooltipHolder;
import net.minecraft.client.gui.screens.Screen;

/** Checks actual installed native tooltips on every settings surface, in both shipped languages. */
public final class SettingsHelpGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c){
        String oldLanguage=c.computeOnClient(client->client.getLanguageManager().getSelected());
        String before=c.computeOnClient(client->new com.google.gson.Gson().toJson(SaoUiClient.config()));
        var path=FabricLoader.getInstance().getConfigDir().resolve("saoui.json");
        String disk=read(path);
        try{
            for(String language:List.of("zh_cn","en_us")){
                language(c,language);
                c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));
                c.clickScreenButton("settings.saoui.category.interface");
                c.runOnClient(client->{var option=SettingsNavigation.widget(client.gui.screen(),"settings.saoui.all_containers");explanation(option,client);});
                int checked=checkScreen(c);
                if(language.equals("zh_cn")){
                    hover(c,"settings.saoui.all_containers","sao-help-all-containers");
                    hover(c,"settings.saoui.container_crafting","sao-help-container-crafting");
                    hover(c,"settings.saoui.blur","sao-help-blur");
                    hover(c,"settings.saoui.theme.hex","sao-help-color-input");
                }
                SettingsNavigation.click(c,"settings.saoui.all_containers");checked+=checkScreen(c);
                for(String category:List.of("hud","compat")){
                    SettingsNavigation.click(c,"gui.back");c.clickScreenButton("settings.saoui.category."+category);checked+=checkScreen(c);
                }
                SettingsNavigation.click(c,"gui.back");checked+=checkScreen(c);
                List<Supplier<Screen>> factories=List.of(
                    ()->new SaoModuleSettingsScreen(null),
                    ()->new SaoContainerSettingsScreen(null),
                    ()->new SaoHudLayoutScreen(null,SaoUiClient.config(),next->{}),
                    ()->new SaoContainerLayoutScreen(null,SaoUiClient.config().containers.defaults,next->{}),
                    ()->new SaoThemeSettingsScreen(null,SaoUiClient.config().theme,next->{}),
                    ()->new SaoEffectsSettingsScreen(null,SaoUiClient.config(),next->{}),
                    ()->new SaoFeatureSettingsScreen(null,SaoUiClient.config().copy()),
                    ()->new SaoHudSettingsScreen(null,SaoUiClient.config().hud,next->{})
                );
                for(var factory:factories){
                    c.runOnClient(client->client.gui.setScreen(factory.get()));c.waitTick();checked+=checkScreen(c);
                    if(c.computeOnClient(client->client.gui.screen() instanceof SaoModuleSettingsScreen)&&language.equals("zh_cn"))hover(c,"settings.saoui.module_up","sao-help-disabled-module");
                    if(c.computeOnClient(client->client.gui.screen() instanceof SaoContainerSettingsScreen)){
                        if(language.equals("zh_cn"))hover(c,"settings.saoui.containers.scope.location","sao-help-disabled-location");
                        for(int i=0;i<8;i++){
                            boolean next=c.computeOnClient(client->client.gui.screen().children().stream().filter(SaoButton.class::isInstance).map(SaoButton.class::cast).anyMatch(w->w.getMessage().getString().equals("›")&&w.active));
                            if(!next)break;c.clickScreenButton("›");checked+=checkScreen(c);
                        }
                    }
                }
                check(checked>=130,"Too few settings controls checked: "+checked);
                SaoUiClient.LOGGER.info("SAO settings explanations passed for {}: {} actual button/slider/input tooltips, dynamic block pages and disabled controls",language,checked);
            }
            c.runOnClient(client->check(before.equals(new com.google.gson.Gson().toJson(SaoUiClient.config())),"Hovering/settings browsing mutated live configuration"));
            check(disk.equals(read(path)),"Hovering/settings browsing wrote configuration to disk");
            SaoUiClient.LOGGER.info("SAO settings help passed: full settings and editor coverage, independent explanatory text, both languages, native pointer hover/screenshots, disabled controls, rebuilds and no config mutation");
        }finally{c.runOnClient(client->client.gui.setScreen(null));language(c,oldLanguage);}
    }
    private static int checkScreen(ClientGameTestContext c){return c.computeOnClient(client->{int count=0;for(var w:SettingsNavigation.widgets(client.gui.screen()))if(w instanceof SaoButton||w instanceof AbstractSliderButton||w instanceof EditBox){explanation(w,client);count++;}return count;});}
    private static String explanation(AbstractWidget w,Minecraft client){
        Tooltip tooltip=holder(w).get();check(tooltip!=null,"Missing explanation: "+w.getMessage());
        var text=new StringBuilder();for(var line:tooltip.toCharSequence(client))line.accept((index,style,codePoint)->{text.appendCodePoint(codePoint);return true;});
        String description=text.toString();check(description.length()>=20,"Explanation too short: "+w.getMessage()+" -> "+description);
        check(!description.replace(" ","").equals(w.getMessage().getString().replace(" ","")),"Tooltip only repeats its setting label: "+w.getMessage().getString());
        check(!description.contains(".help"),"Unresolved explanation key: "+description);return description;
    }
    private static WidgetTooltipHolder holder(AbstractWidget widget){try{var f=AbstractWidget.class.getDeclaredField("tooltip");f.setAccessible(true);return (WidgetTooltipHolder)f.get(widget);}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
    private static void hover(ClientGameTestContext c,String key,String name){
        SettingsNavigation.expose(c,key);
        double[] point=c.computeOnClient(client->{var screen=client.gui.screen();var w=SettingsNavigation.widget(screen,key);var win=client.getWindow();return new double[]{(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/screen.width,(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/screen.height};});
        c.getInput().setCursorPos(point[0],point[1]);long started=net.minecraft.util.Util.getMillis();c.waitFor(client->net.minecraft.util.Util.getMillis()-started>=600);c.waitTicks(2);
        c.runOnClient(client->{var w=SettingsNavigation.widget(client.gui.screen(),key);explanation(w,client);try{var f=WidgetTooltipHolder.class.getDeclaredField("wasDisplayed");f.setAccessible(true);check(f.getBoolean(holder(w)),"Native hover did not display explanation: "+key);}catch(ReflectiveOperationException e){throw new AssertionError(e);}});
        c.takeScreenshot(name);
    }
    private static void language(ClientGameTestContext c,String code){var reload=c.computeOnClient(client->{client.getLanguageManager().setSelected(code);return client.reloadResourcePacks();});c.waitFor(client->reload.isDone());reload.join();c.waitFor(client->client.gui.overlay()==null);}
    private static String read(java.nio.file.Path path){try{return java.nio.file.Files.exists(path)?java.nio.file.Files.readString(path):"<missing>";}catch(java.io.IOException e){throw new RuntimeException(e);}}
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
