package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.List;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Targeted acceptance for the usability update; no optional-mod compatibility fixtures. */
public final class UsabilityGameTest implements FabricClientGameTest {
 @Override public void runTest(ClientGameTestContext c){
  var original=c.computeOnClient(client->SaoUiClient.config().copy());var lang=c.computeOnClient(client->client.getLanguageManager().getSelected());language(c,"zh_cn");
  try(var world=c.worldBuilder().create()){
   world.getConnection().waitForChunksRender();c.waitForScreen(null);
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();var r=server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);var sword=new ItemStack(Items.DIAMOND_SWORD);sword.enchant(r.getOrThrow(Enchantments.SMITE),5);sword.enchant(r.getOrThrow(Enchantments.KNOCKBACK),2);sword.enchant(r.getOrThrow(Enchantments.LOOTING),3);sword.enchant(r.getOrThrow(Enchantments.SWEEPING_EDGE),3);p.getInventory().setItem(0,sword);p.getInventory().setItem(1,new ItemStack(Items.BOOK));p.getInventory().setItem(2,new ItemStack(Items.BOW));var pick=new ItemStack(Items.DIAMOND_PICKAXE);pick.setDamageValue(pick.getMaxDamage()-7);p.getInventory().setItem(3,pick);p.getInventory().setItem(4,new ItemStack(Items.APPLE,5));p.getInventory().setSelectedSlot(3);p.inventoryMenu.broadcastChanges();});
   c.waitFor(client->client.player.getInventory().getItem(0).isEnchanted());
   var time=new java.util.concurrent.atomic.AtomicLong(1000);
   c.runOnClient(client->{var cfg=new SaoConfig();cfg.homeModule="equipment";cfg.parallaxEnabled=false;save(cfg);client.gui.setScreen(new SaoMenuScreen(time::get));});
   c.runOnClient(client->check(!((SaoMenuScreen)client.gui.screen()).isAnimationSettled(),"Menu ignored initial visual transition"));time.addAndGet(600);c.waitTicks(2);
   c.runOnClient(client->{check(((SaoMenuScreen)client.gui.screen()).isAnimationSettled(),"Menu still blocks input after its standard opening");check(!SaoUiClient.config().equipmentPortrait,"Equipment portrait occupies reading space by default");check(EnchantmentPanel.W>=330&&EquipmentLayout.TEXT_SCALE>1.1f,"Reading column did not gain width and text size");});shot(c,"sao-usability-equipment");
   select(c,1);click(c,screen->(AbstractWidget)field(screen,"maxEnchantments"));
   point(c,EnchantmentPanel.X+40,EnchantmentPanel.Y+EnchantmentPanel.BODY_Y+20);c.getInput().pressKey(InputConstants.KEY_END);c.waitTick();
   int scroll=c.computeOnClient(client->panel(client.gui.screen()).scrollPosition());check(scroll>0,"Reader keyboard scrolling was captured by the checkbox");
   c.clickScreenButton("root.saoui.inventory");time.addAndGet(600);c.waitTicks(2);
   var before=c.computeOnClient(client->client.player.getInventory().getItem(0).copy());
   click(c,s->s.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(w->w.visible&&w.menuSlot()==36).findFirst().orElseThrow());
   c.runOnClient(client->check(!client.player.inventoryMenu.getCarried().isEmpty(),"Native inventory pickup stopped working"));c.waitTicks(8);
   click(c,s->s.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(w->w.visible&&w.menuSlot()==36).findFirst().orElseThrow());
   c.runOnClient(client->check(client.player.inventoryMenu.getCarried().isEmpty()&&ItemStack.matches(before,client.player.getInventory().getItem(0)),"Native item return changed components or cursor: carried="+client.player.inventoryMenu.getCarried()+", actual="+client.player.getInventory().getItem(0)+", expected="+before));
   c.clickScreenButton("root.saoui.equipment");time.addAndGet(600);c.waitTicks(2);
   c.runOnClient(client->{check((int)field(field(client.gui.screen(),"panels"),"selectedItem")==1,"Page switch forgot selected book");check(panel(client.gui.screen()).scrollPosition()==scroll,"Page switch lost reading position");var screen=client.gui.screen();screen.resize(screen.width,screen.height);});time.addAndGet(600);c.waitTicks(2);
   c.runOnClient(client->{check((int)field(field(client.gui.screen(),"panels"),"selectedItem")==1&&panel(client.gui.screen()).scrollPosition()==scroll,"Rebuild lost browsing state");});shot(c,"sao-usability-book-preview");
   var menu=c.computeOnClient(client->(SaoMenuScreen)client.gui.screen());
   c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(menu)));c.clickScreenButton("settings.saoui.category.interface");
   int options=c.computeOnClient(client->((SaoSettingsScreen)client.gui.screen()).options().size());
   c.runOnClient(client->((net.minecraft.client.gui.components.EditBox)field(client.gui.screen(),"search")).setValue("立绘"));c.waitTick();
   c.runOnClient(client->{var s=(SaoSettingsScreen)client.gui.screen();check(s.options().size()<options,"Search did not filter options");check(s.options().stream().anyMatch(w->key(w).equals("settings.saoui.equipment_portrait")),"Search missed the named setting");});shot(c,"sao-usability-search");
   SettingsNavigation.click(c,"settings.saoui.equipment_portrait");c.runOnClient(client->{check(!SaoUiClient.config().equipmentPortrait,"Draft edit leaked into live settings");check((boolean)field(client.gui.screen(),"dirty"),"Unsaved indicator was not updated");});
   c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.runOnClient(client->check(client.gui.screen() instanceof SaoSettingsScreen&&((String)field(client.gui.screen(),"query")).isEmpty(),"Escape did not clear search first"));shot(c,"sao-usability-unsaved");
   c.clickScreenButton("settings.saoui.save_return");c.waitForScreen(SaoMenuScreen.class);time.addAndGet(600);c.waitTicks(2);c.runOnClient(client->check(SaoUiClient.config().equipmentPortrait,"Explicit save did not commit draft"));
   c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(menu)));c.clickScreenButton("settings.saoui.category.interface");SettingsNavigation.click(c,"settings.saoui.equipment_portrait");c.clickScreenButton("settings.saoui.discard");c.waitForScreen(SaoMenuScreen.class);time.addAndGet(600);c.waitTicks(2);c.runOnClient(client->check(SaoUiClient.config().equipmentPortrait,"Discard committed a draft change"));
   c.runOnClient(client->{var cfg=SaoUiClient.config().copy();cfg.equipmentPortrait=false;save(cfg);});
   c.clickScreenButton("root.saoui.settings");time.addAndGet(600);c.waitTicks(2);c.clickScreenButton("menu.saoui.menu_layout");time.addAndGet(600);c.waitForScreen(SaoModuleSettingsScreen.class);c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.waitForScreen(SaoSettingsScreen.class);c.clickScreenButton("settings.saoui.discard");c.waitForScreen(SaoMenuScreen.class);time.addAndGet(600);c.waitTicks(2);
   c.clickScreenButton("menu.saoui.containers");time.addAndGet(600);c.waitForScreen(SaoContainerSettingsScreen.class);c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.waitForScreen(SaoSettingsScreen.class);c.clickScreenButton("settings.saoui.discard");c.waitForScreen(SaoMenuScreen.class);time.addAndGet(600);c.waitTicks(2);
   c.runOnClient(client->client.gui.setScreen(new SaoHudLayoutScreen(menu,SaoUiClient.config(),next->{throw new AssertionError("HUD preview committed without apply");})));shot(c,"sao-usability-hud-context");c.runOnClient(client->check((boolean)field(client.gui.screen(),"context"),"HUD editor lacks placement references"));c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.waitForScreen(SaoMenuScreen.class);time.addAndGet(600);c.waitTicks(2);
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.addEffect(new MobEffectInstance(MobEffects.POISON,12000));p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS,6000));p.addEffect(new MobEffectInstance(MobEffects.SPEED,18000));p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,18000));p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,18000));});c.waitFor(client->client.player.getActiveEffects().size()>=5);
   c.runOnClient(client->client.player.getInventory().setSelectedSlot(3));
   c.clickScreenButton("root.saoui.profile");time.addAndGet(600);c.waitTicks(2);shot(c,"sao-usability-profile");c.runOnClient(client->check(PlayerStatusPanel.effects(client.player).getFirst().getEffect().value().getCategory()==net.minecraft.world.effect.MobEffectCategory.HARMFUL,"Important harmful effect was hidden by name order"));
   c.clickScreenButton("profile.saoui.open_effects");time.addAndGet(600);c.waitForScreen(SaoStatusEffectsScreen.class);c.runOnClient(client->check(((SaoSettingsList)field(client.gui.screen(),"list")).children().size()>=5,"Full status list still hides effects"));shot(c,"sao-usability-all-effects");c.getInput().pressKey(InputConstants.KEY_ESCAPE);c.waitForScreen(SaoMenuScreen.class);time.addAndGet(600);c.waitTicks(2);
   c.clickScreenButton("profile.saoui.locate_wear");time.addAndGet(600);c.waitTicks(2);c.runOnClient(client->{var p=field(client.gui.screen(),"panels");int index=(int)field(p,"selectedItem");var items=(List<CombatItems.Entry>)field(p,"weapons");check(items.get(index).stack().is(Items.DIAMOND_PICKAXE),"Durability link selected a different item: selected="+items.get(index).stack()+", weakest="+PlayerStatusPanel.weakest(client.player).stack());check(client.player.inventoryMenu.getCarried().isEmpty(),"Inspecting durability moved an item");});shot(c,"sao-usability-located-equipment");
   world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();for(int i=0;i<36;i++)p.getInventory().setItem(i,new ItemStack(Items.DIAMOND_SWORD));for(var slot:new net.minecraft.world.entity.EquipmentSlot[]{net.minecraft.world.entity.EquipmentSlot.HEAD,net.minecraft.world.entity.EquipmentSlot.CHEST,net.minecraft.world.entity.EquipmentSlot.LEGS,net.minecraft.world.entity.EquipmentSlot.FEET,net.minecraft.world.entity.EquipmentSlot.OFFHAND})p.setItemSlot(slot,new ItemStack(Items.DIAMOND_HELMET));p.inventoryMenu.broadcastChanges();});c.waitFor(client->((List<?>)field(field(client.gui.screen(),"panels"),"weapons")).size()==41);c.waitTicks(2);c.runOnClient(client->check(client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(w->w.visible).count()==41,"Full catalogue hides native equipment entries"));shot(c,"sao-usability-full-catalogue");
   c.runOnClient(client->{var cfg=SaoUiClient.config().copy();cfg.equipmentPortrait=true;save(cfg);});c.waitTicks(2);shot(c,"sao-usability-equipment-portrait");
   language(c,"en_us");c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(menu)));c.clickScreenButton("settings.saoui.category.interface");shot(c,"sao-usability-settings-english");c.clickScreenButton("settings.saoui.discard");
   SaoUiClient.LOGGER.info("SAO usability passed: readable equipment layout, native inventory conservation, selection/scroll across pages and resize, search, save/discard and shortcut drafts, HUD references, harmful-effect priority, complete status list and equipment locate");
  }finally{c.runOnClient(client->{client.gui.setScreen(null);save(original);});language(c,lang);}
 }
 private static String key(AbstractWidget widget){return widget.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t?t.getKey():"";}
 private static void click(ClientGameTestContext c,java.util.function.Function<net.minecraft.client.gui.screens.Screen,AbstractWidget> find){double[] p=c.computeOnClient(client->{var s=client.gui.screen();var w=find.apply(s);var win=client.getWindow();return new double[]{(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width,(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};});c.getInput().setCursorPos(p[0],p[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTicks(2);}
 private static void point(ClientGameTestContext c,double x,double y){double[] p=c.computeOnClient(client->{var screen=client.gui.screen();var q=projection(screen).project(x,y);var win=client.getWindow();return new double[]{q.x()*win.getScreenWidth()/screen.width,q.y()*win.getScreenHeight()/screen.height};});c.getInput().setCursorPos(p[0],p[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTick();}
 private static void select(ClientGameTestContext c,int index){click(c,s->s.children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(w->w.visible).toList().get(index));}
 private static MenuProjection projection(Object screen){try{var m=SaoMenuScreen.class.getDeclaredMethod("projection",long.class);m.setAccessible(true);var clock=(java.util.function.LongSupplier)field(screen,"clock");return (MenuProjection)m.invoke(screen,clock.getAsLong());}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
 private static EnchantmentPanel panel(Object screen){return (EnchantmentPanel)field(field(screen,"panels"),"enchantments");}
 private static Object field(Object o,String key){try{var f=o.getClass().getDeclaredField(key);f.setAccessible(true);return f.get(o);}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
 private static void save(SaoConfig config){try{SaoUiClient.saveConfig(config);}catch(java.io.IOException e){throw new RuntimeException(e);}}
 private static void language(ClientGameTestContext c,String code){var future=c.computeOnClient(client->{client.getLanguageManager().setSelected(code);return client.reloadResourcePacks();});c.waitFor(client->future.isDone());future.join();c.waitFor(client->client.gui.overlay()==null);}
 private static void shot(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.getInput().setCursorPos(4,4);c.waitTicks(2);c.takeScreenshot(name);}
 private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
