package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class SettingsHierarchyGameTest implements FabricClientGameTest {
    @Override @SuppressWarnings("unchecked") public void runTest(ClientGameTestContext c) {
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        c.runOnClient(client->{try{SaoUiClient.saveConfig(new SaoConfig());}catch(java.io.IOException e){throw new RuntimeException(e);}});
        var receiver=ServerPlayNetworking.unregisterGlobalReceiver(CraftingRequest.TYPE.id());
        check(receiver!=null,"Missing original server receiver");
        try(var world=c.worldBuilder().create()){
            world.getConnection().waitForChunksRender();c.waitForScreen(null);
            c.runOnClient(client->{SaoUiClient.config().replaceAllContainers=true;client.gui.setScreen(new SaoSettingsScreen(null));});
            check(c.computeOnClient(client->SettingsNavigation.widgets(client.gui.screen()).stream().filter(w->w.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t && t.getKey().startsWith("settings.saoui.category.")).count())==4,"Overview must have exactly four categories");
            shot(c,"sao-settings-categories");SettingsNavigation.click(c,"settings.saoui.category.interface");
            c.runOnClient(client->{var screen=(SaoSettingsScreen)client.gui.screen();for(String key:new String[]{"ui_scale","opacity","parallax","blur","armor_slots","crafting","container_crafting","all_containers","theme.font","theme.hex"})SettingsNavigation.widget(screen,"settings.saoui."+key);check(screen.options().stream().noneMatch(w->w.getMessage().getContents() instanceof net.minecraft.network.chat.contents.TranslatableContents t && (t.getKey().equals("settings.saoui.effects")||t.getKey().startsWith("settings.saoui.section."))),"Intermediate group buttons remained");});
            shot(c,"sao-settings-interface-direct");SettingsNavigation.click(c,"settings.saoui.theme.font");shot(c,"sao-settings-interface-colors");
            c.getInput().pressKey(InputConstants.KEY_ESCAPE);check(c.computeOnClient(client->((SaoSettingsScreen)client.gui.screen()).page())==SaoSettingsScreen.Page.HOME,"Escape did not return to overview");
            SettingsNavigation.click(c,"settings.saoui.category.compat");c.runOnClient(client->SettingsNavigation.widget(client.gui.screen(),"settings.saoui.ipn"));shot(c,"sao-settings-compat-direct");c.getInput().pressKey(InputConstants.KEY_ESCAPE);
            SettingsNavigation.click(c,"settings.saoui.category.menu");c.waitForScreen(SaoModuleSettingsScreen.class);
            c.clickScreenButton(Component.translatable("settings.saoui.module_home",Component.translatable(MenuModule.INVENTORY.titleKey())).getString());SettingsNavigation.click(c,"gui.done");
            check(c.computeOnClient(client->SaoUiClient.config().homeModule).equals(MenuModule.PROFILE.id()),"Menu category wrote config early");
            SettingsNavigation.click(c,"settings.saoui.container_rules");c.clickScreenButton(Component.translatable("settings.saoui.containers.enabled",Component.translatable("options.on")).getString());SettingsNavigation.click(c,"gui.done");
            check(c.computeOnClient(client->SaoUiClient.config().containers.defaults.enabled),"Rule editor wrote config early");SettingsNavigation.click(c,"gui.cancel");
            check(c.computeOnClient(client->SaoUiClient.config().homeModule).equals(MenuModule.PROFILE.id()),"Cancel leaked menu home");
            c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));SettingsNavigation.expose(c,"settings.saoui.scale");
            c.runOnClient(client->{var screen=client.gui.screen();for(String key:new String[]{"hud","scale","smooth","smoothing","bar.health","bar.hide_vanilla_health","bar.hunger","bar.experience","bar.armor","bar.hide_vanilla_crosshair"})SettingsNavigation.widget(screen,"settings.saoui."+key);var slider=(SaoSlider)SettingsNavigation.widget(screen,"settings.saoui.scale");for(int i=0;i<400;i++)slider.keyPressed(new KeyEvent(InputConstants.KEY_LEFT,0,0));check(slider.amount()==.2f,"Slider went below .20");});
            shot(c,"sao-settings-hud-direct");SettingsNavigation.click(c,"gui.cancel");
            c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));SettingsNavigation.click(c,"settings.saoui.category.menu");c.clickScreenButton(Component.translatable("settings.saoui.module_home",Component.translatable(MenuModule.INVENTORY.titleKey())).getString());SettingsNavigation.click(c,"gui.done");
            SettingsNavigation.click(c,"settings.saoui.container_rules");c.clickScreenButton(Component.translatable("settings.saoui.containers.enabled",Component.translatable("options.on")).getString());SettingsNavigation.click(c,"gui.done");
            c.runOnClient(client->{var screen=client.gui.screen();screen.resize(screen.width,screen.height);});check(c.computeOnClient(client->((SaoSettingsScreen)client.gui.screen()).page())==SaoSettingsScreen.Page.INTERFACE,"Resize lost category");SettingsNavigation.click(c,"gui.done");
            check(c.computeOnClient(client->SaoUiClient.config().homeModule).equals("inventory")&&!c.computeOnClient(client->SaoUiClient.config().containers.defaults.enabled),"Save did not commit category drafts");
            check(!c.computeOnClient(client->ClientPlayNetworking.canSend(CraftingRequest.TYPE)),"Server still advertises crafting");
            world.getServer().runOnServer(server->server.getPlayerList().getPlayers().getFirst().openMenu(new SimpleMenuProvider((id,inv,p)->{var items=new SimpleContainer(27);items.setItem(0,new ItemStack(Items.EMERALD,5));return ChestMenu.threeRows(id,inv,items);},Component.literal("Server without SAO crafting"))));
            c.waitForScreen(ContainerScreen.class);c.waitFor(client->BlockFloatingUi.ready(client.gui.screen()));c.waitTicks(5);
            c.runOnClient(client->{var screen=client.gui.screen();check(!ContainerCraftingUi.visible(screen),"Unsupported server showed crafting panel");check(FlatContainerUi.bounds(screen).equals(FlatContainerUi.nativeBounds(screen)),"Hidden crafting reserved layout space");check(client.player.containerMenu.slots.size()==63 && ContainerCraftingState.get(client.player.containerMenu)==null,"Unsupported server acquired fake crafting slots");});
            shot(c,"sao-unsupported-server-no-crafting");BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);BlockUiGameTest.clickSlot(c,27,InputConstants.MOUSE_BUTTON_LEFT);world.getConnection().waitForServerboundPackets();
            world.getServer().runOnServer(server->check(server.getPlayerList().getPlayers().getFirst().getInventory().countItem(Items.EMERALD)==5,"Unsupported-server inventory transfer failed"));
            c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
            SaoUiClient.LOGGER.info("SAO settings hierarchy passed: four categories and direct options, native scroll list, inline effects/colors/HUD/compatibility, Back/Escape, resize, nested module/rule drafts, cancel/save, .20 minimum; server capability genuinely unadvertised, no panel/no reserved width/no fake slots, native transfer");
        } finally {
            ServerPlayNetworking.registerGlobalReceiver(CraftingRequest.TYPE,(ServerPlayNetworking.PlayPayloadHandler<CraftingRequest>)receiver);
            c.runOnClient(client->{try{SaoUiClient.saveConfig(original);}catch(java.io.IOException e){throw new RuntimeException(e);}});
        }
    }
    private static void shot(ClientGameTestContext c,String name){c.getInput().setCursorPos(4,4);c.waitTicks(2);c.takeScreenshot(name);}
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
