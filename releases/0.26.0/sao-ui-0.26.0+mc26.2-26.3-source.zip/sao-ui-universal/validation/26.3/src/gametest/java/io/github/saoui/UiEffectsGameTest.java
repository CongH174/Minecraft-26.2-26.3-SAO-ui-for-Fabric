package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Delivered-JAR acceptance for physical scaling, exact sliders and live native slot interaction. */
public final class UiEffectsGameTest implements FabricClientGameTest {
    @Override public void runTest(ClientGameTestContext c) {
        var original=c.computeOnClient(client->SaoUiClient.config().copy());
        c.runOnClient(client->{SaoUiClient.config().parallaxEnabled=SaoUiClient.config().animationsEnabled=SaoUiClient.config().blurEnabled=true;});
        int oldGui=c.computeOnClient(client->client.options.guiScale().get());
        int oldBlur=c.computeOnClient(client->client.options.getMenuBackgroundBlurriness());
        int[] size=c.computeOnClient(client->new int[]{client.getWindow().getScreenWidth(),client.getWindow().getScreenHeight()});
        try(var world=c.worldBuilder().create()) {
            world.getConnection().waitForChunksRender();c.waitForScreen(null);
            c.runOnClient(client->{client.options.pauseOnLostFocus=false;client.getWindow().setWindowed(1280,720);});
            c.waitFor(client->client.getWindow().getScreenWidth()==1280 && client.getWindow().getScreenHeight()==720);
            openSettings(c);SettingsNavigation.click(c,"settings.saoui.category.interface");
            double[] pointer=c.computeOnClient(client->{var screen=client.gui.screen();var slider=SettingsNavigation.widgets(screen).stream().filter(SaoSlider.class::isInstance).map(SaoSlider.class::cast).findFirst().orElseThrow();var win=client.getWindow();return new double[]{(slider.getX()+slider.getWidth()*.8)*win.getScreenWidth()/screen.width,(slider.getY()+10.0)*win.getScreenHeight()/screen.height};});
            c.getInput().setCursorPos(pointer[0],pointer[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTick();
            check(c.computeOnClient(client->SettingsNavigation.widgets(client.gui.screen()).stream().filter(SaoSlider.class::isInstance).map(SaoSlider.class::cast).findFirst().orElseThrow().amount())>1.5f,"Real slider mouse input failed");
            exact(c,"ui_scale",1.23f);exact(c,"blur",.67f);exact(c,"opacity",1.42f);exact(c,"animation_speed",.2f);
            capture(c,"sao-effects-sliders");SettingsNavigation.click(c,"gui.cancel");
            check(c.computeOnClient(client->SaoUiClient.config().uiScale)==original.uiScale,"Cancel leaked effects");
            openSettings(c);SettingsNavigation.click(c,"settings.saoui.category.interface");exact(c,"ui_scale",1.23f);exact(c,"parallax",.2f);exact(c,"blur",.67f);exact(c,"opacity",1.42f);exact(c,"animation_speed",.2f);
            SettingsNavigation.click(c,"settings.saoui.animations_enabled");SettingsNavigation.click(c,"settings.saoui.parallax_enabled");
            exact(c,"scale",.81f);exact(c,"smoothing",1.24f);SettingsNavigation.click(c,"settings.saoui.theme.font");
            c.runOnClient(client->SettingsNavigation.widgets(client.gui.screen()).stream().filter(EditBox.class::isInstance).map(EditBox.class::cast).findFirst().orElseThrow().setValue("#2266AA"));
            capture(c,"sao-font-editor");SettingsNavigation.click(c,"gui.done");
            c.runOnClient(client->{var disk=new ConfigStore(FabricLoader.getInstance().getConfigDir().resolve("saoui.json")).load();
                check(disk.uiScale==1.23f && disk.scale==.81f && disk.blurStrength==.67f && disk.uiOpacity==1.42f && disk.healthSmoothing==1.24f,"Effects did not persist independently");
                check(disk.theme.customFont && disk.theme.font==0x2266AA && ThemePalette.ink()==0xFF2266AA,"Custom font did not persist/apply");
                SaoUiClient.config().homeModule="inventory";SaoUiClient.config().replaceAllContainers=true;
            });
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getInventory().clearContent();p.getInventory().setItem(9,new ItemStack(Items.DIAMOND,7));p.inventoryMenu.broadcastChanges();});
            c.waitFor(client->client.player.getInventory().getItem(9).getCount()==7);
            double baseline=0;
            for(int gui:new int[]{1,2,3}) {
                gui(c,gui);open(c);
                double width=menuWidth(c);if(gui==1)baseline=width;else check(Math.abs(width-baseline)<4,"Menu followed vanilla scale: "+baseline+" -> "+width);
                capture(c,"sao-independent-gui-"+gui);close(c);
            }
            open(c);PlayerCraftingGameTest.click(c,9,InputConstants.MOUSE_BUTTON_LEFT,0);PlayerCraftingGameTest.click(c,10,InputConstants.MOUSE_BUTTON_LEFT,0);
            c.waitFor(client->client.player.getInventory().getItem(10).getCount()==7);close(c);world.getConnection().waitForServerboundPackets();
            for(float blur:new float[]{0,1,2}) {
                c.runOnClient(client->{SaoUiClient.config().blurEnabled=blur>0;SaoUiClient.config().blurStrength=Math.max(.2f,blur);SaoUiClient.config().uiOpacity=blur==0?2:.8f;});open(c);capture(c,"sao-blur-"+(int)blur);close(c);
            }
            c.runOnClient(client->{SaoUiClient.config().uiScale=.83f;SaoUiClient.config().uiOpacity=1.6f;SaoUiClient.config().blurEnabled=true;SaoUiClient.config().blurStrength=1;});
            double containerBaseline=0;
            for(int gui:new int[]{1,2,3}) {
                gui(c,gui);world.getServer().runOnServer(server->server.getPlayerList().getPlayers().getFirst().openMenu(new SimpleMenuProvider((id,inv,p)->{var storage=new SimpleContainer(27);storage.setItem(0,new ItemStack(Items.EMERALD,5));return ChestMenu.threeRows(id,inv,storage);},Component.literal("Independent SAO size"))));
                c.waitForScreen(ContainerScreen.class);c.waitFor(client->BlockFloatingUi.ready(client.gui.screen()));c.waitTicks(3);
                double w=c.computeOnClient(client->{var screen=client.gui.screen();return FlatContainerUi.bounds(screen).width()*BlockFloatingUi.frame(screen).scale()*client.getWindow().getGuiScale();});
                if(gui==1)containerBaseline=w;else check(Math.abs(w-containerBaseline)<4,"Container followed vanilla scale: "+containerBaseline+" -> "+w);
                BlockUiGameTest.clickSlot(c,0,InputConstants.MOUSE_BUTTON_LEFT);BlockUiGameTest.clickSlot(c,27,InputConstants.MOUSE_BUTTON_LEFT);
                c.waitFor(client->client.player.containerMenu.getCarried().isEmpty());capture(c,"sao-independent-container-"+gui);close(c);world.getConnection().waitForServerboundPackets();
            }
            world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();check(p.getInventory().countItem(Items.DIAMOND)==7 && p.getInventory().countItem(Items.EMERALD)==15,"Scaled UI lost or duplicated native items");});
            check(c.computeOnClient(client->client.options.getMenuBackgroundBlurriness())==oldBlur,"SAO changed vanilla ESC blur");
            SaoUiClient.LOGGER.info("SAO UI effects passed: exact .01 keyboard sliders, real mouse slider, direct category cancel/save, font persistence, physical menu/container bounds at vanilla GUI 1/2/3, scaled native item transfers, blur 0/1/2 screenshots, vanilla options preserved");
        } finally {c.runOnClient(client->{try{SaoUiClient.saveConfig(original);}catch(java.io.IOException e){throw new RuntimeException(e);}client.options.guiScale().set(oldGui);client.getWindow().setWindowed(size[0],size[1]);client.resizeGui();});}
    }
    private static void exact(ClientGameTestContext c,String key,float target) {
        SettingsNavigation.expose(c,"settings.saoui."+key);
        c.runOnClient(client->{var s=client.gui.screen();var slider=SettingsNavigation.widgets(s).stream().filter(SaoSlider.class::isInstance).map(SaoSlider.class::cast).filter(w->w.settingKey().equals("settings.saoui."+key)).findFirst().orElseThrow();
            int steps=Math.round((target-slider.amount())*100);for(int i=0;i<Math.abs(steps);i++)slider.keyPressed(new KeyEvent(steps>0?InputConstants.KEY_RIGHT:InputConstants.KEY_LEFT,0,0));
            check(slider.amount()==target,"Slider lost exact hundredths for "+key);
        });
    }
    private static void gui(ClientGameTestContext c,int scale){c.runOnClient(client->{client.options.guiScale().set(scale);client.resizeGui();});c.waitTicks(2);check(c.computeOnClient(client->client.getWindow().getGuiScale())==scale,"Native GUI scale was not applied");}
    private static double menuWidth(ClientGameTestContext c){return c.computeOnClient(client->{var w=client.gui.screen().children().stream().filter(FloatingItemSlot.class::isInstance).map(FloatingItemSlot.class::cast).filter(s->s.menuSlot()==9).findFirst().orElseThrow();return w.getWidth()*(double)client.getWindow().getGuiScale();});}
    private static void openSettings(ClientGameTestContext c){c.runOnClient(client->client.gui.setScreen(new SaoSettingsScreen(null)));}
    private static void open(ClientGameTestContext c){c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());c.waitTicks(2);}
    private static void close(ClientGameTestContext c){c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);}
    private static void capture(ClientGameTestContext c,String name){c.getInput().setCursorPos(4,700);c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.waitTicks(3);c.takeScreenshot(name);}
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
