package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import net.minecraft.client.renderer.state.LightmapRenderState;
import net.minecraft.world.effect.MobEffects;

/** Only gamma override, native key binding and a genuinely dark room are exercised. */
public final class GammaOverrideGameTest implements FabricClientGameTest {
 @Override public void runTest(ClientGameTestContext c){
  String oldKey=c.computeOnClient(client->GammaOverride.key.saveString());double oldGamma=c.computeOnClient(client->client.options.gamma().get());
  try{
   c.runOnClient(client->{check(!GammaOverride.enabled(),"Gamma override is enabled by default");check(java.util.Arrays.asList(client.options.keyMappings).contains(GammaOverride.key),"Native controls do not contain the independent binding");GammaOverride.key.setKey(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_G));KeyMapping.resetMapping();});
   try(var world=c.worldBuilder().create()){
    world.getConnection().waitForChunksRender();c.waitForScreen(null);
    world.getServer().runOnServer(server->{var source=server.createCommandSourceStack();for(String command:new String[]{"fill -6 64 -6 6 70 6 minecraft:stone hollow","fill -5 65 5 5 68 5 minecraft:polished_andesite","setblock -3 65 4 minecraft:red_concrete","setblock 3 65 4 minecraft:blue_concrete","gamemode creative @a","tp @a 0.5 65 0.5 0 0","time set midnight","weather clear"})server.getCommands().performPrefixedCommand(source,command);});
    c.waitFor(client->client.player.blockPosition().getY()==65&&client.level.getBlockState(new net.minecraft.core.BlockPos(0,70,0)).is(net.minecraft.world.level.block.Blocks.STONE));c.waitTicks(20);world.getConnection().waitForChunksRender();
    c.runOnClient(client->{client.options.gamma().set(0.0);client.options.pauseOnLostFocus=false;check(client.level.getBrightness(net.minecraft.world.level.LightLayer.SKY,client.player.blockPosition())==0,"Room is not actually dark");check(!client.player.hasEffect(MobEffects.NIGHT_VISION),"Fixture already has night vision");});c.waitTicks(6);shot(c,"sao-gamma-off");
    c.getInput().pressKey(InputConstants.KEY_G);c.waitTicks(6);c.runOnClient(client->{check(GammaOverride.enabled(),"G did not enable gamma override");check(extract(client).brightness==GammaOverride.MAX_GAMMA,"Real native lightmap extraction did not apply the override");check(client.options.gamma().get()==0.0,"Override changed the user's brightness setting");check(!client.player.hasEffect(MobEffects.NIGHT_VISION),"Override added a potion effect");check(client.gui.screen()==null,"Independent gamma key opened a menu");});shot(c,"sao-gamma-on");
    c.waitTicks(20);c.runOnClient(client->check(GammaOverride.enabled(),"A single key press kept toggling"));
    c.runOnClient(client->client.options.gamma().set(.35));c.waitTicks(3);c.runOnClient(client->{check(extract(client).brightness==GammaOverride.MAX_GAMMA,"Brightness edit defeated the active override");check(Math.abs(client.options.gamma().get()-.35)<.001,"Brightness edit was overwritten");});
    c.getInput().pressKey(InputConstants.KEY_G);c.waitTicks(6);c.runOnClient(client->{check(!GammaOverride.enabled(),"G did not disable gamma override");check(Math.abs(extract(client).brightness-.35)<.001,"Disabling did not resume the current native brightness");});
    c.runOnClient(client->client.options.gamma().set(0.0));c.waitTicks(6);shot(c,"sao-gamma-restored");
    c.runOnClient(client->{GammaOverride.key.setKey(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_H));KeyMapping.resetMapping();});
    c.getInput().pressKey(InputConstants.KEY_G);c.waitTicks(2);c.runOnClient(client->check(!GammaOverride.enabled(),"Old key still triggers after rebinding"));
    c.getInput().pressKey(InputConstants.KEY_H);c.waitTicks(3);c.runOnClient(client->check(GammaOverride.enabled(),"Rebound key does not work"));
    c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(SaoMenuScreen.class);c.waitFor(client->((SaoMenuScreen)client.gui.screen()).isAnimationSettled());c.getInput().pressKey(InputConstants.KEY_H);c.waitTicks(2);c.runOnClient(client->check(GammaOverride.enabled(),"Typing inside a menu toggled the gameplay shortcut"));c.getInput().pressKey(InputConstants.KEY_K);c.waitForScreen(null);
    c.runOnClient(client->check(!client.player.hasEffect(MobEffects.NIGHT_VISION),"Rebinding or menu use added night vision"));
   }
   c.waitFor(client->!GammaOverride.enabled());
   SaoUiClient.LOGGER.info("SAO gamma override passed: default off, independent G/native rebind to H, real dark-room lightmap, high gamma, no options or potion mutation, current-brightness restore, no menu typing trigger and disconnect reset");
  }finally{c.runOnClient(client->{GammaOverride.key.setKey(InputConstants.getKey(oldKey));KeyMapping.resetMapping();client.options.gamma().set(oldGamma);});}
 }
 private static LightmapRenderState extract(net.minecraft.client.Minecraft client){try{var f=client.gameRenderer.getClass().getDeclaredField("lightmapRenderStateExtractor");f.setAccessible(true);var extractor=(LightmapRenderStateExtractor)f.get(client.gameRenderer);var state=new LightmapRenderState();extractor.tick();extractor.extract(state,1);return state;}catch(ReflectiveOperationException e){throw new AssertionError(e);}}
 private static void shot(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.getInput().setCursorPos(4,4);c.waitTicks(2);c.takeScreenshot(name);}
 private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
}
