package io.github.saoui;

import com.mojang.serialization.JsonOps;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentEffectComponents;
import net.minecraft.world.item.enchantment.LevelBasedValue;

/** Uses the connected world's registry and loaded language resources; no companion or reflection required. */
final class EnchantmentDetails {
    private EnchantmentDetails() {}

    static Optional<String> descriptionKey(String nameKey,String idKey,int level,Predicate<String> exists){
        var bases=new LinkedHashSet<String>();
        if(nameKey!=null)bases.add(nameKey);
        if(idKey!=null)bases.add(idKey);
        for(String base:bases){
            // A level-specific author description is more useful than the generic one in this panel.
            for(String suffix:List.of(".desc",".description",".info"))if(exists.test(base+suffix+"."+level))return Optional.of(base+suffix+"."+level);
            for(String suffix:List.of(".desc",".description",".info"))if(exists.test(base+suffix))return Optional.of(base+suffix);
            if(exists.test("description."+base))return Optional.of("description."+base);
        }
        return Optional.empty();
    }

    static List<Component> describe(Holder<Enchantment> holder,int level,boolean armor,SaoConfig config,HolderLookup.Provider registries){
        var result=new ArrayList<Component>();
        var enchantment=holder.value();
        var id=holder.unwrapKey().map(k->k.identifier()).orElse(null);
        if(config.enchantmentDescriptions){
            String nameKey=enchantment.description().getContents() instanceof TranslatableContents t?t.getKey():null;
            String idKey=id==null?null:id.toLanguageKey("enchantment");
            descriptionKey(nameKey,idKey,level,Language.getInstance()::has).ifPresent(key->result.add(Component.translatable("saoui.enchant.resource",Component.translatable(key))));
        }
        if(config.syncedEnchantmentEffects){
            var encoded=EnchantmentEffectComponents.CODEC.encodeStart(registries.createSerializationContext(JsonOps.INSTANCE),enchantment.effects()).result();
            if(encoded.isPresent()&&encoded.get().isJsonObject()){
                var facts=EnchantmentEffectFacts.describe(encoded.get().getAsJsonObject(),json->LevelBasedValue.CODEC.parse(JsonOps.INSTANCE,json).getOrThrow().calculate(Math.max(1,level)));
                if(!facts.isEmpty()){
                    for(var fact:facts){
                        var args=new ArrayList<Object>();
                        String key="saoui.enchant.component."+fact.component();
                        args.add(Language.getInstance().has(key)?Component.translatable(key):Component.literal(fact.component()));
                        args.addAll(fact.values());
                        Component line=Component.translatable("saoui.enchant.effect."+fact.operation(),args.toArray());
                        if(!fact.target().isEmpty())line=Component.translatable("saoui.enchant.target",line,target(fact.target()));
                        if(fact.conditional())line=Component.translatable("saoui.enchant.conditional",line);
                        result.add(line);
                    }
                }
            }else result.add(Component.translatable("saoui.enchant.unavailable"));
        }
        if(result.isEmpty())result.add(Component.translatable("saoui.enchant.unknown"));
        return List.copyOf(result);
    }
    private static Component target(String target){
        String key="saoui.enchant.target."+target;
        return Language.getInstance().has(key)?Component.translatable(key):Component.literal(target);
    }
}
