package io.github.saoui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Mirror coordinates and UVs, preserving clockwise GUI winding and readable glyphs. */
final class HudBarRenderer {
    static final int WIDTH=215;
    static final int GOLD=0xFFFFD76A;
    static void draw(GuiGraphicsExtractor g,Minecraft client,int nameWidth,int y,String label,double ratio,int tint,float overlay,String value){draw(g,client,nameWidth,y,label,ratio,tint,overlay,value,SaoUiClient.config().hud);}
    static void draw(GuiGraphicsExtractor g,Minecraft client,int nameWidth,int y,String label,double ratio,int tint,float overlay,String value,HudOptions options){draw(g,client,nameWidth,y,label,ratio,tint,overlay,value,options,FoodRecovery.NONE,0);}
    static void draw(GuiGraphicsExtractor g,Minecraft client,int nameWidth,int y,String label,double ratio,int tint,float overlay,String value,HudOptions options,FoodRecovery preview,float pulse){
        int panelWidth=nameWidth+250,barX=nameWidth+18;HudBarStyle style=options.style==null?HudBarStyle.SAO:options.style;boolean right=options.rightAligned;
        switch(style){
            case SAO -> {sprite(g,panelWidth,right,0,y,16,15,0,0,16,15,0xFFFFFFFF);sprite(g,panelWidth,right,16,y,nameWidth,15,16,0,5,15,0xFFFFFFFF);sprite(g,panelWidth,right,16+nameWidth,y,234,15,21,0,234,15,0xFFFFFFFF);}
            case RECTANGLE -> {rect(g,panelWidth,right,0,y,panelWidth,15,0xCC25343E);rect(g,panelWidth,right,barX-2,y+1,WIDTH+4,13,0xFFC2CED1);rect(g,panelWidth,right,barX-1,y+2,WIDTH+2,11,0xFF15212A);}
        }
        fill(g,panelWidth,right,barX,y+3,ratio,tint,style);fill(g,panelWidth,right,barX,y+3,overlay,GOLD,style);
        if(preview.present()){
            range(g,panelWidth,right,barX,y+3,preview.currentFood()/20.0,preview.predictedFood()/20.0,FloatingDraw.alpha(preview.rotten()?0xFFA9BE62:0xFFFFCF85,pulse),style);
            range(g,panelWidth,right,barX,y+3,preview.currentSaturation()/20.0,preview.predictedSaturation()/20.0,FloatingDraw.alpha(GOLD,pulse),style);
        }
        g.nextStratum();
        String shortLabel=client.font.plainSubstrByWidth(label,nameWidth);int valueWidth=client.font.width(value);
        int normal=barX+WIDTH-4-valueWidth,alternate=barX+4;
        if(preview.present()){
            double from=preview.foodGain()>0?preview.currentFood()/20.0:preview.currentSaturation()/20.0;
            double to=preview.foodGain()>0?preview.predictedFood()/20.0:preview.predictedSaturation()/20.0;
            if(overlap(alternate,valueWidth,barX,from,to)<overlap(normal,valueWidth,barX,from,to))normal=alternate;
        }
        int valueX=right?panelWidth-normal-valueWidth:normal;
        g.fill(valueX-2,y+2,valueX+valueWidth+2,y+13,0xD019242C);
        int labelX=right?panelWidth-12-client.font.width(shortLabel):12;
        g.text(client.font,shortLabel,labelX,y+3,ThemePalette.font(0xFFFFFFFF),true);g.text(client.font,value,valueX,y+3,ThemePalette.font(0xFFFFFFFF),true);
    }
    private static int overlap(int x,int width,int barX,double from,double to){return Math.max(0,Math.min(x+width+2,barX+(int)Math.round(WIDTH*to))-Math.max(x-2,barX+(int)Math.round(WIDTH*from)));}
    private static void rect(GuiGraphicsExtractor g,int panelWidth,boolean right,int x,int y,int w,int h,int color){int left=right?panelWidth-x-w:x;g.fill(left,y,left+w,y+h,color);}
    private static void sprite(GuiGraphicsExtractor g,int panelWidth,boolean right,int x,int y,int w,int h,int u,int v,int sw,int sh,int color){UiSprites.gui(g,right?panelWidth-x-w:x,y,w,h,right?u+sw:u,v,right?-sw:sw,sh,color);}
    private static void fill(GuiGraphicsExtractor g,int panelWidth,boolean right,int x,int y,double ratio,int tint,HudBarStyle style){range(g,panelWidth,right,x,y,0,ratio,tint,style);}
    private static void range(GuiGraphicsExtractor g,int panelWidth,boolean right,int x,int y,double from,double to,int tint,HudBarStyle style){
        int start=(int)Math.round(WIDTH*Math.clamp(from,0,1)),end=(int)Math.round(WIDTH*Math.clamp(to,0,1)),pixels=end-start;if(pixels<=0||(tint>>>24)==0)return;
        if(style==HudBarStyle.SAO)sprite(g,panelWidth,right,x+start,y,pixels,9,start,188,pixels,9,tint);
        else {int top=UiTheme.mix(tint,0xFFFFFFFF,.20),bottom=UiTheme.mix(tint,0xFF000000,.30);for(int row=0;row<9;row++)rect(g,panelWidth,right,x+start,y+row,pixels,1,(UiTheme.mix(top,bottom,row/8.0)&0xFFFFFF)|(tint&0xFF000000));}
    }
    private HudBarRenderer(){}
}
