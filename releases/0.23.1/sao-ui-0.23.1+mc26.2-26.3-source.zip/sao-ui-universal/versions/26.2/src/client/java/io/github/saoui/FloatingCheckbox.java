package io.github.saoui;

import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** A checkbox on the projected menu surface, with native button input/focus and a narrated state. */
final class FloatingCheckbox extends Button {
    private final Consumer<Boolean> change;
    private MenuProjection projection;
    private double x,y,w,h,opacity;
    private boolean checked;
    FloatingCheckbox(boolean checked,Consumer<Boolean> change){
        super(0,0,1,1,Component.empty(),button->((FloatingCheckbox)button).toggle(),DEFAULT_NARRATION);
        this.checked=checked;this.change=change;message();SettingsHelp.attach(this,"saoui.enchant.show_max");
    }
    boolean checked(){return checked;}
    private void message(){setMessage(Component.translatable("saoui.enchant.show_max",Component.translatable(checked?"options.on":"options.off")));}
    private void toggle(){checked=!checked;message();change.accept(checked);}
    void place(MenuProjection p,double x,double y,double w,double h,double opacity,boolean interactive){
        projection=p;this.x=x;this.y=y;this.w=w;this.h=h;this.opacity=opacity;active=interactive;visible=opacity>.01;
        var bounds=FloatingDraw.bounds(p,x,y,w,h);setRectangle(bounds.width(),bounds.height(),bounds.left(),bounds.top());
    }
    @Override public boolean isMouseOver(double mx,double my){if(!active||!visible||projection==null)return false;var at=projection.unproject(mx,my);return at.x()>=x&&at.x()<x+w&&at.y()>=y&&at.y()<y+h;}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubleClick){return isMouseOver(e.x(),e.y())&&super.mouseClicked(e,doubleClick);}
    @Override protected void extractContents(GuiGraphicsExtractor g,int mx,int my,float delta){
        if(projection==null)return;boolean hover=isFocused()||isMouseOver(mx,my);int edge=hover?ThemePalette.accent():ThemePalette.muted();
        double cy=y+(h-11)/2;FloatingDraw.rect(g,projection,x,cy,11,11,color(edge));FloatingDraw.rect(g,projection,x+1,cy+1,9,9,color(checked?ThemePalette.accent():ThemePalette.cell()));
        if(checked)FloatingDraw.text(g,projection,"✓",x+2,cy+1,color(ThemePalette.onAccent()));
        var label=Component.translatable(checked?"saoui.enchant.max_checked":"saoui.enchant.max_choice").getString();
        FloatingDraw.text(g,projection,Minecraft.getInstance().font.plainSubstrByWidth(label,(int)w-17),x+16,y+(h-9)/2,color(hover?ThemePalette.accent():ThemePalette.ink()));
    }
    private int color(int rgb){return FloatingDraw.alpha(rgb,opacity);}
}
