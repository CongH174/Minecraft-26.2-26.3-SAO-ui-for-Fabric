package io.github.saoui;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Items;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/** Source-separated, collapsible reading surface. Updates preserve the current reading position. */
final class EnchantmentPanel {
    static final int X=322,Y=-124,W=222,H=252,VISIBLE_LINES=15;
    private record Row(String text,boolean heading,String section) {}
    private record Section(String id,String title,List<String> details,boolean defaultOpen,boolean brief) {}
    private final List<Row> lines=new ArrayList<>();
    private final List<Section> sections=new ArrayList<>();
    private final Map<String,Boolean> expanded=new HashMap<>();
    private ItemStack cached=ItemStack.EMPTY;
    private String cachedIdentity="",focusedSection="";
    private boolean built,focused,preview,cachedPreview;
    private net.minecraft.core.RegistryAccess cachedRegistry;
    private net.minecraft.locale.Language cachedLanguage;
    private boolean cachedDescriptions,cachedEffects,cachedLore;
    private int scroll,compactScroll;
    private boolean reading;
    boolean modal(){return reading&&SaoUiClient.config().enchantmentDetailsVisible;}
    private double readerScale(){var w=Minecraft.getInstance().getWindow();return 1.8*UiEffects.unit(w.getHeight(),w.getGuiScale());}
    private double readerWidth(){return Math.min(600,(Minecraft.getInstance().gui.screen().width-24*readerScale())/readerScale());}
    private double readerHeight(){return (Minecraft.getInstance().gui.screen().height-24*readerScale())/readerScale();}
    private MenuProjection readerProjection(){var s=Minecraft.getInstance().gui.screen();return new MenuProjection((s.width-readerWidth()*readerScale())/2,12*readerScale(),readerScale(),0,0,0);}
    private int visibleLines(){return reading?Math.max(1,((int)readerHeight()-88)/12):VISIBLE_LINES;}
    private void closeReader(){reading=false;rebuildRows();scroll=compactScroll;clampScroll();}

    boolean previewMode(){return preview;}
    void previewMode(boolean value){if(preview==value)return;preview=value;scroll=compactScroll=0;expanded.clear();focusedSection="";focused=false;}
    int scrollPosition(){return scroll;}
    int lineCount(){return lines.size();}
    List<String> visibleText(){return lines.stream().skip(scroll).limit(VISIBLE_LINES).map(Row::text).toList();}
    private boolean inside(double x,double y,MenuProjection p){var q=p.unproject(x,y);return SaoUiClient.config().enchantmentDetailsVisible&&q.x()>=X&&q.x()<X+W&&q.y()>=Y&&q.y()<Y+H;}
    private void clampScroll(){scroll=Math.clamp(scroll,0,Math.max(0,lines.size()-visibleLines()));}
    boolean scroll(double x,double y,double amount,MenuProjection p){
        if((!reading&&!inside(x,y,p))||amount==0)return false;
        scroll-=(int)Math.copySign(3,amount);clampScroll();return true;
    }
    boolean click(double x,double y,MenuProjection p){
        if(reading){
            var q=readerProjection().unproject(x,y);
            if(q.y()>=6&&q.y()<30&&q.x()>=readerWidth()-64){closeReader();return true;}
            int index=(int)Math.floor((q.y()-64)/12)+scroll;
            if(q.y()>=64&&q.y()<64+visibleLines()*12&&index>=0&&index<lines.size()){var row=lines.get(index);if(row.heading()&&!row.section().isEmpty()){focusedSection=row.section();toggle(row.section());}}
            return true;
        }
        focused=inside(x,y,p);if(!focused)return false;
        var q=p.unproject(x,y);
        if(q.y()>=Y+7&&q.y()<Y+28&&q.x()>=X+W-38){compactScroll=scroll;reading=true;focused=true;scroll=0;rebuildRows();return true;}
        if(q.x()>=X+W-14&&q.y()>=Y+49&&q.y()<Y+214){scroll=(int)Math.round((q.y()-Y-49)/165*Math.max(0,lines.size()-VISIBLE_LINES));clampScroll();return true;}
        int row=(int)Math.floor((q.y()-Y-51)/11)+scroll;
        if(q.y()>=Y+51&&q.y()<Y+51+VISIBLE_LINES*11&&row>=0&&row<lines.size()){
            var r=lines.get(row);if(r.heading()&&!r.section().isEmpty()){focusedSection=r.section();toggle(r.section());}
        }
        return true;
    }
    boolean keyPressed(KeyEvent e){
        if(reading&&e.key()==InputConstants.KEY_ESCAPE){closeReader();return true;}
        if(!focused)return false;
        if(e.key()==InputConstants.KEY_UP)scroll--;
        else if(e.key()==InputConstants.KEY_DOWN)scroll++;
        else if(e.key()==InputConstants.KEY_HOME)scroll=0;
        else if(e.key()==InputConstants.KEY_END)scroll=lines.size();
        else if((e.key()==InputConstants.KEY_RETURN||e.key()==InputConstants.KEY_SPACE)&&!focusedSection.isEmpty()){toggle(focusedSection);return true;}
        else return false;
        clampScroll();return true;
    }
    private void toggle(String id){
        sections.stream().filter(s->s.id().equals(id)).findFirst().ifPresent(s->expanded.put(id,!expanded.getOrDefault(id,s.defaultOpen())));
        rebuildRows();
    }
    private void add(String text,boolean heading,String section){
        for(var part:Minecraft.getInstance().font.getSplitter().splitLines(Component.literal(text),reading?(int)readerWidth()-32:W-32,net.minecraft.network.chat.Style.EMPTY))lines.add(new Row(part.getString(),heading,section));
    }
    private void rebuildRows(){
        lines.clear();
        for(var s:sections){
            boolean open=expanded.getOrDefault(s.id(),s.defaultOpen());
            add((open?"[-] ":"[+] ")+s.title(),true,s.id());
            if(open)for(var detail:s.details())add(detail,false,"");
            else if(s.brief()&&!s.details().isEmpty()){
                var parts=Minecraft.getInstance().font.getSplitter().splitLines(Component.literal(s.details().getFirst()),reading?(int)readerWidth()-32:W-32,net.minecraft.network.chat.Style.EMPTY);
                for(int i=0;i<Math.min(2,parts.size());i++)lines.add(new Row(parts.get(i).getString()+(i==1&&parts.size()>2?"…":""),false,""));
            }
            lines.add(new Row("",false,""));
        }
        clampScroll();
    }
    private void enchant(Holder<Enchantment> enchantment,int level,boolean armor){
        String title=Enchantment.getFullname(enchantment,level).getString();
        var id=enchantment.unwrapKey().map(k->k.identifier()).orElse(null);
        String key=id==null?title:id.toString();
        var details=EnchantmentDetails.describe(enchantment,level,armor,SaoUiClient.config(),Minecraft.getInstance().player.registryAccess()).stream().map(Component::getString).distinct().toList();
        sections.add(new Section(key,title,details,true,false));
    }
    private void refresh(ItemStack stack,String identity){
        var registry=Minecraft.getInstance().player.registryAccess();var language=net.minecraft.locale.Language.getInstance();var config=SaoUiClient.config();
        if(built&&cachedPreview==preview&&ItemStack.matches(cached,stack)&&cachedIdentity.equals(identity)&&cachedRegistry==registry&&cachedLanguage==language&&cachedDescriptions==config.enchantmentDescriptions&&cachedEffects==config.syncedEnchantmentEffects&&cachedLore==config.serverEnchantmentLore)return;
        boolean sameSelection=built&&cachedIdentity.equals(identity)&&cached.is(stack.getItem())&&cached.getHoverName().equals(stack.getHoverName())&&cachedRegistry==registry;
        if(!sameSelection){scroll=0;reading=false;expanded.clear();focusedSection="";focused=false;}
        cachedRegistry=registry;cachedLanguage=language;cachedDescriptions=config.enchantmentDescriptions;cachedEffects=config.syncedEnchantmentEffects;cachedLore=config.serverEnchantmentLore;
        built=true;cachedPreview=preview;cached=stack.copy();cachedIdentity=identity;sections.clear();
        if(stack.isEmpty()){rebuildRows();return;}
        var itemLore=preview?List.<Component>of():ServerItemDescriptions.describe(stack,config);
        if(!itemLore.isEmpty()){
            var text=new ArrayList<String>();for(var line:itemLore)text.add(line.getString());
            text.add(Component.translatable("saoui.enchant.item_lore_source").getString());
            sections.add(new Section("item/lore",Component.translatable("saoui.enchant.item_lore").getString(),List.copyOf(text),true,false));
        }
        boolean armor=stack.is(ItemTags.ARMOR_ENCHANTABLE);
        var existing=stack.getEnchantments();var stored=stack.getOrDefault(DataComponents.STORED_ENCHANTMENTS,ItemEnchantments.EMPTY);
        if(preview){
            boolean book=stack.is(Items.BOOK)||stack.is(Items.ENCHANTED_BOOK);
            registry.lookupOrThrow(Registries.ENCHANTMENT).listElements().filter(e->book||e.value().isSupportedItem(stack))
                .sorted(Comparator.comparing(e->e.value().description().getString())).forEach(e->enchant(e,e.value().getMaxLevel(),armor));
        }else if(!existing.isEmpty()||!stored.isEmpty()){
            existing.entrySet().stream().sorted(Comparator.comparing(e->e.getKey().value().description().getString())).forEach(e->enchant(e.getKey(),e.getIntValue(),armor));
            if(!stored.isEmpty()){
                stored.entrySet().stream().sorted(Comparator.comparing(e->e.getKey().value().description().getString())).forEach(e->enchant(e.getKey(),e.getIntValue(),false));
            }
        }
        rebuildRows();
    }
    void render(GuiGraphicsExtractor g,MenuProjection p,ItemStack stack,double opacity,String identity){
        if(!SaoUiClient.config().enchantmentDetailsVisible)return;
        PlayerPanels.panel(g,p,X,Y,W*opacity,H,opacity);if(opacity<.65)return;refresh(stack,identity);
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.title").getString(),X+14,Y+14,FloatingDraw.alpha(ThemePalette.ink(),opacity));
        FloatingDraw.text(g,p,"[+]",X+W-30,Y+14,FloatingDraw.alpha(ThemePalette.ink(),opacity));
        FloatingDraw.rect(g,p,X+14,Y+43,W-28,.8,FloatingDraw.alpha(ThemePalette.line(),opacity));
        for(int i=0;i<VISIBLE_LINES&&i+scroll<lines.size();i++){
            var row=lines.get(i+scroll);
            FloatingDraw.text(g,p,row.text(),X+14,Y+51+i*11,FloatingDraw.alpha(row.heading()?ThemePalette.accent():ThemePalette.ink(),opacity));
        }
        if(lines.isEmpty())FloatingDraw.text(g,p,Component.translatable(preview?"saoui.enchant.no_applicable":"saoui.enchant.empty").getString(),X+14,Y+52,FloatingDraw.alpha(ThemePalette.muted(),opacity));
        if(lines.size()>VISIBLE_LINES){double thumb=165.0*VISIBLE_LINES/lines.size(),dy=(165-thumb)*scroll/(lines.size()-VISIBLE_LINES);FloatingDraw.rect(g,p,X+W-9,Y+49,2,165,FloatingDraw.alpha(ThemePalette.line(),opacity));FloatingDraw.rect(g,p,X+W-9,Y+49+dy,2,thumb,FloatingDraw.alpha(ThemePalette.accent(),opacity));}
        FloatingDraw.rect(g,p,X+14,Y+221,W-28,.8,FloatingDraw.alpha(ThemePalette.line(),opacity));
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.reading_hint").getString(),X+14,Y+226,FloatingDraw.alpha(ThemePalette.muted(),opacity));
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.server_rules").getString(),X+14,Y+239,FloatingDraw.alpha(ThemePalette.muted(),opacity));
    }
    void readingOverlay(GuiGraphicsExtractor g){
        if(!modal())return;
        var client=Minecraft.getInstance();var screen=client.gui.screen();var p=readerProjection();double w=readerWidth(),h=readerHeight();
        g.nextStratum();g.fill(0,0,screen.width,screen.height,0xF0101820);PlayerPanels.panel(g,p,0,0,w,h,1);
        FloatingDraw.text(g,p,client.font.plainSubstrByWidth(cached.getHoverName().getString(),(int)w-88),14,13,ThemePalette.ink());
        FloatingDraw.text(g,p,Component.translatable("gui.back").getString(),w-50,13,ThemePalette.ink());
        FloatingDraw.text(g,p,client.font.plainSubstrByWidth(ItemDetails.summary(client.player,cached).getString(),(int)w-28),14,32,ThemePalette.ink());
        FloatingDraw.rect(g,p,14,49,w-28,.8,ThemePalette.line());
        FloatingDraw.text(g,p,client.font.plainSubstrByWidth(Component.translatable(preview?"saoui.enchant.max_checked":cached.has(DataComponents.STORED_ENCHANTMENTS)?"saoui.enchant.stored":"saoui.enchant.active").getString(),(int)w-28),14,52,preview?ThemePalette.accent():ThemePalette.muted());
        for(int n=0;n<visibleLines()&&n+scroll<lines.size();n++){var row=lines.get(n+scroll);if(row.heading())FloatingDraw.rect(g,p,7,64+n*12,2,9,ThemePalette.accent());FloatingDraw.text(g,p,row.text(),14,64+n*12,ThemePalette.ink());}
        FloatingDraw.rect(g,p,14,h-22,w-28,.8,ThemePalette.line());
        FloatingDraw.text(g,p,Component.translatable("saoui.enchant.reader_hint").getString(),14,h-16,ThemePalette.muted());
        if(lines.size()>visibleLines()){double track=visibleLines()*12,thumb=track*visibleLines()/lines.size(),dy=(track-thumb)*scroll/(lines.size()-visibleLines());FloatingDraw.rect(g,p,w-9,62,2,track,ThemePalette.line());FloatingDraw.rect(g,p,w-9,62+dy,2,thumb,ThemePalette.ink());}
    }

}
