package io.github.saoui;

import net.minecraft.client.Minecraft;
import squeek.appleskin.ModConfig;
import squeek.appleskin.client.HUDOverlayHandler;
import squeek.appleskin.helpers.FoodHelper;

/** Loaded only after AppleSkin is detected. Uses its shared held-food cache and FoodValuesEvent result. */
final class AppleSkinFoodPreview {
    static FoodRecovery sample(Minecraft client,boolean saturation){
        var config=ModConfig.INSTANCE;var hud=HUDOverlayHandler.INSTANCE;var player=client.player;
        if(config==null||hud==null||player==null||!config.showFoodValuesHudOverlay)return FoodRecovery.NONE;
        var held=hud.heldFood.result(client.gui.hud.getGuiTicks(),player);
        if(held==null||held.modifiedFoodComponent==null)return FoodRecovery.NONE;
        var food=held.modifiedFoodComponent;var current=player.getFoodData();
        return FoodRecovery.estimate(current.getFoodLevel(),current.getSaturationLevel(),food.nutrition(),food.saturation(),config.maxHudOverlayFlashAlpha,saturation&&config.showSaturationHudOverlay,FoodHelper.isRotten(held.consumableComponent));
    }
    private AppleSkinFoodPreview(){}
}
