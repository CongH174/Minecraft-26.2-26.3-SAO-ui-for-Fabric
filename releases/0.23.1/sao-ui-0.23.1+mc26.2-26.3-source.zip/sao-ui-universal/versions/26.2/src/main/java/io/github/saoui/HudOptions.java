package io.github.saoui;

/** Independently saved HUD modules; absent legacy fields retain these defaults. */
public final class HudOptions {
    public boolean rightAligned;
    public HudBarStyle style=HudBarStyle.SAO;
    public boolean health = true;
    public boolean hunger = true;
    public boolean experience = true;
    public boolean armor = true;
    public boolean saturation = true;
    public boolean foodPreview = true;
    public boolean hideVanillaHealth;
    public boolean hideVanillaHunger;
    public boolean hideVanillaExperience;
    public boolean hideVanillaArmor;
    public boolean hideVanillaCrosshair;
    /** Read once from 0.9 configs; null is omitted by Gson after migration. */
    @Deprecated public Boolean hideVanilla;

    public HudOptions validated() {
        if(style==null)style=HudBarStyle.SAO;
        if (Boolean.TRUE.equals(hideVanilla))
            hideVanillaHealth = hideVanillaHunger = hideVanillaExperience = hideVanillaArmor = hideVanillaCrosshair = true;
        hideVanilla = null;
        return this;
    }
    public int extraBars() { return (hunger ? 1 : 0) + (experience ? 1 : 0) + (armor ? 1 : 0); }
    public boolean anyBar() { return health || extraBars() > 0; }
    public int height() { return anyBar() ? (1 + extraBars()) * 20 - 5 : 0; }
    public HudOptions copy() {
        var copy = new HudOptions();
        copy.rightAligned=rightAligned;copy.style=style;
        copy.health = health; copy.hunger = hunger; copy.experience = experience;
        copy.armor = armor; copy.saturation = saturation; copy.foodPreview = foodPreview; copy.hideVanilla = hideVanilla;
        copy.hideVanillaHealth = hideVanillaHealth; copy.hideVanillaHunger = hideVanillaHunger;
        copy.hideVanillaExperience = hideVanillaExperience; copy.hideVanillaArmor = hideVanillaArmor;
        copy.hideVanillaCrosshair = hideVanillaCrosshair;
        return copy;
    }
}
