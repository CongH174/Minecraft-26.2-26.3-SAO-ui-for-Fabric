package io.github.saoui;

/** Read-only predicted endpoints; no food is consumed and no player data is changed. */
public record FoodRecovery(int currentFood,int predictedFood,float currentSaturation,float predictedSaturation,float alphaLimit,boolean rotten) {
    public static final FoodRecovery NONE=new FoodRecovery(0,0,0,0,0,false);
    public static FoodRecovery estimate(int food,float saturation,int nutrition,float saturationGain,float maxAlpha,boolean showSaturation,boolean rotten){
        int start=Math.clamp(food,0,20),end=(int)Math.clamp((long)start+Math.max(0,nutrition),0L,20L);
        float sat=Float.isFinite(saturation)?Math.clamp(saturation,0,start):0;
        float gain=Float.isFinite(saturationGain)?Math.max(0,saturationGain):0;
        float after=showSaturation?Math.clamp(sat+gain,sat,end):sat;
        float limit=Float.isFinite(maxAlpha)?Math.clamp(maxAlpha,0,1):0;
        return limit>0&&(end>start||after>sat)?new FoodRecovery(start,end,sat,after,limit,rotten):NONE;
    }
    public boolean present(){return alphaLimit>0&&(predictedFood>currentFood||predictedSaturation>currentSaturation);}
    public int foodGain(){return predictedFood-currentFood;}
    public float opacity(long millis,float animationRate){if(!present())return 0;if(animationRate<=0)return alphaLimit;double phase=(millis*(double)animationRate/1600.0)%1;return (float)(.10+.90*(.5-.5*Math.cos(phase*Math.PI*2)))*alphaLimit;}
}
