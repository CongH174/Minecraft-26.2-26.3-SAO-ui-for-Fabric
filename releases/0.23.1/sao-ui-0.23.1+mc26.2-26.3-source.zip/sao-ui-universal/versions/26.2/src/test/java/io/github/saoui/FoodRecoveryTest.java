package io.github.saoui;
import com.google.gson.Gson;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class FoodRecoveryTest {
 @Test void endpointsClampToRealFoodAndSaturationLimits(){var r=FoodRecovery.estimate(16,4,8,12,.65f,true,false);assertEquals(20,r.predictedFood());assertEquals(4,r.foodGain());assertEquals(16,r.predictedSaturation());assertEquals(20,FoodRecovery.estimate(20,18,4,12,1,true,false).predictedSaturation());}
 @Test void hiddenSaturationDoesNotHideHungerPrediction(){var r=FoodRecovery.estimate(12,2,5,6,1,false,false);assertTrue(r.present());assertEquals(17,r.predictedFood());assertEquals(2,r.predictedSaturation());}
 @Test void invalidAndNonFoodInputsDoNotInventRecovery(){assertFalse(FoodRecovery.estimate(20,20,8,10,1,true,false).present());assertFalse(FoodRecovery.estimate(12,Float.NaN,-3,Float.NaN,1,true,false).present());assertFalse(FoodRecovery.estimate(12,0,4,0,Float.NaN,true,false).present());assertFalse(FoodRecovery.estimate(12,0,4,0,0,true,false).present());}
 @Test void veryLargeNutritionDoesNotOverflow(){var r=FoodRecovery.estimate(19,2,Integer.MAX_VALUE,Float.MAX_VALUE,1,true,true);assertEquals(20,r.predictedFood());assertEquals(20,r.predictedSaturation());assertTrue(r.rotten());}
 @Test void breathHasSmoothBoundedExtremesAndStaticMode(){var r=FoodRecovery.estimate(12,2,5,6,.65f,true,false);assertEquals(.065f,r.opacity(0,1),.0001);assertEquals(.65f,r.opacity(800,1),.0001);assertEquals(r.opacity(0,1),r.opacity(1600,1),.0001);assertEquals(.65f,r.opacity(123,0),.0001);assertEquals(.65f,r.opacity(400,2),.0001);assertEquals(12,r.currentFood());}
 @Test void legacyDefaultsAndDraftRoundTripRemainIndependent(){var gson=new Gson();var original=gson.fromJson("{}",SaoConfig.class).validated();assertTrue(original.hud.foodPreview);var copy=original.copy();copy.hud.foodPreview=false;assertTrue(original.hud.foodPreview);var saved=gson.fromJson(gson.toJson(copy),SaoConfig.class).validated();assertFalse(saved.hud.foodPreview);saved.resetHud();assertTrue(saved.hud.foodPreview);}
}
