package io.github.saoui;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import squeek.appleskin.ModConfig;
import squeek.appleskin.api.event.FoodValuesEvent;
/** Test-only helper. No AppleSkin classes are touched by the absent-mod suite. */
final class AppleSkinPreviewChecks {
 private static boolean overrideFood,registered;
 static void run(ClientGameTestContext c,TestSingleplayerContext world){
  var settings=ModConfig.INSTANCE;boolean oldPreview=settings.showFoodValuesHudOverlay,oldOffhand=settings.showFoodValuesHudOverlayWhenOffhand,oldSaturation=settings.showSaturationHudOverlay;float oldAlpha=settings.maxHudOverlayFlashAlpha;
  try{
   c.runOnClient(client->{settings.showFoodValuesHudOverlay=true;settings.showFoodValuesHudOverlayWhenOffhand=true;settings.showSaturationHudOverlay=true;settings.maxHudOverlayFlashAlpha=.8f;if(!registered){FoodValuesEvent.EVENT.register(event->{if(overrideFood&&event.itemStack.is(Items.APPLE))event.modifiedFoodComponent=new FoodProperties(7,5,false);});registered=true;}});
   select(c,0);waitPreview(c,16);check(preview(c).foodGain()==4,"Main-hand apple recovery incorrect");
   select(c,1);waitPreview(c,17);check(preview(c).predictedSaturation()>preview(c).currentSaturation(),"Expected saturation is missing");
   select(c,3);waitPreview(c,17);c.runOnClient(client->settings.showFoodValuesHudOverlayWhenOffhand=false);c.waitTicks(2);check(!preview(c).present(),"AppleSkin offhand switch ignored");
   c.runOnClient(client->settings.showFoodValuesHudOverlayWhenOffhand=true);c.waitTicks(2);waitPreview(c,17);select(c,0);waitPreview(c,16);
   c.runOnClient(client->overrideFood=true);c.waitTicks(2);waitPreview(c,19);c.runOnClient(client->check(client.player.getMainHandItem().get(DataComponents.FOOD).nutrition()==4,"AppleSkin event changed native item components"));c.runOnClient(client->overrideFood=false);c.waitTicks(2);waitPreview(c,16);
   c.runOnClient(client->settings.showSaturationHudOverlay=false);c.waitTicks(2);check(preview(c).predictedSaturation()==preview(c).currentSaturation()&&preview(c).foodGain()==4,"AppleSkin saturation preview switch ignored");c.runOnClient(client->settings.showSaturationHudOverlay=true);
   c.runOnClient(client->settings.showFoodValuesHudOverlay=false);check(!preview(c).present(),"AppleSkin master preview switch ignored");c.runOnClient(client->{settings.showFoodValuesHudOverlay=true;settings.maxHudOverlayFlashAlpha=0;});check(!preview(c).present(),"Zero flash opacity still shows recovery");c.runOnClient(client->settings.maxHudOverlayFlashAlpha=.8f);
   food(c,world,18,2);select(c,2);waitPreview(c,20);check(preview(c).foodGain()==2,"Recovery did not clip to 20 food");
   c.runOnClient(client->settings.showFoodValuesHudOverlayWhenOffhand=false);food(c,world,20,2);select(c,0);check(!preview(c).present(),"Inedible full-hunger apple has a recovery hint");select(c,4);c.waitTicks(2);check(preview(c).present()&&preview(c).foodGain()==0,"Always-edible food lost saturation-only prediction");
   food(c,world,12,2);world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();var custom=new ItemStack(Items.STICK);custom.set(DataComponents.FOOD,new FoodProperties(6,3,false));custom.set(DataComponents.CONSUMABLE,new ItemStack(Items.APPLE).get(DataComponents.CONSUMABLE));p.getInventory().setItem(5,custom);p.inventoryMenu.broadcastChanges();});c.waitFor(client->client.player.getInventory().getItem(5).has(DataComponents.FOOD));select(c,5);waitPreview(c,18);
   select(c,1);waitPreview(c,17);var recovery=preview(c);check(recovery.opacity(0,1)<recovery.opacity(800,1)&&recovery.opacity(800,1)<=.8001,"Breathing opacity did not respect AppleSkin maximum");
   c.runOnClient(client->{var cfg=SaoUiClient.config().copy();cfg.hud.hideVanillaHunger=true;try{SaoUiClient.saveConfig(cfg);}catch(java.io.IOException e){throw new RuntimeException(e);}});c.waitTicks(2);check(preview(c).present(),"Hiding the native food bar disabled SAO preview");
   for(var style:HudBarStyle.values())for(boolean right:new boolean[]{false,true}){var cfg=SaoUiClient.config().copy();cfg.hud.style=style;cfg.hud.rightAligned=right;cfg.scale=1.4f;cfg.y=80;FoodPreviewGameTest.save(c,cfg);c.waitFor(client->{var p=AppleSkinBridge.preview(client,SaoUiClient.config().hud);return p.present()&&p.opacity(net.minecraft.util.Util.getMillis(),1)>.72;});shot(c,"sao-food-preview-"+style.name().toLowerCase(java.util.Locale.ROOT)+(right?"-right":"-left"));}
   c.runOnClient(client->client.gui.setScreen(new Swatches(recovery)));c.waitTick();c.takeScreenshot("sao-food-preview-breath-contrast");c.runOnClient(client->client.gui.setScreen(null));
   c.runOnClient(client->check(client.player.getFoodData().getFoodLevel()==12&&client.player.getMainHandItem().getCount()==4,"Preview consumed food or changed actual hunger"));
   FoodPreviewGameTest.save(c,new SaoConfig());SaoUiClient.LOGGER.info("SAO AppleSkin food preview passed: supplied jar, shared cache and modified FoodValuesEvent, main/offhand priority, native components, full-hunger/overflow caps, all preview/opacity switches, both styles/directions, native-bar hiding, breath contrast and no food consumption");
  }finally{c.runOnClient(client->{overrideFood=false;settings.showFoodValuesHudOverlay=oldPreview;settings.showFoodValuesHudOverlayWhenOffhand=oldOffhand;settings.showSaturationHudOverlay=oldSaturation;settings.maxHudOverlayFlashAlpha=oldAlpha;});}
 }
 private static FoodRecovery preview(ClientGameTestContext c){return c.computeOnClient(client->AppleSkinBridge.preview(client,SaoUiClient.config().hud));}
 private static void waitPreview(ClientGameTestContext c,int target){c.waitFor(client->{var p=AppleSkinBridge.preview(client,SaoUiClient.config().hud);return p.present()&&p.predictedFood()==target;});}
 private static void select(ClientGameTestContext c,int slot){c.getInput().pressKey(InputConstants.KEY_1+slot);c.waitFor(client->client.player.getInventory().getSelectedSlot()==slot);c.waitTicks(2);}
 private static void food(ClientGameTestContext c,TestSingleplayerContext world,int food,float sat){world.getServer().runOnServer(server->{var p=server.getPlayerList().getPlayers().getFirst();p.getFoodData().setFoodLevel(food);p.getFoodData().setSaturation(sat);});c.waitFor(client->client.player.getFoodData().getFoodLevel()==food&&Math.abs(client.player.getFoodData().getSaturationLevel()-sat)<.01);c.waitTicks(2);}
 private static void shot(ClientGameTestContext c,String name){c.runOnClient(client->{client.gui.toastManager().clear();client.gui.hud.getChat().clearMessages(true);});c.takeScreenshot(name);}
 private static void check(boolean ok,String message){FoodPreviewGameTest.check(ok,message);}
 private static final class Swatches extends Screen {
  private final FoodRecovery recovery;Swatches(FoodRecovery r){super(Component.literal("AppleSkin recovery · breathing contrast"));recovery=r;}
  @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta){g.fill(0,0,width,height,0xFF18262F);g.text(font,title,12,10,0xFFFFFFFF,false);int i=0;for(var style:HudBarStyle.values())for(boolean high:new boolean[]{false,true}){int y=42+i++*46;g.text(font,style+" · "+(high?"PEAK":"LOW"),20,y-13,0xFFFFCF85,false);var options=new HudOptions();options.style=style;g.pose().pushMatrix();g.pose().translate(20,y);HudBarRenderer.draw(g,minecraft,48,0,"Hunger",.6,0xFFE99C43,.1f,"12 → 17 / 20",options,recovery,high?.8f:.08f);g.pose().popMatrix();}}
 }
 private AppleSkinPreviewChecks(){}
}
