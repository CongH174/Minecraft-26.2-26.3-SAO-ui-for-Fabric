package io.github.saoui;

import java.util.ArrayList;
import java.util.List;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.contents.TranslatableContents;

/** Navigate actual category buttons and the native scroll list, then dispatch real pointer input. */
final class SettingsNavigation {
    static List<AbstractWidget> widgets(Screen screen){var result=new ArrayList<AbstractWidget>();for(var child:screen.children())if(child instanceof AbstractWidget widget)result.add(widget);if(screen instanceof SaoSettingsScreen settings)result.addAll(settings.options());return result;}
    static AbstractWidget widget(Screen screen,String key){return widgets(screen).stream().filter(w->w.getMessage().getContents() instanceof TranslatableContents t&&t.getKey().equals(key)).findFirst().orElseThrow(()->new AssertionError("Missing direct option "+key));}
    static void click(ClientGameTestContext c,String key){
        expose(c,key);
        double[] point=c.computeOnClient(client->{var s=client.gui.screen();var w=widget(s,key);var win=client.getWindow();return new double[]{(w.getX()+w.getWidth()/2.0)*win.getScreenWidth()/s.width,(w.getY()+w.getHeight()/2.0)*win.getScreenHeight()/s.height};});
        c.getInput().setCursorPos(point[0],point[1]);c.waitTick();c.getInput().pressMouse(InputConstants.MOUSE_BUTTON_LEFT);c.waitTick();
    }
    static void expose(ClientGameTestContext c,String key){
        if(!c.computeOnClient(client->client.gui.screen() instanceof SaoSettingsScreen))return;
        if(c.computeOnClient(client->widgets(client.gui.screen()).stream().anyMatch(w->w.getMessage().getContents() instanceof TranslatableContents t&&t.getKey().equals(key)))){reveal(c,key);return;}
        String category;
        if(key.startsWith("settings.saoui.bar.")||List.of("settings.saoui.hud","settings.saoui.food_preview","settings.saoui.hud_right","settings.saoui.hud_style","settings.saoui.smooth","settings.saoui.smoothing","settings.saoui.scale","settings.saoui.x","settings.saoui.y").contains(key))category="hud";
        else if(key.equals("settings.saoui.ipn"))category="compat";
        else if(key.startsWith("settings.saoui.category.")||key.startsWith("gui."))return;
        else category="interface";
        if(c.computeOnClient(client->((SaoSettingsScreen)client.gui.screen()).page())!=SaoSettingsScreen.Page.HOME)c.clickScreenButton("gui.back");
        c.clickScreenButton("settings.saoui.category."+category);reveal(c,key);
    }
    private static void reveal(ClientGameTestContext c,String key){c.runOnClient(client->{var screen=(SaoSettingsScreen)client.gui.screen();var widget=widget(screen,key);screen.reveal(widget);});c.waitTick();}
    private SettingsNavigation(){}
}
