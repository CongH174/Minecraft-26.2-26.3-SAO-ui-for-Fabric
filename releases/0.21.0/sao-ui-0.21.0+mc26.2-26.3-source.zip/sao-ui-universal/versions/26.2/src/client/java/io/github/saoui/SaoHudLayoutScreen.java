package io.github.saoui;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;

/** Child editor merges into its parent's draft only after Apply. Escape discards local edits. */
final class SaoHudLayoutScreen extends Screen {
    private final Screen parent;
    private final Consumer<SaoConfig> apply;
    private final SaoConfig draft;
    private EditBox xField,yField;
    private SaoButton done;
    private boolean dragging,updating;
    private double grabX,grabY,canvasX,canvasY,canvasScale;
    SaoHudLayoutScreen(Screen parent,SaoConfig initial,Consumer<SaoConfig> apply){super(t("hud_title"));this.parent=parent;this.draft=initial.copy();this.apply=apply;}
    private static Component t(String key,Object...args){return Component.translatable("settings.saoui.layout."+key,args);}
    @Override protected void init(){
        dragging=false;
        int panel=Math.min(430,width-24),left=(width-panel)/2,quarter=(panel-18)/4,y=height-64;
        xField=field(left,y,quarter,"x",draft.x,true);yField=field(left+quarter+6,y,quarter,"y",draft.y,false);
        addRenderableWidget(new SaoSlider(left+2*(quarter+6),y,panel-2*(quarter+6),20,"settings.saoui.scale",draft.scale,v->draft.scale=v));
        int third=(panel-12)/3;
        addRenderableWidget(new SaoButton(left,height-28,third,20,t("reset"),null,()->{draft.x=draft.y=12;draft.scale=1;rebuildWidgets();}));
        done=addRenderableWidget(new SaoButton(left+third+6,height-28,third,20,t("apply"),null,()->{if(valid()){apply.accept(draft.copy());onClose();}}));
        addRenderableWidget(new SaoButton(left+2*(third+6),height-28,third,20,Component.translatable("gui.cancel"),null,this::onClose));
        validate();canvas();
    }
    private EditBox field(int x,int y,int w,String axis,int initial,boolean horizontal){
        var box=addRenderableWidget(new EditBox(font,x,y,w,20,t(axis)));box.setMaxLength(4);box.setValue(Integer.toString(initial));
        box.setResponder(text->{if(!updating){try{int v=Integer.parseInt(text);if(v>=0&&v<=8192){if(horizontal)draft.x=v;else draft.y=v;}}catch(NumberFormatException ignored){}}validate();});return box;
    }
    private boolean validField(EditBox box){if(box==null)return true;try{int n=Integer.parseInt(box.getValue());return n>=0&&n<=8192;}catch(NumberFormatException e){return false;}}
    private boolean valid(){return validField(xField)&&validField(yField);}
    private void validate(){if(xField!=null)xField.setTextColor(validField(xField)?0xFFE5EBE8:0xFFFF7777);if(yField!=null)yField.setTextColor(validField(yField)?0xFFE5EBE8:0xFFFF7777);if(done!=null)done.active=valid();}
    private void sync(){updating=true;xField.setValue(Integer.toString(draft.x));yField.setValue(Integer.toString(draft.y));updating=false;validate();}
    private void canvas(){canvasScale=Math.max(.01,Math.min((width-24.0)/width,(height-112.0)/height));canvasX=(width-width*canvasScale)/2;canvasY=36;}
    private double localX(double x){return (x-canvasX)/canvasScale;}
    private double localY(double y){return (y-canvasY)/canvasScale;}
    private SaoHud.Frame frame(){var p=draft;if(!p.hud.anyBar()){p=p.copy();p.hud.health=true;}return SaoHud.frame(minecraft,p,width,height);}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubleClick){
        if(super.mouseClicked(e,doubleClick))return true;
        if(e.button()!=InputConstants.MOUSE_BUTTON_LEFT||!frame().contains(localX(e.x()),localY(e.y())))return false;
        dragging=true;grabX=localX(e.x())-frame().x();grabY=localY(e.y())-frame().y();setFocused(null);return true;
    }
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){
        if(!dragging)return super.mouseDragged(e,dx,dy);
        double unit=UiEffects.unit(minecraft.getWindow().getHeight(),minecraft.getWindow().getGuiScale());var f=frame();
        draft.x=LayoutEditing.referenceOffset(localX(e.x()),grabX,unit,width,f.width());draft.y=LayoutEditing.referenceOffset(localY(e.y()),grabY,unit,height,f.height());sync();return true;
    }
    @Override public boolean mouseReleased(MouseButtonEvent e){if(dragging&&e.button()==InputConstants.MOUSE_BUTTON_LEFT){dragging=false;return true;}return super.mouseReleased(e);}
    @Override public boolean keyPressed(KeyEvent e){
        if(getFocused() instanceof EditBox)return super.keyPressed(e);
        int dx=e.key()==InputConstants.KEY_LEFT?-1:e.key()==InputConstants.KEY_RIGHT?1:0,dy=e.key()==InputConstants.KEY_UP?-1:e.key()==InputConstants.KEY_DOWN?1:0;
        if(dx!=0||dy!=0){draft.x=Math.clamp(draft.x+dx,0,8192);draft.y=Math.clamp(draft.y+dy,0,8192);sync();return true;}return super.keyPressed(e);
    }
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta){
        canvas();g.fill(0,0,width,height,0xED101820);g.text(font,title,(width-font.width(title))/2,10,0xFFFFCF70,false);
        g.text(font,font.plainSubstrByWidth(t("hud_hint").getString(),width-24),12,24,0xFFCED8D9,false);
        int cx=(int)canvasX,cy=(int)canvasY,cw=(int)(width*canvasScale),ch=(int)(height*canvasScale);
        g.fill(cx-1,cy-1,cx+cw+1,cy+ch+1,0xFF64777C);g.fill(cx,cy,cx+cw,cy+ch,0xFF22333C);
        g.pose().pushMatrix();g.pose().translate((float)canvasX,(float)canvasY);g.pose().scale((float)canvasScale,(float)canvasScale);
        g.fill(width/2,0,width/2+1,height,0x443F626A);g.fill(0,height/2,width,height/2+1,0x443F626A);
        SaoHud.preview(g,minecraft,draft,width,height);var f=frame();
        g.fill(f.x(),f.y()-2,f.x()+f.width(),f.y()-1,0xFFFFCF70);g.fill(f.x(),f.y()+f.height()+1,f.x()+f.width(),f.y()+f.height()+2,0xFFFFCF70);
        if(dragging){g.fill(f.x(),0,f.x()+1,height,0x88FFCF70);g.fill(0,f.y(),width,f.y()+1,0x88FFCF70);}
        g.pose().popMatrix();g.text(font,t("x"),xField.getX(),height-75,0xFFE0E8E6,false);g.text(font,t("y"),yField.getX(),height-75,0xFFE0E8E6,false);
        super.extractRenderState(g,mx,my,delta);
    }
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
