package io.github.saoui;

import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;

/** A schematic over the same placement math as native container presentation; no inventory is opened. */
final class SaoContainerLayoutScreen extends Screen {
    private final Screen parent;
    private final ContainerUiProfile draft;
    private final Consumer<ContainerUiProfile> apply;
    private final EditBox[] fields=new EditBox[5];
    private SaoButton done,side;
    private boolean updating;
    private int selected,dragging=-1,startX,startY;
    private double pressX,pressY,viewScale,centerX,centerY;
    SaoContainerLayoutScreen(Screen parent,ContainerUiProfile initial,Consumer<ContainerUiProfile> apply){super(t("container_title"));this.parent=parent;draft=initial.copy();this.apply=apply;}
    private static Component t(String key,Object...args){return Component.translatable("settings.saoui.layout."+key,args);}
    @Override protected void init(){
        dragging=-1;int panel=Math.min(460,width-24),left=(width-panel)/2,w=(panel-18)/4,y=height-62;
        side=addRenderableWidget(new SaoButton(left,37,panel-64-font.width(t("gap"))-12,18,sideLabel(),null,()->{draft.backpackSide=ContainerUiProfile.Side.values()[(draft.backpackSide.ordinal()+1)%4];side.setMessage(sideLabel());reframe();}));
        fields[4]=field(left+panel-64,37,64,4,draft.gap);
        for(int i=0;i<4;i++)fields[i]=field(left+i*(w+6),y,w,i,value(i));
        int third=(panel-12)/3;
        addRenderableWidget(new SaoButton(left,height-27,third,20,t("reset"),null,()->{draft.containerX=draft.containerY=draft.backpackX=draft.backpackY=0;draft.gap=18;draft.backpackSide=ContainerUiProfile.Side.RIGHT;sync();side.setMessage(sideLabel());reframe();}));
        done=addRenderableWidget(new SaoButton(left+third+6,height-27,third,20,t("apply"),null,()->{if(valid()){apply.accept(draft.copy());onClose();}}));
        addRenderableWidget(new SaoButton(left+2*(third+6),height-27,third,20,Component.translatable("gui.cancel"),null,this::onClose));validate();reframe();
    }
    private Component sideLabel(){return Component.translatable("settings.saoui.containers.side",Component.translatable("settings.saoui.containers.side."+draft.backpackSide.name().toLowerCase(java.util.Locale.ROOT)));}
    private int value(int i){return switch(i){case 0->draft.containerX;case 1->draft.containerY;case 2->draft.backpackX;case 3->draft.backpackY;default->draft.gap;};}
    private void value(int i,int v){switch(i){case 0->draft.containerX=v;case 1->draft.containerY=v;case 2->draft.backpackX=v;case 3->draft.backpackY=v;default->draft.gap=v;}}
    private EditBox field(int x,int y,int w,int i,int initial){var box=addRenderableWidget(new EditBox(font,x,y,w,18,t(i==4?"gap":"offset_"+i)));box.setMaxLength(4);box.setValue(Integer.toString(initial));box.setResponder(text->{if(!updating){try{int n=Integer.parseInt(text);if(n>=(i==4?0:-200)&&n<=(i==4?96:200)){value(i,n);reframe();}}catch(NumberFormatException ignored){}}validate();});return box;}
    private boolean validField(int i){if(fields[i]==null)return true;try{int n=Integer.parseInt(fields[i].getValue());return n>=(i==4?0:-200)&&n<=(i==4?96:200);}catch(NumberFormatException e){return false;}}
    private boolean valid(){for(int i=0;i<5;i++)if(!validField(i))return false;return true;}
    private void validate(){for(int i=0;i<5;i++)if(fields[i]!=null)fields[i].setTextColor(validField(i)?0xFFE5EBE8:0xFFFF7777);if(done!=null)done.active=valid();}
    private void sync(){updating=true;for(int i=0;i<5;i++)fields[i].setValue(Integer.toString(value(i)));updating=false;validate();}
    private void reframe(){
        var p=ContainerPanelLayout.place(222,draft);var b=p.baseline();var bounds=p.bounds();
        double extentX=Math.max(Math.abs(bounds.x()+draft.containerX-b.centerX()),Math.abs(bounds.x()+bounds.width()+draft.containerX-b.centerX()));
        double extentY=Math.max(Math.abs(bounds.y()+draft.containerY-b.centerY()),Math.abs(bounds.y()+bounds.height()+draft.containerY-b.centerY()));
        centerX=width/2.0;centerY=(62+height-84)/2.0;viewScale=Math.max(.01,Math.min((width-40)/(2*extentX+20),(height-150)/(2*extentY+20)));
    }
    private ContainerPanelLayout.Rect rect(int id){var p=ContainerPanelLayout.place(222,draft);return id==0?new ContainerPanelLayout.Rect(0,-36,222,212):new ContainerPanelLayout.Rect(p.backpackX(),p.backpackY()-36,222,212);}
    private double sx(int x){return centerX+(x+draft.containerX-ContainerPanelLayout.place(222,draft).baseline().centerX())*viewScale;}
    private double sy(int y){return centerY+(y+draft.containerY-ContainerPanelLayout.place(222,draft).baseline().centerY())*viewScale;}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubleClick){
        if(super.mouseClicked(e,doubleClick))return true;if(e.button()!=InputConstants.MOUSE_BUTTON_LEFT)return false;
        for(int id=1;id>=0;id--){var r=rect(id);if(e.x()>=sx(r.x())&&e.x()<sx(r.x()+r.width())&&e.y()>=sy(r.y())&&e.y()<sy(r.y()+r.height())){selected=dragging=id;pressX=e.x();pressY=e.y();startX=value(id*2);startY=value(id*2+1);setFocused(null);return true;}}return false;
    }
    private int snapOffset(double n,int other){n=Math.clamp(n,-200,200);if(Math.abs(n)<=5/viewScale)n=0;if(Math.abs(n-other)<=5/viewScale)n=other;return (int)Math.round(n);}
    @Override public boolean mouseDragged(MouseButtonEvent e,double dx,double dy){if(dragging<0)return super.mouseDragged(e,dx,dy);int i=dragging*2;value(i,snapOffset(startX+(e.x()-pressX)/viewScale,value((1-dragging)*2)));value(i+1,snapOffset(startY+(e.y()-pressY)/viewScale,value((1-dragging)*2+1)));sync();return true;}
    @Override public boolean mouseReleased(MouseButtonEvent e){if(dragging>=0&&e.button()==InputConstants.MOUSE_BUTTON_LEFT){dragging=-1;reframe();return true;}return super.mouseReleased(e);}
    @Override public boolean keyPressed(KeyEvent e){if(getFocused() instanceof EditBox)return super.keyPressed(e);int dx=e.key()==InputConstants.KEY_LEFT?-1:e.key()==InputConstants.KEY_RIGHT?1:0,dy=e.key()==InputConstants.KEY_UP?-1:e.key()==InputConstants.KEY_DOWN?1:0;if(dx!=0||dy!=0){value(selected*2,Math.clamp(value(selected*2)+dx,-200,200));value(selected*2+1,Math.clamp(value(selected*2+1)+dy,-200,200));sync();reframe();return true;}return super.keyPressed(e);}
    @Override public void extractRenderState(GuiGraphicsExtractor g,int mx,int my,float delta){
        g.fill(0,0,width,height,0xED101820);g.text(font,title,(width-font.width(title))/2,9,0xFFFFCF70,false);g.text(font,font.plainSubstrByWidth(t("container_hint").getString(),width-24),12,24,0xFFCED8D9,false);
        g.fill(12,60,width-12,height-83,0xFF22333C);g.fill(width/2,60,width/2+1,height-83,0x443F626A);
        for(int id=0;id<2;id++){
            var r=rect(id);int x=(int)sx(r.x()),y=(int)sy(r.y()),w=(int)(r.width()*viewScale),h=(int)(r.height()*viewScale);int edge=id==selected?0xFFFFCF70:0xFF90A4A4;
            g.fill(x-1,y-1,x+w+1,y+h+1,edge);g.fill(x,y,x+w,y+h,0xFFE0E6E0);
            g.pose().pushMatrix();g.pose().translate(x,y);g.pose().scale((float)viewScale,(float)viewScale);

            for(int row=0;row<3;row++)for(int col=0;col<9;col++){int cx=14+col*22,cy=58+row*22;g.fill(cx,cy,cx+20,cy+20,0xFFB9C5BD);g.fill(cx+1,cy+1,cx+19,cy+19,0xFFF3F5EE);}
            if(id==1)for(int col=0;col<9;col++)g.fill(14+col*22,150,34+col*22,170,0xFFF3F5EE);
            g.pose().popMatrix();
            g.text(font,font.plainSubstrByWidth(t(id==0?"container_short":"backpack_short").getString(),Math.max(1,w-8)),x+4,y+4,0xFF404443,false);
        }
        for(int i=0;i<4;i++)g.text(font,font.plainSubstrByWidth(t("offset_"+i).getString(),fields[i].getWidth()),fields[i].getX(),height-74,0xFFDEE7E4,false);
        g.text(font,t("gap"),fields[4].getX()-font.width(t("gap"))-4,41,0xFFDEE7E4,false);super.extractRenderState(g,mx,my,delta);
    }
    @Override public void onClose(){minecraft.gui.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
}
